// ./library/ZakzzIsNotDev.js
function unpack(str) {
    try {
        if (/eval\(function\(p,a,c,k,e,d\)/.test(str)) {
            const Unpacker = require('unpacker');'
            if (Unpacker.detect(str)) {
                return Unpacker.unpack(str);
            }
        }
    } catch (err) {
        console.error('❌ Error unpack:', err);
    }
    return null;
}

module.exports = { unpack };