const axios = require("axios");

/**
 * Ubah level proteksi Cloudflare berdasarkan domain
 * @param {string} domain - Misalnya "example.com"
 * @param {string} mode - Mode proteksi (low, high, under_attack, dll)
 * @param {string} token - API Token Cloudflare
 */
async function setSecurityLevel(domain, mode, token) {
  try {
    // 1. Ambil zone ID dari domain
    const zoneRes = await axios.get("https://api.cloudflare.com/client/v4/zones", {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      params: { name: domain }
    });

    const zone = zoneRes.data.result[0];
    if (!zone) {
      return { success: false, message: `Zone untuk domain ${domain} tidak ditemukan.` };
    }

    // 2. Update proteksi
    const updateRes = await axios.patch(
      `https://api.cloudflare.com/client/v4/zones/${zone.id}/settings/security_level`,
      { value: mode },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        }
      }
    );

    if (updateRes.data.success) {
      return { success: true };
    } else {
      return {
        success: false,
        message: updateRes.data.errors?.[0]?.message || "Gagal mengubah mode.",
      };
    }
  } catch (err) {
    return {
      success: false,
      message: err.response?.data?.errors?.[0]?.message || err.message,
    };
  }
}

module.exports = { setSecurityLevel };