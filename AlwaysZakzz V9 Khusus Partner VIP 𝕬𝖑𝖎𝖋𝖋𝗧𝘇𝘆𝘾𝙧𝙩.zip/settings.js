const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")


/* 

=========================================================================

 HELO BG 🦅
 CREDIT : 𝐴𝑙𝑤𝑎𝑦𝑠𝑍𝑎𝑘𝑧𝑧 𝑂𝑓𝑓𝑖𝑐𝑖𝑎𝑙
 WA AlwaysZakzz : 6285817068074
 
 NOTE: JANGAN HAPUS CREDIT DEVELOPER, HAPUS? SEMOGA SC NYA ERROR MAMPUS WKWK
 
=========================================================================

*/


//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6281315224632'
global.versi = version
global.namaOwner = "Aliftzycrt Arzeth ion"
global.packname = 'BY Aliftzycrt'
global.botname = 'Danzd Arzeth ion'
global.botname2 = 'Danzd arzeth ion'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6281315224632"
global.linkGrup = "https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 2500
global.delayPushkontak = 4500

//~~~~~~~~~~~ Vercel Tokens ~~~~~~~~~~//
global.vercelToken = 'ejn0BWaybh7iZVPd6ohUsUFV'

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029VbAbqrkBvvseV1Cpk73p" 
global.idSaluran = "120363403066612655@newsletter" 
global.namaSaluran = "𝕬𝖑𝖎𝖋𝖋𝗧𝘇𝘆𝘾𝙧𝙩-𝙰𝚛𝚣𝚎𝚝𝚑-𝚒𝚘𝚗"

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.merchantIdOrderKuota = "OK2409765"
global.apiOrderKuota = "234282517392794232163915OKCT6190CBF9303EF30A25E9ED0F4A4E8C54"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214511199581585990303UMI51440014ID.CO.QRIS.WWW0215ID20253689275670303UMI5204541153033605802ID5918AAN TOKO OK21639156007CILACAP61055321162070703A0163044650"
global.pinOrkut = "1203"
global.pwOrkut = "ZAKZZDEV02"

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "-"
global.ZakzzDev = "zakzz"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "083143274439"
global.ovo = "_"
global.gopay = "083143274439"
global.shopepay = "_"
global.qris = "https://img1.pixhost.to/images/5528/595408081_zakzzdev.jpg"

//~~~~~~~~~~~~ Settings Keamanan Panel ~~~~~~~~~~~~//
global.emailPanel = "Aliftzy@gmail.com" // Email yang tidak boleh dihapus
global.ownerServerName = "ZakzzDev" // Nama server yang tidak boleh dihapus

//~~~~~~~~~~~~ Settings Keamanan Panel V2 ~~~~~~~~~~~~//
global.emailPanelV2 = "Aliftzy@gmail.com"
global.ownerServerNameV2 = "ZakzzDev"

//~~~~~~~~~ Settings Api Panel ~~~~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "_"
global.apikey = "_" //ptla
global.capikey = "_" //ptlc

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "-" //ptla
global.capikeyV2 = "-" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "❌ *`𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝`*\n➤  𝐑𝐞𝐬𝐭𝐫𝐢𝐜𝐭𝐞𝐝 𝐟𝐨𝐫 𝐎𝐰𝐧𝐞𝐫/𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐎𝐧𝐥𝐲\n➤  ᴏɴʟʏ ᴜsᴀʙʟᴇ ʙʏ ᴀʟᴡᴀʏꜱᴢᴀᴋᴢᴢ",
	admin: "❌ *`Admin Only`*\n➤  ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ",
	botAdmin: "❌ *`Bot Is Not Admin`*\n➤ 𝐌𝐚𝐤𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭 𝐚𝐧 𝐀𝐝𝐦𝐢𝐧 𝐟𝐢𝐫𝐬𝐭",
	group: "❌ *`Group Only`*\n➤  ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ɢʀᴏᴜᴘ",
	private: "❌ *`Private Only`*\n➤  ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ᴅɪ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ",
	prem: "❌ *`Premium Feature`*\n➤  ʜᴀʀᴀᴘ ᴛɪɴɢᴋᴀᴛᴋᴀɴ ᴀᴋᴜɴ ᴀɴᴅᴀ ᴋᴇ ᴘʀᴇᴍɪᴜᴍ",
	wait: '⏳ *`𝐋𝐨𝐚𝐝𝐢𝐧𝐠...`*',
	error: '❌ *`𝐄𝐫𝐫𝐨𝐫 𝐎𝐜𝐜𝐮𝐫𝐫𝐞𝐝!`*',
	done: '✅ *`𝐒𝐮𝐜𝐜𝐞𝐬𝐬`*'
}

global.nokosvirtusim = [
  { id: "716", nama: "Nokos WhatsApp Indonesia", harga: 5000 },
  { id: "1537", nama: "Nokos WhatsApp China", harga: 20000 },
  { id: "313", nama: "Nokos WhatsApp Malaysia", harga: 10000 },
  { id: "2257", nama: "Nokos WhatsApp India", harga: 10000 },
  { id: "4063", nama: "Nokos WhatsApp Inggris", harga: 10000 },
  { id: "556", nama: "Nokos WhatsApp Thailand", harga: 10000 },
  { id: "733", nama: "Nokos Telegram Indonesia", harga: 5000 },
  { id: "344", nama: "Nokos Telegram Malaysia", harga: 10000 },
  { id: "2415", nama: "Nokos Telegram China", harga: 20000 },
  { id: "1875", nama: "Nokos Telegram Amerika", harga: 8000 }
];

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})